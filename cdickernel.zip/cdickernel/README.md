# CDIC Kernel

A project built with Hexagonal Architecture (a.k.a Ports and Adapters) in Python.

This project demonstrates separation of concerns, testable business logic, and clear boundaries between infrastructure and application core.

🧱 Technologies:
- Python 3.11+
- Uvicorn
- FastAPI
- SQLAlchemy / asyncpg
- Celery
- Redis
- PostgreSQL
- OpenAI

```
透過 Makefile 執行，相關指令請參考 Makefile 的內容

常用指令：
1. 執行
make up

2. 關閉
make down

3. 背景執行
make restart
```