from fastapi import APIRouter, status
from fastapi.responses import JSONResponse
from app.shared.database.tennat.connection_manager import tenant_conn_mgr

router = APIRouter(
    prefix="/heartbeat",
    include_in_schema=True,
)

@router.get(path="/readiness", status_code=status.HTTP_200_OK)
async def readiness() -> JSONResponse:
    await tenant_conn_mgr.check_connection()
    return JSONResponse({"status": "ready"})

@router.get(path="/liveness", status_code=status.HTTP_200_OK)
async def liveness() -> JSONResponse:
    await tenant_conn_mgr.check_connection()
    return JSONResponse({"status": "alive"})