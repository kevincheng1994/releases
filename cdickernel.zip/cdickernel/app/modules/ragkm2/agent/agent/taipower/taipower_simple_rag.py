from typing import Optional

from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.query_constructor.base import AttributeInfo
from langchain_core.prompts import ChatPromptTemplate

from app.modules.ragkm2.agent.database.chroma_maker import ChromaMaker
from app.modules.ragkm2.agent.utils import utils

from .taipower_tools import CHUNK_RETRIEVER_NAME, LIST_DOC_NAMES_NAME


class StatusCode:
    COMPLETION = 200
    GENERATERESPONSE = 201
    INFOINTERMEDIATE = 202
    OBSERVATION = 203
    UNFORMATTEDCOMPLETION = 204


class Stage:
    INITIAL = 1
    REPHRASE = 2
    FORMAT = 3


SIMPLE_RAG_SYSTEM_PROMPT = """
請根據提供的文章內容回答問題, 答應簡潔明了，專注於解決問題，若答案不在提供的內容則回答「不知道」
Context: {context}"


為了使回答符合使用者所需, 請遵守下列規定思考問題答案:
1. 無論如何都使用繁體中文, 除了書名(文件名)以及專業名詞
2. 當使用者有指定格式時, Final Answer 請輸出該格式的輸出
3. 若沒有指定格式, 且使用者問題, 如 請摘要 [書名] 或請總結 [書名] 的內容, Final Answer 根據以下結構撰寫摘要並將字數限制在 1000 ~ 2000 字之間:
    背景：總結研究的背景和動機
    研究方向：描述研究的主要重點和目標
    主要建議：概述研究中的關鍵建議或提議
    發現：強調研究的主要發現或結果
    總體考慮：總結研究的重要觀點或更廣泛的影響
    未來方向：指出論文中提到的未來研究方向或限制
4. 若沒有指定格式, 且不是第 3 點提到的問題, Answer 請以列表形式呈現
5. 敘述風格簡潔直接, 包含專業術語和縮寫(通時包含全稱),反映出專業性
6. 說話語氣正式專業, 偶爾使用直接引語,增加真實感和權威性
"""

SIMPLE_RAG_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SIMPLE_RAG_SYSTEM_PROMPT),
        ("human", "{input}"),
    ]
)


METADATA_FIELD_INFO = [
    AttributeInfo(
        name="year",
        description="The publication year of the section or the book",
        type="int",
    ),
    AttributeInfo(
        name="month",
        description="The publication month of the section or the book",
        type="int",
    ),
    AttributeInfo(
        name="title",
        description="""
                    The title of the book or section. It is always delimited by triple backquotes.
                    For example, when the input is [xxx example.npy], the title would be "xxx example.npy".
                    """,
        type="string",
    ),
]


class TaipowerSimpleRAG:

    def __init__(self, chain, verbose):
        self.chain = chain
        self.verbose = verbose

    @classmethod
    def create(
        cls,
        llm_kwargs: dict,
        embeddings_kwargs: dict,
        vectorstore_kwargs: dict,
        metadata_field_info: dict = METADATA_FIELD_INFO,
        verbose: bool = False,
        *args,
        **kwargs,
    ) -> "TaipowerSimpleRAG":

        llm_kwargs["temperature"] = 0
        llm = utils.create_llm(**llm_kwargs)

        # create retriever
        if vectorstore_kwargs["persist_dir"]:
            # vectorstore = ChromaMaker(key_dict).create_from_persist_dir(
            #     persist_dir=vectorstore_persist_dir,
            #     service_platform=service_platform,
            #     available_docnames=None
            # )
            raise NotImplementedError("no docnames for list doc names tool")
        elif vectorstore_kwargs["chunk_dir"] and vectorstore_kwargs["docname_to_metadata"]:
            vectorstore, docnames = ChromaMaker().create_from_chunk_dir(**embeddings_kwargs, **vectorstore_kwargs)
        else:
            raise ValueError("vectorstore args is not valid")

        # retriever = SelfQueryRetriever.from_llm(
        #     llm=llm,
        #     vectorstore=vectorstore,
        #     document_contents='various papers',
        #     metadata_field_info=metadata_field_info
        # )
        retriever = vectorstore.as_retriever()
        retriever.search_kwargs.update({"k": 5})
        question_answer_chain = create_stuff_documents_chain(llm, SIMPLE_RAG_PROMPT)
        chain = create_retrieval_chain(retriever, question_answer_chain)

        return cls(chain=chain, verbose=verbose)

    create_agent = create

    @classmethod
    def create_from_config(cls, configs: dict) -> "TaipowerSimpleRAG":
        # read config
        llm_kwargs = configs["llm"]
        embeddings_kwargs = configs["embeddings"]
        vectorstore_kwargs = configs["vectorstore"]
        verbose = configs["verbose"]

        return cls.create(
            llm_kwargs=llm_kwargs,
            embeddings_kwargs=embeddings_kwargs,
            vectorstore_kwargs=vectorstore_kwargs,
            verbose=verbose,
        )

    def stream(self, question: dict, stop_stage: Optional[Stage] = None):
        # translate chinese to english
        tc_q = question.get("input")
        if tc_q is None:
            raise ValueError("The question is a dictionary and should have two keys input and chat_history")

        # iter_id = 0
        # references = {CHUNK_RETRIEVER_NAME: [], LIST_DOC_NAMES_NAME: []}
        # chunk_retriever_context_memo = {}
        # intermediate_thotghts = ''

        references = {CHUNK_RETRIEVER_NAME: [], LIST_DOC_NAMES_NAME: []}

        answer = self.chain.invoke({"input": tc_q})
        pairs = []
        for doc in answer["context"]:
            pairs.append([doc.page_content, doc.metadata["title"], doc.metadata])
        references[CHUNK_RETRIEVER_NAME].extend(pairs)
        yield (StatusCode.COMPLETION, answer["answer"], references)
