from .taipower_agent import TaipowerAgent
from .taipower_simple_rag import TaipowerSimpleRAG

__all__ = ["TaipowerAgent", "TaipowerSimpleRAG"]

SUPPORTED_TYPES = ["agent", "simple_rag"]


def create(agent_type: str, *args, **kwargs):
    atype = agent_type.lower()
    acls = None
    if atype == "agent":
        acls = TaipowerAgent
    elif atype == "simple_rag":
        acls = TaipowerSimpleRAG
    # elif atype == "concise_agent":
    # acls = TaipowerConciseAgent
    if acls is None:
        raise NotImplementedError
    print("create agent: ", atype)
    return acls.create_from_config(*args, **kwargs)
