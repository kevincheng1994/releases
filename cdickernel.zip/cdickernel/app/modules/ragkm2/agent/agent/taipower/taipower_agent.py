import os
import re
import traceback
from typing import Optional
from langchain.agents import AgentExecutor, create_react_agent
from langchain.chains.query_constructor.base import AttributeInfo
from langchain.retrievers.self_query.base import SelfQueryRetriever
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.agents import AgentStep
from app.modules.ragkm2.agent.database.chroma_maker import ChromaMaker
from app.modules.ragkm2.agent.retrievers.bm25_similarity_ensemble_retriever import BM25SimilarityEnsembleRetriever
from app.modules.ragkm2.agent.status_code import ReturnProcess
from app.modules.ragkm2.agent.utils import utils

# 導入 Prompt 和修正拼寫後的工具相關常數與函式
from .taipower_prompt import OPTIMIZED_REACT_PROMPT  # , get_react_prompt
from .taipower_tools import (  # ENTIRE_RETRIEVER_NAME,; create_question_classifier_chain,; RAGQueryAnalyzer,
    CHUNK_RETRIEVER_NAME,
    LIST_DOC_NAMES_NAME,
    EvidenceManager,
    InMemoryNotebook,
    QueryAnalysis,
    SubQuestion,
    create_beast_chain,
    create_chunk_retriever_tool,
    create_entire_retriever_tool,
    create_final_synthesis_chain,
    create_list_doc_names_tool,
    create_markdown_chain,
    create_notebook_tool,
    create_query_analyzer_chain,
    create_query_correction_chain,
    create_rag_query_analyzer_chain,
    create_task_completer_tool,
)

# --- 輔助函數與定義 ---
def _format_steps_to_thought(steps: list[AgentStep]) -> str:
    """將 Agent 的思考步驟歷史格式化為單一的字串，供 Beast Mode 使用。"""
    return "\n".join([f"{step.action.log}\nObservation: {step.observation}" for step in steps])


def _extract_cited_sources(text: str) -> set[str]:
    """從回答文字中提取被引用的來源檔名。

    支援兩種格式：
    - [^filename.pdf]  (synthesis chain 引用格式)
    - [filename.pdf]   (beast mode 引用格式)
    """
    cited = set(re.findall(r'\[\^([^\]]+)\]', text))
    cited.update(re.findall(r'\[([^\]^]+\.(?:pdf|PDF|md|MD|txt|TXT|docx|DOCX))\]', text))
    return cited


class Stage:
    """定義 Agent 流程中可以停止的階段點。"""

    INITIAL = 1
    BEAST = 2
    FORMAT = 3


# --- 中繼資料定義 ---
# 用於 SelfQueryRetriever，定義可以進行元數據過濾的欄位。
METADATA_FIELD_INFO = [
    AttributeInfo(name="year", description="The publication year of the book", type="int"),
    AttributeInfo(name="month", description="The publication month of the book", type="int"),
    AttributeInfo(name="title", description="The title of the book", type="string"),
]

# --- 主要 Agent 類別 ---


from uuid import UUID
from app.modules.ragkm2.agent.repository import KnowledgeBaseRepository

class TaipowerAgent:
    """
    一個採用智慧路由的 RAG Agent。

    它首先使用問題分類器來判斷用戶意圖，然後選擇最高效的處理路徑：
    - 對於簡單請求（如列出文件、全文摘要），它會走捷徑，直接調用工具。
    - 對於複雜的內容查詢，它會啟用完整的 ReAct 循環來進行深度檢索和推理。
    """

    # 定義 Agent 各個操作所需的 LLM 實例名稱，用於追蹤 token 使用量。
    OPERATION_NAMES = [
        "react",
        "synthesis",
        "correction",
        "q_analyzer",
        "rag_analyzer",
        "beast",
        "markdown",
        "entire_retriever_tool",
        "selfquery_retriever",
        # "q_classifier",
    ]

    def __init__(
        self,
        agent_executor_factory,
        markdown_chain,
        beast_chain,
        # classifier_chain,
        query_correction_chain,
        query_analyzer,
        rag_query_analyzer,
        synthesis_chain,
        docnames: list[str],
        retriever,
        vectorstore,
        llms,
        verbose: bool,
        enable_notebook: bool,
    ):
        self.agent_executor_factory = agent_executor_factory
        self.markdown_chain = markdown_chain
        self.beast_chain = beast_chain
        # self.classifier_chain = classifier_chain
        self.query_correction_chain = query_correction_chain
        self.query_analyzer = query_analyzer
        self.rag_query_analyzer = rag_query_analyzer
        self.synthesis_chain = synthesis_chain
        self.verbose = verbose
        self.docnames = docnames
        self.retriever = retriever
        self.vectorstore = vectorstore
        self.llms = llms
        self.enable_notebook = enable_notebook

    # def _create_agent_executor(self, prompt: PromptTemplate, max_steps: int) -> AgentExecutor:
    #     """根據給定的 Prompt 動態創建一個 AgentExecutor。"""
    #     react_agent = create_react_agent(self.llms["react"], self.tools, prompt)
    #     return AgentExecutor(
    #         agent=react_agent,
    #         tools=self.tools,
    #         verbose=self.verbose,
    #         handle_parsing_errors=True,
    #         max_iterations=max_steps,
    #         return_intermediate_steps=True,
    #     )

    @classmethod
    async def create(
        cls,
        llm_configs: dict,
        embeddings_kwargs: dict,
        vectorstore_kwargs: dict,
        knowledge_base_id: UUID,
        is_bm25_ensemble: bool = True,
        is_rephrase: bool = False,
        verbose: bool = False,
        use_reranker: bool = False,
        enable_notebook: bool = True,
    ) -> "TaipowerAgent":
        """
        工廠方法，負責組裝 Agent 所需的所有重度資源 (LLMs, VectorStore, Retriever)
        並創建一個輕量級的 Agent Executor 工廠。
        """

        # 1. 創建所有 LLM 實例
        llms = {}

        # 獲取預設的 LLM 設定
        default_config = llm_configs.get("default", {})
        if not default_config:
            raise ValueError("llm_configs must contain a 'default' configuration.")

        # # 確保 agent react 循環的溫度為0，以獲得更穩定的工具使用
        # llm_react_kwargs = llm_kwargs.copy()
        # llm_react_kwargs["temperature"] = 0

        for on in cls.OPERATION_NAMES:
            # 只有 react 循環使用特別的溫度設定
            # current_kwargs = llm_react_kwargs if on == "react" else llm_kwargs
            # llms[on] = utils.create_llm(**current_kwargs, token_operation=on)

            # 獲取該操作的特定設定，如果沒有，則使用預設設定
            op_config = llm_configs.get(on, default_config)

            # 從設定中提取參數
            # 提取所有其他參數 (temperature, max_output_tokens 等)
            model_kwargs = {k: v for k, v in op_config.items() if k not in ["llm_type", "key_dict", "model_name"]}

            llms[on] = utils.create_llm(
                llm_type=op_config.get("llm_type"),
                key_dict=op_config.get("key_dict"),
                model_name=op_config.get("model_name"),
                token_operation=on,
                **model_kwargs,
            )

        # 2. 創建向量資料庫 (從資料庫讀取)
        repository = KnowledgeBaseRepository()
        chunks_data = await repository.get_chunks_by_kb_id(knowledge_base_id)
        # 列出筆數
        print(f"Knowledge base ID {knowledge_base_id} has {len(chunks_data)} chunks.")
        
        chroma_maker = ChromaMaker()
        vectorstore, docnames = chroma_maker.create_from_db(
            embedding_type=embeddings_kwargs.get("embedding_type"),
            key_dict=embeddings_kwargs.get("key_dict"),
            model_name=embeddings_kwargs.get("model_name"),
            chunks_data=chunks_data,
            persist_dir=vectorstore_kwargs.get("persist_dir"),
        )

        final_k = 20

        # 如果沒有 Reranker，我們需要讓初始召回更「慷慨」一些，以彌補缺少精排的損失。
        if not use_reranker:
            retrieval_k = final_k * 2  # 例如，將召回數量加倍到 10
            if verbose:
                print(f"⚠️ Reranker 已禁用。將初始召回數量 (retrieval_k) 提高到 {retrieval_k} 以進行補償。")
        else:
            # 如果有 Reranker，我們召回更多的候選者，讓 Reranker 有足夠的材料去「挖掘遺珠」。
            # Reranker 的輸入應該遠大於 final_k。
            retrieval_k = final_k * 4  # 例如，召回 20 個，讓 Reranker 從中選出最好的 5 個。
            if verbose:
                print(f"✅ Reranker 已啟用。初始召回數量 (retrieval_k) 設定為 {retrieval_k}。")

        # 3. 根據配置選擇並創建檢索器類型。
        if is_bm25_ensemble:
            retriever = BM25SimilarityEnsembleRetriever(
                db=vectorstore,
                k=retrieval_k,
                final_k=final_k,
                weights=[0.5, 0.5],
                reranker_model_name="BAAI/bge-reranker-base" if use_reranker else None,
            )
        else:
            retriever = SelfQueryRetriever.from_llm(
                llm=llms["selfquery_retriever"],
                vectorstore=vectorstore,
                document_contents="various papers",
                metadata_field_info=METADATA_FIELD_INFO,
                verbose=verbose,
            )
            retriever.search_kwargs.update({"k": retrieval_k})

        # 4. 定義一個輕量級的工廠函數，用於在每次 stream 調用時動態創建 AgentExecutor。
        # 這個工廠會接收每次請求時臨時創建的 evidence_manager 和 notebook_instance。
        def agent_executor_factory(evidence_manager: "EvidenceManager", notebook_instance: "InMemoryNotebook"):

            # 動態組裝工具列表
            tools = [
                create_chunk_retriever_tool(retriever, vectorstore, evidence_manager),
                create_entire_retriever_tool(llms["entire_retriever_tool"], vectorstore),
                create_list_doc_names_tool(docnames),
                create_task_completer_tool(),
            ]
            if enable_notebook:
                tools.append(create_notebook_tool(notebook_instance))

            # 創建 ReAct Agent 和執行器
            react_agent = create_react_agent(llms["react"], tools, OPTIMIZED_REACT_PROMPT)
            return AgentExecutor(
                agent=react_agent,
                tools=tools,
                verbose=verbose,
                handle_parsing_errors=True,
                max_iterations=30,
                return_intermediate_steps=True,
            )

        # 5. 創建並返回 TaipowerAgent 實例。
        # 將所有重度資源和工廠函數傳遞給構造函數。
        return cls(
            # llms=llms,
            agent_executor_factory=agent_executor_factory,
            markdown_chain=create_markdown_chain(llms["markdown"]),
            beast_chain=create_beast_chain(llms["beast"]),
            # classifier_chain=create_question_classifier_chain(llms["q_classifier"]),
            query_correction_chain=create_query_correction_chain(llms["correction"]),
            query_analyzer=create_query_analyzer_chain(llms["q_analyzer"]),
            rag_query_analyzer=create_rag_query_analyzer_chain(llms["rag_analyzer"]),
            synthesis_chain=create_final_synthesis_chain(llms.get("synthesis", llms["react"])),
            docnames=docnames,
            retriever=retriever,
            vectorstore=vectorstore,
            llms=llms,
            enable_notebook=enable_notebook,
            verbose=verbose,
        )

    @classmethod
    async def create_from_config(cls, configs: dict, knowledge_base_id: UUID) -> "TaipowerAgent":
        """從單一配置字典創建 Agent 的便利方法。"""
        return await cls.create(
            llm_configs=configs.get("llm_configs", {}),
            embeddings_kwargs=configs.get("embeddings", {}),
            vectorstore_kwargs=configs.get("vectorstore", {}),
            knowledge_base_id=knowledge_base_id,
            is_bm25_ensemble=configs.get("is_bm25_ensemble", True),
            is_rephrase=configs.get("is_rephrase", False),
            verbose=configs.get("verbose", False),
            use_reranker=configs.get("use_reranker", False),
            enable_notebook=configs.get("enable_notebook", True),
        )

    def _adjust_retrieval_strategy(self, rag_analysis_result: dict):
        """
        根據 RAG 分析結果字典，動態調整檢索策略。

        Args:
            rag_analysis_result (dict): 從 RAGQueryAnalyzer 鏈返回的結果字典。
        """

        if not hasattr(self.retriever, "weights"):
            if self.verbose:
                print("⚠️ 當前檢索器不支持權重調整。")
            return

        # 從字典中安全地獲取檢索策略，如果找不到則使用預設值
        strategy = rag_analysis_result.get("retrieval_strategy", "HYBRID_BALANCED")

        # 根據策略設置權重
        if strategy == "EXACT_MATCH":
            self.retriever.weights = [0.9, 0.1]
        elif strategy == "ENTITY_FOCUSED_HYBRID":
            self.retriever.weights = [0.6, 0.4]
        elif strategy == "SEMANTIC_SEARCH":
            self.retriever.weights = [0.2, 0.8]
        elif strategy == "HYBRID_BALANCED":
            self.retriever.weights = [0.5, 0.5]
        elif strategy == "MULTI_HOP":
            self.retriever.weights = [0.4, 0.6]  # 略偏向語義，支持多跳推理
        else:
            # 如果出現未知的策略，則退回到一個安全的預設值
            self.retriever.weights = [0.5, 0.5]
            if self.verbose:
                print(f"⚠️ 未知的檢索策略 '{strategy}'，使用預設平衡權重。")

        if self.verbose:
            print(
                f"🔧 根據策略 '{strategy}'，調整檢索權重為: BM25={self.retriever.weights[0]}, Vector={self.retriever.weights[1]}"
            )

    def _save_report_to_markdown(
        self, filename: str, question: str, final_answer: str, evidence_manager: EvidenceManager
    ):
        """
        將一次完整的查詢結果（問題、答案、證據）寫入指定的 Markdown 檔案。
        """
        try:
            # 確保檔案所在的目錄存在
            output_dir = os.path.dirname(filename)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            with open(filename, "w", encoding="utf-8") as f:
                f.write("# 查詢分析報告\n\n")
                f.write("## 原始問題 (Initial Question)\n\n")
                f.write(f"{question}\n\n")

                f.write("## 最終答案 (Final Answer)\n\n")
                f.write(f"{final_answer}\n\n")

                f.write("---\n\n")
                f.write("## 來源證據 (Source Chunks)\n\n")

                # 從 evidence_manager 獲取所有證據
                source_chunks = evidence_manager.get_all_evidence_as_docs()

                if not source_chunks:
                    f.write("未找到任何支持證據。\n")
                else:
                    f.write(f"共找到 {len(source_chunks)} 則相關證據：\n\n")
                    for i, doc in enumerate(source_chunks):
                        source_file = doc.metadata.get("source", "未知來源")
                        f.write(f"### 證據 Chunk {i+1} - 來源: {source_file}\n\n")
                        f.write(f"```text\n{doc.page_content}\n```\n\n")

            if self.verbose:
                print(f"✅ 結果已成功保存到 Markdown 檔案: {filename}")

        except Exception as e:
            # 即使存檔失敗，也不應該中斷主流程，只印出錯誤
            print(f"❌ 保存報告到 Markdown 檔案時發生錯誤: {e}")

    def stream(self, question: dict, stop_stage: Optional[Stage] = None, max_steps: int = 30):
        """
        處理使用者問題的主流程，採用一個包含查詢修正、深度分析、智慧路由和
        外部化證據儲存的先進 ReAct 循環。

        Args:
            question (dict): 包含 'input', 'chat_history' 和可選的 'output_filename' 的字典。
            stop_stage (Optional[Stage]): 流程中斷點，用於偵錯。
            max_steps (int): ReAct 循環的最大迭代次數 (此參數現在由 AgentExecutor 初始化時設定)。
        """
        original_question_input = question.get("input")
        chat_history = question.get("chat_history", [])
        output_filename = question.get("output_filename")

        if not original_question_input:
            raise ValueError("問題字典必須包含 'input' 鍵。")

        # =================================================================
        # --- 階段一：查詢格式校正與引導 (可選互動) ---
        # =================================================================
        yield (ReturnProcess.AGENT, "正在解析問題...", {})
        query_correction = self.query_correction_chain.invoke({"input": original_question_input})
        query_correction = query_correction.dict()

        if query_correction.get("is_correction_needed"):
            yield (
                ReturnProcess.REPHRASE,
                query_correction.get("correction_reason"),
                {},
            )
            current_query = query_correction.get("corrected_query")
        else:
            current_query = original_question_input

        # =================================================================
        # --- 階段二：深度查詢分析與策略生成 ---
        # =================================================================

        try:
            if hasattr(self.retriever, "weights"):
                if self.verbose:
                    print("🔄 重置檢索器權重為預設值 [0.5, 0.5]")
                self.retriever.weights = [0.5, 0.5]

            # 2. 階段 0: 智慧化路由
            # classification_result = self.classifier_chain.invoke({"input": original_question_input})
            # qtype = classification_result.get("qtype")
            yield (ReturnProcess.AGENT, "正在分析問題意圖...", {})
            query_analysis = self.query_analyzer.invoke({"input": current_query, "chat_history": chat_history})
            query_analysis = query_analysis.dict()
            qtype = query_analysis.get("qtype")
            sub_questions = query_analysis.get("sub_questions")
            target_entity = query_analysis.get("target_entity")
            rewritten_query = query_analysis.get("rewritten_query")
            suggested_keywords = query_analysis.get("suggested_keywords")
            custom_instructions = query_analysis.get("custom_instructions")

            if self.verbose:
                print("📋 初步查詢分析完成:")
                print(f"   - 重寫後查詢: {rewritten_query}")
                print(f"   - 類型: {qtype}")
                print(f"   - 建議策略: {query_analysis.get('suggested_approach')}")

        except Exception as e:
            print(f"⚠️ 查詢分析階段失敗: {e}。將退回到簡單 RAG 模式。")
            # 設計一個回退機制，確保流程不會中斷
            query_analysis = QueryAnalysis(
                rewritten_query=current_query,
                qtype="SIMPLE_RAG_QUERY",
                target_entity=None,
                sub_questions=[SubQuestion(sub_query=current_query, required_entities=[])],
                suggested_keywords=[],
                suggested_approach="執行標準檢索流程。",
                answer_structure_suggestion=None,
                reasoning="分析鏈執行失敗，採用預設回退策略。",
            )
            # 更新局部變數以供後續使用
            qtype = query_analysis.qtype
            sub_questions = query_analysis.sub_questions
            rewritten_query = current_query
            suggested_keywords = []
            custom_instructions = None

        # =================================================================
        # --- 新增：方案 1 - 擴充主查詢文本 ---
        # =================================================================
        if qtype in ["SIMPLE_RAG_QUERY", "DECOMPOSED_RAG_QUERY"] and suggested_keywords:
            keyword_expansion = " ".join(suggested_keywords)
            rewritten_query_expanded = f"{rewritten_query} (相關關鍵字: {keyword_expansion})"
            if self.verbose:
                print(f"🔍 檢索強化：將主查詢擴充為 -> '{rewritten_query_expanded}'")
        else:
            rewritten_query_expanded = rewritten_query
        # =================================================================
        # --- 階段三：路由與 Agent 準備 ---
        # =================================================================

        # 為本次請求創建獨立的狀態管理器
        evidence_manager = EvidenceManager()
        notebook_instance = InMemoryNotebook() if self.enable_notebook else None

        try:
            if qtype in ["OUT_OF_SCOPE", "LIST_DOCUMENTS", "SUMMARIZE_DOCUMENT"]:
                # --- 捷徑 1: 超出範圍 ---
                if qtype == "OUT_OF_SCOPE":
                    response = "抱歉，我是一個專業的知識庫問答助理，只能回答與資料庫中文件相關的問題。"
                    yield (ReturnProcess.COMPLETION, response, {})
                    return

                # --- 捷徑 2: 列出所有文件 ---
                if qtype == "LIST_DOCUMENTS":
                    if not self.docnames:
                        observation = "資料庫中目前沒有文件。"
                    else:
                        doc_list = [f"- [{name}]" for name in self.docnames]
                        observation = "資料庫包含的文件名稱如下：\n" + "\n".join(doc_list)

                    # 雖然沒有使用 markdown_chain，但為了保持流程一致性，仍然可以呼叫
                    # markdown_out = self.markdown_chain.invoke({"input": observation})
                    references = {
                        LIST_DOC_NAMES_NAME: [
                            [None, name.strip("[]- ")]
                            for name in observation.split("\n")
                            if name.strip() and "." in name
                        ]
                    }
                    yield (ReturnProcess.COMPLETION, observation, references)
                    return

                # --- 捷徑 3: 摘要單一文件 ---
                if qtype == "SUMMARIZE_DOCUMENT":
                    if not target_entity:
                        # 健壯性檢查：如果分析器未能提取出檔案名稱
                        response = "抱歉，我理解您想進行摘要，但未能從您問題中明確找到要摘要的檔案名稱。請嘗試使用 `[檔案名稱]` 的格式。"
                        yield (ReturnProcess.COMPLETION, response, {})
                        return

                    try:
                        # summary_tool = next(t for t in self.agent_executor.tools if t.name == ENTIRE_RETRIEVER_NAME)
                        summary_tool = create_entire_retriever_tool(
                            self.llms["entire_retriever_tool"], self.vectorstore
                        )
                        yield (ReturnProcess.AGENT, f"正在為您摘要檔案 '{target_entity}'...", {})
                        # observation = summary_tool.invoke(original_question_input)
                        # 直接將提取出的檔案名稱傳遞給工具
                        tool_input = {
                            "doc_name": target_entity,
                            "instructions": custom_instructions,  # 即使是 None 也傳遞
                        }
                        observation = summary_tool.invoke(tool_input)
                        markdown_out = self.markdown_chain.invoke({"input": observation})
                        references = {LIST_DOC_NAMES_NAME: [[None, target_entity]]}
                        # 摘要工具的結果已經很完善，可以直接輸出
                        yield (ReturnProcess.COMPLETION, markdown_out.strip(), references)
                        return
                    except Exception as e:
                        # 處理工具執行時可能發生的任何錯誤
                        if self.verbose:
                            print(f"⚠️ 摘要工具執行失敗: {e}")
                        yield (
                            ReturnProcess.COMPLETION,
                            f"抱歉，在為您摘要檔案 '{target_entity}' 的過程中發生錯誤。",
                            {},
                        )
                        return

            if qtype in ["SIMPLE_RAG_QUERY", "DECOMPOSED_RAG_QUERY"]:
                if notebook_instance and sub_questions:
                    if suggested_keywords:
                        keyword_hint = " ".join(suggested_keywords)
                        for sq in sub_questions:
                            original_sub_query = sq.get("sub_query", "")
                            new_sub_query = original_sub_query + f" (請特別關注這些核心概念: {keyword_hint})"
                            sq["sub_query"] = new_sub_query
                        if self.verbose:
                            print("🧠 子問題已強化，將引導 Agent 專注於核心概念。")

                    # 將策略建議注入 Notebook
                    if query_analysis.get("suggested_approach"):
                        notebook_instance.add_task(f"遵循策略：{query_analysis.get('suggested_approach')}")

                    for sq in sub_questions:
                        task = f"回答子問題：{sq.get('sub_query')}"
                        notebook_instance.add_task(task)

                    if self.verbose:
                        print(notebook_instance.review_tasks())

                # 基於清晰的 rewritten_query 調整 RAG 策略
                yield (ReturnProcess.AGENT, "正在規劃檢索策略...", {})
                rag_analysis_result = self.rag_query_analyzer.invoke({"query": rewritten_query})
                rag_analysis_result = rag_analysis_result.dict()
                self._adjust_retrieval_strategy(rag_analysis_result)

            # =================================================================
            # --- 階段四：Agent 執行 (ReAct 循環) ---
            # =================================================================

            # if qtype == "GENERAL_RAG_QUERY":
            #     if self.verbose:
            #         print("進入 GENERAL_RAG_QUERY 深度分析...")

            #     try:
            #         # 第二層分析
            #         rag_analysis_result = self.rag_query_analyzer.invoke({"query": original_question_input})
            #         if self.verbose:
            #             print(f"RAG 策略分析結果 (字典): {rag_analysis_result}")

            #         reasoning_text = rag_analysis_result.get("reasoning", "無法獲取分析理由。")
            #         strategy_msg = f"🔍 分析查詢策略: {reasoning_text}"
            #         yield (ReturnProcess.AGENT, strategy_msg, {})

            #         # 動態調整檢索策略
            #         self._adjust_retrieval_strategy(rag_analysis_result)
            #     except Exception as e:
            #         if self.verbose:
            #             print(f"⚠️ RAG 分析器執行失敗: {e}，使用預設策略")
            #         pass

            # 3. 動態創建本次請求專用的 AgentExecutor
            agent_executor_to_use = self.agent_executor_factory(evidence_manager, notebook_instance)
            agent_input = {"input": rewritten_query_expanded, "chat_history": chat_history}

            if self.verbose:
                print("✅ 初始設定完畢，進入主要 ReAct 循環...")

            # 4. 執行 ReAct 循環 (發散探索階段)
            references = {CHUNK_RETRIEVER_NAME: []}
            # references = {CHUNK_RETRIEVER_NAME: []}
            # references = {}
            agent_scratchpad = ""
            final_agent_output = ""
            beast_mode = False

            try:
                # for i, chunk in enumerate(agent_executor_to_use.iter(question)):
                # for i, step in enumerate(self.agent_executor.stream(question)):
                # for i, chunk in enumerate(agent_executor_to_use.iter(question)):
                for step, chunk in enumerate(agent_executor_to_use.iter(agent_input), 1):
                    # 2. 處理最終輸出 (Final Answer)
                    if "output" in chunk:
                        final_agent_output = chunk["output"]
                        # 最終答案通常在一個單獨的 chunk 中，我們可以在這裡提前 yield
                        # 但為了與 Beast Mode 流程統一，我們在循環外處理
                        break

                    if "intermediate_step" in chunk:
                        # 'intermediate_step' 是一個元組列表: [(AgentAction, Observation), ...]
                        for action, observation in chunk["intermediate_step"]:
                            if action.tool == "TaskCompleter":
                                final_agent_output = observation
                                if self.verbose:
                                    print(f"✅ Agent 發出任務完成訊號: {observation}")
                                break

                            # yield 工具名稱，由 router 端轉換為友善訊息
                            yield (ReturnProcess.AGENT, action.tool, {})
                            # 將完整的步驟（包括 Observation）加入 scratchpad
                            agent_scratchpad += _format_steps_to_thought(
                                [AgentStep(action=action, observation=str(observation))]
                            )

                    if final_agent_output:
                        break

                    # 熔斷機制
                    if step >= agent_executor_to_use.max_iterations and not final_agent_output:
                        if self.verbose:
                            print(f"🔄 Agent 達到最大步數 ({agent_executor_to_use.max_iterations})，觸發 Beast Mode")
                        beast_mode = True
                        break

            except Exception as e:
                if self.verbose:
                    print(f"⚠️ ReAct 執行出現異常: {e}，觸發 Beast Mode")
                    traceback.print_exc()
                beast_mode = True
                agent_scratchpad += f"\n執行異常: {str(e)}"

            if stop_stage == Stage.INITIAL:
                return

            # 5. 根據 ReAct 循環的結果決定下一步
            # --- 5.1 成功完成：進入收斂整合階段 ---
            # 🔥 成功完成的情況
            if final_agent_output and not beast_mode:
                # draft_answer_from_agent = final_agent_output
                final_answer = ""
                evidence_count = evidence_manager.get_evidence_count()

                if evidence_count > 0:
                    yield (
                        ReturnProcess.AGENT,
                        "正在進行最終審校...",
                        {},
                    )
                    if self.verbose:
                        print(f"📚 正在使用 {evidence_count} 則外部證據，對 Agent 的初步答案進行精煉...")

                    all_evidence = evidence_manager.review_all_evidence()
                    final_answer = self.synthesis_chain.invoke(
                        {
                            "all_evidence": all_evidence,
                            "original_question": original_question_input,
                        }
                    )

                else:
                    # 沒有從知識庫檢索證據，但 Agent 可能已從對話歷史推導出答案
                    # 用 beast_chain 根據 agent scratchpad 生成正確回應
                    yield (ReturnProcess.AGENT, "正在進行最終審校...", {})
                    beast_input = f"Question: {original_question_input}\n\nAgent scratchpad:\n{agent_scratchpad}"
                    final_answer = self.beast_chain.invoke({"input": beast_input})

                #     # print(final_answer)
                #     markdown_out = self.markdown_chain.invoke({"input": final_answer})
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=3000, chunk_overlap=150)
                chunks = text_splitter.split_text(final_answer)
                formatted_chunks = [self.markdown_chain.invoke({"input": chunk}) for chunk in chunks]
                markdown_out = "".join(formatted_chunks).strip()
                # markdown_out = self.markdown_chain.invoke({"input": final_agent_output})

                # 填寫reference：只保留最終回答中實際引用的來源
                source_documents = evidence_manager.get_all_evidence_as_docs()
                if source_documents:
                    cited_sources = _extract_cited_sources(markdown_out)
                    if cited_sources:
                        source_documents = [
                            doc for doc in source_documents
                            if doc.metadata.get("source", "") in cited_sources
                        ]
                    pairs = []
                    for doc in source_documents:
                        source = doc.metadata.get("source", "未知來源")
                        pairs.append([doc.page_content, source, doc.metadata])
                    references[CHUNK_RETRIEVER_NAME] = pairs

                if output_filename:
                    if self.verbose:
                        print("📝 偵測到 output_filename，正在將結果保存到檔案...")
                    self._save_report_to_markdown(
                        filename=output_filename,
                        question=original_question_input,
                        final_answer=markdown_out,  # 保存最終格式化好的答案
                        evidence_manager=evidence_manager,  # 傳遞實例
                    )

                yield (ReturnProcess.COMPLETION, markdown_out.strip(), references)
                #     # yield (ReturnProcess.COMPLETION, final_answer.strip(), references)
                return

            # --- 5.2 失敗或超時：進入 Beast Mode ---
            beast_input = f"Question: {original_question_input}\n\n" f"Agent scratchpad:\n{agent_scratchpad}"
            beast_output = self.beast_chain.invoke({"input": beast_input})

            source_documents = evidence_manager.get_all_evidence_as_docs()
            if source_documents:
                cited_sources = _extract_cited_sources(beast_output)
                if cited_sources:
                    source_documents = [
                        doc for doc in source_documents
                        if doc.metadata.get("source", "") in cited_sources
                    ]
                pairs = []
                for doc in source_documents:
                    source = doc.metadata.get("source", "未知來源")
                    pairs.append([doc.page_content, source, doc.metadata])
                references[CHUNK_RETRIEVER_NAME] = pairs

            if output_filename:
                if self.verbose:
                    print("📝 偵測到 output_filename，正在將結果保存到檔案...")
                self._save_report_to_markdown(
                    filename=output_filename,
                    question=original_question_input,
                    final_answer=beast_output,  # 保存最終格式化好的答案
                    evidence_manager=evidence_manager,  # 傳遞實例
                )
            yield (ReturnProcess.COMPLETION, beast_output, references)

            if stop_stage == Stage.BEAST:
                return

        finally:
            # =================================================================
            # --- 階段六：資源清理 ---
            # =================================================================
            evidence_manager.cleanup()
