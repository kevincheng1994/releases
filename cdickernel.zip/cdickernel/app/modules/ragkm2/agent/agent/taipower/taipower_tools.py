import ast
import difflib
import json
import os
import re
import shutil
import tempfile
import uuid
from typing import Any, Literal, Optional

# from langchain.chains.combine_documents.stuff import create_stuff_documents_chain
# from langchain.chains.combine_documents.reduce import create_reduce_documents_chain
# from operator import itemgetter
# from langchain.chains.combine_documents.stuff import create_stuff_documents_chain
# from langchain.chains.combine_documents.reduce import create_reduce_documents_chain
# from operator import itemgetter
from langchain.chains import MapReduceDocumentsChain, ReduceDocumentsChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from langchain.chains.llm import LLMChain
from langchain.chains.summarize import load_summarize_chain
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain_core.language_models import BaseLanguageModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool, Tool
from langchain_core.vectorstores import VectorStore

# --- 1. 常數定義 (Constants) ---

CHUNK_RETRIEVER_NAME = "ChunkRetriever"
ENTIRE_RETRIEVER_NAME = "EntireRetriever"
LIST_DOC_NAMES_NAME = "ListDocNames"
DOCUMENT_ROUTER_NAME = "DocumentRouter"

# --- 2. 系統級 Prompt (用於工具和鏈內部) ---

CUSTOM_SUMMARY_SYSTEM_PROMPT_TEMPLATE = """
<role>
You are an AI assistant that formats text into a summary. Your ONLY job is to follow the user's formatting rules with absolute, literal precision. You are not an analyst; you are a formatting machine.
</role>
<task>
You will receive the full text of a document and a set of user-defined instructions for the summary's structure.
You MUST generate a summary that STRICTLY and EXACTLY follows the structure provided in `<user_instructions>`.
</task>
<output_format_rules>
- You MUST use the exact titles, numbering, and order from the user's instructions.
- DO NOT invent, rename, or reorder any sections.
- DO NOT add any extra headers or commentary.
- The output language must be Traditional Chinese.
</output_format_rules>
<user_instructions>
{instructions}
</user_instructions>
"""

DEFAULT_SUMMARY_SYSTEM_PROMPT = """<role>
You are a specialized AI assistant for summarizing technical documents.
</role>
<task>
You will receive the full text of a document. Generate a Traditional-Chinese summary that strictly follows the below structure.
</task>
<instruction>
1. Output ONLY the five section headings and their summary text.
2. Do NOT print any instructions, conditions, or meta-comments.
3. Internal guidelines (invisible to user):
   - Background: ≤3 sentences
   - Core tech/arch: ≤3 bullet points
   - Key findings: ≤5 bullet points
   - Overall: ≤3 sentences
   - Future: ≤3 sentences
</instruction>
<default_summary_structure>
### 背景：
### 核心技術/架構：
### 主要論點/發現：
### 總體考慮：
### 未來方向：
</default_summary_structure>
"""

BEAST_MODE_SYSTEM_PROMPT = """
你是一名負責回答問題的專家。你會收到「問題」與「思考的過程」，請根據思考的過程回答問題。
<output format>
1. 無論如何都使用繁體中文，除了書名（文件名）以及專業名詞。
2. 當使用者有指定格式時 (例如在原始問題中提供了 '摘要的架構如下: ...')，Final Answer 請【嚴格地、一字不差地】使用該格式輸出。
3. 如果工具 (如 EntireRetriever) 已經返回了格式化的摘要，請直接使用該摘要作為 Final Answer。
4. 若沒有指定格式，且不是摘要問題，Final Answer 請以列表形式呈現。
5. 無需提及使用了哪個工具。
6. 當提到書名（文件名）時，都以 `[書名]` 表示，不要自行省略任何文字，副檔名也不要省略。
</output format>
"""

MARKDOWN_FORMATTER_SYSTEM_PROMPT = """
你是一位專門處理 Markdown 格式的助理。你會收到 Answer，請將 Answer 轉換為 Markdown 格式。
<output>
1. 不得修改任何字元，包括標點符號、空格及文件順序。
2. 僅進行格式化處理，不要新增自己的見解。
3. 不要提到你所作的任務。
4. 無論如何都使用繁體中文，除了書名（文件名）以及專業名詞。
</output>
"""

# --- 3. Pydantic 結構定義 ---


class InMemoryNotebook:
    """
    一個簡單的、存在於記憶體中的筆記本狀態管理器。

    這個類別的實例會與 TaipowerAgent 的實例生命週期綁定，
    從而為單次 `stream` 呼叫提供一個獨立的、臨時的筆記空間。
    它能讓 Agent 在多步驟的 ReAct 循環中，記錄、回顧和累積資訊。
    """

    def __init__(self):
        """初始化一個空的筆記本。"""
        # self.entries = []
        self.tasks = []
        self.completed_tasks = []

    def add_task(self, task: str) -> str:
        """向 Checklist 中添加一個新任務。"""
        if task not in self.tasks and task not in self.completed_tasks:
            self.tasks.append(task)
        return self.review_tasks()

    def complete_task(self, task: str) -> str:
        """將一個任務標記為完成。"""
        if task in self.tasks:
            self.tasks.remove(task)
            self.completed_tasks.append(task)
        return self.review_tasks()

    def review_tasks(self) -> str:
        """審閱當前的任務清單。"""
        if not self.tasks and not self.completed_tasks:
            return "任務清單是空的。"

        review = "--- 任務清單狀態 ---\n"
        if self.tasks:
            review += "⏳ 待辦任務：\n"
            for i, task in enumerate(self.tasks, 1):
                review += f"{i}. {task}\n"

        if self.completed_tasks:
            review += "✅ 已完成任務：\n"
            for i, task in enumerate(self.completed_tasks, 1):
                review += f"{i}. {task}\n"

        return review

    # def add(self, entry: dict) -> str:
    #     """
    #     向筆記本中添加一條新的筆記條目。

    #     Args:
    #         entry (dict): 一個包含筆記內容的字典，
    #                       應符合 NotebookEntry 的結構。

    #     Returns:
    #         str: 一個表示操作成功的確認訊息。
    #     """
    #     # 為了健壯性，可以加上對 entry 結構的基礎驗證
    #     if not isinstance(entry, dict) or "search_query" not in entry:
    #         return "錯誤：筆記條目格式不正確，必須是包含 'search_query' 鍵的字典。"

    #     self.entries.append(entry)
    #     return f"✅ 已添加筆記。當前共有 {len(self.entries)} 條記錄。"

    # def review(self) -> str:
    #     """
    #     讀取並格式化筆記本中的所有內容。

    #     Returns:
    #         str: 一個格式化好的、包含所有筆記的字串，
    #              供 Agent 在 `Observation` 中查看。
    #     """
    #     if not self.entries:
    #         return "📝 筆記本目前是空的。"

    #     # 將所有筆記條目格式化為人類和 LLM 都易於閱讀的格式
    #     review_text = f"📚 筆記本總覽 (共 {len(self.entries)} 條記錄)：\n\n"

    #     for i, entry in enumerate(self.entries, 1):
    #         review_text += f"--- 筆記 #{i} ---\n"
    #         review_text += f"🔍 搜索詞: {entry.get('search_query', '未提供')}\n"

    #         docs_found = entry.get("documents_found", [])
    #         review_text += f"📄 相關文件: {', '.join(docs_found) if docs_found else '無'}\n"

    #         review_text += f"💡 摘要與洞察: {entry.get('insights', '無')}\n"

    #         next_actions = entry.get("next_actions", [])
    #         if next_actions:
    #             review_text += f"➡️ 下一步建議: {', '.join(next_actions)}\n"

    #         review_text += "\n"

    #     return review_text

    def clear(self):
        """
        清空筆記本中的所有條目。
        這個方法在每次新的 `stream` 請求開始時被呼叫，
        以確保不同請求之間的記憶不會互相污染。
        """
        self.entries = []


class RAGQueryAnalyzer(BaseModel):
    """專門針對 GENERAL_RAG_QUERY 的深度分析"""

    retrieval_strategy: str = Field(
        description="推薦的檢索策略類型：EXACT_MATCH, SEMANTIC_SEARCH, HYBRID_BALANCED, MULTI_HOP"
    )
    confidence: float = Field(ge=0, le=1, description="策略推薦的信心度")
    query_complexity: str = Field(description="查詢複雜度評估：SIMPLE, MODERATE, COMPLEX")
    bm25_weight: float = Field(ge=0, le=1, description="BM25 搜尋權重")
    vector_weight: float = Field(ge=0, le=1, description="向量搜尋權重")
    reasoning: str = Field(description="策略選擇的理由")


class ChunkRetrieverSchema(BaseModel):
    query: str = Field(description="The query string to search for.")
    filter: Optional[dict] = Field(None, description="An optional metadata filter to apply.")


class NotebookEntry(BaseModel):
    """筆記本條目的數據結構"""

    search_query: str = Field(description="搜索的關鍵字")
    result_summary: str = Field(description="搜索結果的簡要總結")
    documents_found: list[str] = Field(description="找到的文件名列表")
    insights: str = Field(description="從這次搜索中獲得的洞察")
    next_actions: list[str] = Field(description="建議的下一步行動")


class NotebookToolSchema(BaseModel):
    """筆記本工具的輸入格式"""

    action: Literal["add", "review", "add_task", "complete_task", "review_tasks"] = Field(
        description="要執行的操作：'add'(添加筆記), 'review'(查看筆記), 'add_task'(新增任務), 'complete_task'(完成任務), 'review_tasks'(審閱任務清單)。"
    )
    entry: Optional[dict] = Field(None, description="當 action='add' 時，需要提供的筆記內容字典。")
    task: Optional[str] = Field(
        None, description="當 action='add_task' 或 'complete_task' 時，需要提供的任務描述字串。"
    )


class TaskCompleterInput(BaseModel):
    reasoning: str = Field(
        description="A brief summary explaining why all tasks are considered complete and what has been found."
    )


class EvidenceManager:
    """
    管理在 Agent 執行期間蒐集的證據 (chunks)，將其持久化到臨時檔案系統。
    每個 Agent 的 stream 實例都會擁有自己的一個獨立證據庫。
    """

    def __init__(self):
        # 創建一個唯一的臨時目錄來儲存這次請求的所有證據
        self.evidence_dir = tempfile.mkdtemp(prefix="agent_evidence_")
        self._seen_chunk_contents = set()
        print(f"🗂️ 證據管理器已初始化，臨時目錄位於: {self.evidence_dir}")

    def _is_highly_similar(self, new_chunk_content: str, threshold=0.9) -> bool:
        """使用已儲存的內容進行相似度比較。"""
        # 為了效率，我們這裡只比較新 chunk 和已存在於 _seen_chunk_contents 的內容
        # 這種方法雖然不是全局最優，但在大多數情況下是足夠好的近似
        for seen_content in self._seen_chunk_contents:
            similarity = difflib.SequenceMatcher(None, new_chunk_content, seen_content).ratio()
            if similarity > threshold:
                return True
        return False

    def get_all_evidence_as_docs(self) -> list[Document]:
        """
        讀取所有證據檔案，並將它們作為 Document 物件列表返回。
        這保留了元數據，非常適合後續處理。
        """
        evidence_docs = []
        # all_files = [f for f in os.listdir(self.evidence_dir) if f.endswith(".txt")]
        all_files = [f for f in os.listdir(self.evidence_dir) if f.endswith(".json")]

        for file_name in sorted(all_files):
            # 從檔案名稱解析回原始來源
            # 假設檔名格式是 '原始來源_uuid.txt'
            # parts = file_name.split("_")
            # original_source = parts[0] if len(parts) > 1 else "unknown_source.md"

            file_path = os.path.join(self.evidence_dir, file_name)

            try:
                with open(file_path, encoding="utf-8") as f:
                    # content = f.read()
                    data = json.load(f)
                    doc = Document(page_content=data["page_content"], metadata=data["metadata"])
                    # doc = Document(page_content=content, metadata={"source": original_source})
                    evidence_docs.append(doc)
            except (json.JSONDecodeError, KeyError) as e:
                print(f"⚠️ 讀取證據檔案 {file_name} 失敗: {e}，已跳過。")

        return evidence_docs

    def add_chunks(self, new_chunks: list[Document]) -> str:
        """將一批新的、不重複的 chunks 儲存為獨立的 .txt 檔案。"""
        added_count = 0
        for chunk in new_chunks:
            # 使用集合進行快速的精確去重檢查
            if chunk.page_content not in self._seen_chunk_contents:
                # 為了避免大量相似但不完全相同的內容，可以選擇性地增加相似度檢查
                # if not self._is_highly_similar(chunk.page_content):
                self._seen_chunk_contents.add(chunk.page_content)

                # metadata_str = json.dumps(chunk.metadata, ensure_ascii=False)

                # 創建檔案名稱
                source_name = chunk.metadata.get("source", "unknown").replace(os.path.sep, "_")
                file_name = f"{source_name}_{uuid.uuid4().hex[:8]}.json"
                file_path = os.path.join(self.evidence_dir, file_name)

                # 將 chunk 內容寫入檔案
                with open(file_path, "w", encoding="utf-8") as f:
                    # f.write(chunk.page_content)
                    json.dump(
                        {"page_content": chunk.page_content, "metadata": chunk.metadata},
                        f,
                        ensure_ascii=False,
                        indent=2,
                    )

                added_count += 1

        total_files = len(os.listdir(self.evidence_dir))
        return f"新增 {added_count} 則新證據。目前共蒐集 {total_files} 則證據。"

    def review_all_evidence(self) -> str:
        """讀取所有證據檔案，並將它們合併為一個大的 context 字串。"""
        all_files = [f for f in os.listdir(self.evidence_dir)]
        if not all_files:
            return "證據庫中沒有任何資料。"

        context = f"--- 蒐集到的相關資料 (共 {len(all_files)} 則) ---\n\n"
        for i, file_name in enumerate(sorted(all_files), 1):
            # 從檔案名稱解析回原始來源
            original_source = file_name.split("_")[0]
            file_path = os.path.join(self.evidence_dir, file_name)

            with open(file_path, encoding="utf-8") as f:
                content = f.read()

            context += f"--- 來源: [{original_source}] - 證據 #{i} ---\n"
            context += f"{content}\n\n"

        return context

    def get_evidence_count(self) -> int:
        """返回當前儲存的證據數量。"""
        return len(os.listdir(self.evidence_dir))

    def cleanup(self):
        """刪除臨時證據目錄及其所有內容。"""
        if os.path.exists(self.evidence_dir):
            shutil.rmtree(self.evidence_dir)
            print(f"🗑️ 已清理證據目錄: {self.evidence_dir}")


class SubQuestion(BaseModel):
    """代表一個從原始問題中分解出的、獨立且可執行的子問題。"""

    sub_query: str = Field(description="一個具體的、單一意圖的查詢語句。")
    required_entities: list[str] = Field(description="回答這個子問題所必需的關鍵實體。")


class QueryAnalysis(BaseModel):
    """對用戶查詢的全面分析，用於指導 Agent 的後續行為。"""

    rewritten_query: str = Field(
        description="根據對話歷史補全上下文後，一個獨立的、自包含的查詢。如果原始問題已經很完整，則此字段與原始問題相同。"
    )

    # 用於路由的 qtype
    qtype: Literal[
        "DECOMPOSED_RAG_QUERY", "SIMPLE_RAG_QUERY", "SUMMARIZE_DOCUMENT", "LIST_DOCUMENTS", "OUT_OF_SCOPE"
    ] = Field(description="將重寫後的查詢 (`rewritten_query`) 分類到最符合的類型。")

    target_entity: Optional[str] = Field(
        None,
        description="如果 `rewritten_query` 是針對一個被方括號 `[]` 包圍的特定實體（例如檔案名稱），則在此欄位中提取該實體的【確切名稱】（不含方括號）。如果查詢中沒有被方括號包圍的實體，則此欄位應為 null。",
    )

    custom_instructions: Optional[str] = Field(
        None,
        description="如果使用者在問題中提供了具體的格式化或摘要指令（例如，'摘要的架構如下...'），則在此欄位中提取該指令的完整文本。",
    )

    # 用於 RAG 查詢的詳細資訊
    sub_questions: list[SubQuestion] = Field(
        description="分解後的子問題列表。對於 SIMPLE_RAG_QUERY，此列表只包含一個元素，即原始問題本身。"
    )

    suggested_keywords: list[str] = Field(
        description="一個經過優化的關鍵字列表，建議 Agent 在執行檢索時優先使用。可以包含同義詞或擴展詞。"
    )

    suggested_approach: str = Field(
        description="一段自然語言描述的、建議性的解決方案或探索策略。例如：'請先處理綠線的部分，再處理棕線。最後，將兩者的預算進行比較。'"
    )

    answer_structure_suggestion: Optional[str] = Field(
        None,
        description="如果適用，提供一個建議的最終答案結構或大綱，指導 Agent 如何組織其 Final Answer。例如：'1. 綠線進度, 2. 棕線進度, 3. 預算對比分析'。",
    )

    reasoning: str = Field(default="", description="簡要總結並說明進行此完整分析（包括重寫、分類、分解和策略建議）的原因。")


class QueryCorrection(BaseModel):
    """用於檢查和修正使用者查詢格式的結構。"""

    is_correction_needed: bool = Field(description="判斷使用者的原始查詢格式是否需要修正。")
    corrected_query: str = Field(description="如果需要修正，則提供一個格式更佳的新查詢；如果不需要，則返回原始查詢。")
    correction_reason: str = Field(
        description="如果需要修正，用友善的語氣向使用者解釋原因；如果不需要，則簡單說明格式正確。"
    )


class SemanticAnalysisResult(BaseModel):
    """對原始用戶查詢進行語意分析後的結構化結果。"""

    primary_intent: str = Field(description="對用戶最核心、最主要的意圖的簡潔總結。")
    query_type: str = Field(
        description="查詢的類型，例如：'事實查詢 (Fact-Finding)', '比較分析 (Comparison)', '摘要總結 (Summarization)', '因果關係 (Causality)'。"
    )
    sub_questions: list[SubQuestion] = Field(
        description="從原始問題中分解出的子問題列表。如果原始問題很簡單，可以只有一個子問題。"
    )
    keywords_for_retrieval: list[str] = Field(description="建議用於初始檢索的核心關鍵字列表，應包含同義詞或擴展詞。")


# --- 4. 輔助函式 ---


def _parse_tool_input(input_str: str, default_key: str = "query") -> dict[str, Any]:
    """
    穩健地解析 Agent 傳來的工具輸入字串。
    它能處理 Python 字典字面量、簡單的 key='value' 格式，以及純字串。

    Args:
        input_str (str): 來自 Agent 的 Action Input。
        default_key (str): 當輸入是純字串時，應該使用的預設鍵名。
                           預設為 'query'。

    Returns:
        一個解析後的字典。
    """
    input_str = str(input_str).strip()  # 確保是字串並去除首尾空白

    # LLM 有時會在 Action Input 後附加 Observation 模板文字，截斷它
    if "\nObservation:" in input_str:
        input_str = input_str.split("\nObservation:")[0].strip()

    try:
        parsed = ast.literal_eval(input_str)
        if isinstance(parsed, dict):
            return parsed
    except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
        pass

    try:
        parsed_args = {key: value for key, _, value in re.findall(r"(\w+)=([\'\"])(.*?)\2", input_str)}
        if parsed_args:
            return parsed_args
    except Exception:
        pass

    return {default_key: input_str}


# --- 5. 核心鏈與工具創建函數 ---


def create_markdown_chain(llm):
    """創建一個將輸入轉換為 Markdown 格式的 Chain。"""
    prompt = ChatPromptTemplate.from_messages([("system", MARKDOWN_FORMATTER_SYSTEM_PROMPT), ("user", "{input}")])
    return prompt | llm | StrOutputParser()


def create_beast_chain(llm):
    """創建 Beast Mode Chain，用於根據思考過程生成最終答案。"""
    prompt = ChatPromptTemplate.from_messages([("system", BEAST_MODE_SYSTEM_PROMPT), ("user", "{input}")])
    return prompt | llm | StrOutputParser()


def create_query_analyzer_chain(llm):
    """
    建立一個全面的、多步驟的查詢分析器chain。
    它將原始使用者輸入和對話歷史，轉換為一個結構化的、可供 Agent 執行的完整行動綱領。
    """
    analysis_description = """你是一位頂級的 AI 系統分析師，負責將原始、口語化的用戶輸入，轉換為精確、結構化的機器可讀指令。

**你必須嚴格遵循以下【六步驟分析流程】：**

1. **查詢重寫 (Query Rewriting)**
-   仔細閱讀【最新的使用者問題】和【對話歷史】。
-   如果最新的問題是獨立的（例如：「請摘要 [文件A.pdf]」），則直接使用它。
-   如果最新的問題依賴於上下文（例如：「那份報告呢？」 或 「和綠線比較一下」），你必須將其改寫成一個**完整的、自包含的**問題。
-   將最終的、完整的查詢填入 `rewritten_query` 欄位。

2. **意圖分類 (Intent Classification)**
-   基於 `rewritten_query`，判斷使用者的最高層級意圖，並選擇一個最適合的 `qtype`。
-   `OUT_OF_SCOPE`: 純粹無關閒聊（例如：「你好」、「今天天氣如何」）。**重要：若對話歷史不為空，且最新問題是對先前回答的後續追問或格式調整要求（例如：「條列一下」、「再詳細說明」、「換個方式」），絕對不能判為 OUT_OF_SCOPE，應視為 SIMPLE_RAG_QUERY。**
-   `LIST_DOCUMENTS`: 只想知道有哪些檔案。
-   `SUMMARIZE_DOCUMENT`: 明確要求對**單一具名文件**進行**整體**摘要。
-   `SIMPLE_RAG_QUERY`: 一個單意圖、無需分解的 RAG 查詢。

3. **提取目標實體與自訂指令 (Entity & Instruction Extraction)**
-   如果 `qtype` 是 `SUMMARIZE_DOCUMENT`：
-   你【必須】從 `rewritten_query` 中提取檔案名稱，填入 `target_entity`。
-   同時，檢查 `rewritten_query` 是否包含摘要格式的指令（例如，「摘要的架構如下...」或「分以下幾點說明...」）。如果包含，你【必須】將完整的指令文本提取出來，填入 `custom_instructions` 欄位。

4. **查詢分解 (Query Decomposition)**
-   如果 `qtype` 是 `SIMPLE_RAG_QUERY`，則 `sub_questions` 清單只包含一個元素，其 `sub_query` 就是 `rewritten_query`。
-   如果 `qtype` 是 `DECOMPOSED_RAG_QUERY`，則**必須**將 `rewritten_query` 拆分為多個邏輯上獨立的子問題。
-   對於其他 `qtype`，`sub_questions` 清單可以為空。
-   對每個子問題，提取其核心的 `required_entities`。

5.  **關鍵字擴充 (Keyword Expansion)**
-   基於所有的 `sub_questions`，產生一個用於高效率檢索的 `suggested_keywords` 清單。應包含核心詞、同義詞和相關術語（例如，`垃圾` -> `廢棄物`）。

6.  **策略與結構建議 (Strategy & Structure Suggestion)**
-   **`suggested_approach`**: 根據子問題的邏輯關係，用自然語言描述一個清晰的、分步驟的執行策略。
-   **`answer_structure_suggestion`**: 預測一個好的答案應該包含哪些部分，並提供一個 Markdown 格式的大綱建議。

7. **最後，用 `reasoning` 欄位簡單總結你的整個分析過程。 **
    """

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", analysis_description),
            (
                "user",
                """
        請根據【對話歷史】與【最新的使用者問題】，執行六步驟分析流程。

        【對話歷史】
        {chat_history}

        【最新的使用者問題】
        {input}
        """,
            ),
        ]
    )

    return prompt | llm.with_structured_output(QueryAnalysis, method="function_calling")


def create_rag_query_analyzer_chain(llm):
    """創建 RAG 查詢分析器"""
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """
        你是 RAG 檢索策略專家。針對已確認是 GENERAL_RAG_QUERY 的問題，分析最佳檢索策略。

        **策略分類標準：**

        1. **EXACT_MATCH** - 精確匹配優先
           - 包含明確的代號、編號、型號（如：ALT-001、Section 4.2.1、條文編號）
           - 專有名詞、技術規格、具體的法規條文
           - 權重配置：bm25_weight=0.6, vector_weight=0.4

        2. **ENTITY_FOCUSED_HYBRID** - 實體為主的混合搜索
           - **當查詢包含【專有名詞、技術術語、機關名稱、法規名稱】時使用**，這些詞語的核心意義不變，但措辭和順序可能有細微變化。(例如: '歲入審定總額', '桃園捷運綠線')
           - 權重配置：bm25_weight=0.6, vector_weight=0.4

        3. **SEMANTIC_SEARCH** - 語義理解優先
           - 概念性問題、趨勢分析、比較性查詢
           - 模糊的描述性問題、抽象概念
           - 權重配置：bm25_weight=0.2, vector_weight=0.8

        4. **HYBRID_BALANCED** - 平衡策略
           - 既需要精確匹配又需要語義理解
           - 中等複雜度的綜合性問題
           - 權重配置：bm25_weight=0.5, vector_weight=0.5

        5. **MULTI_HOP** - 多步推理
           - 需要跨多個文件整合信息
           - 複雜的因果關係分析
           - 權重配置：bm25_weight=0.4, vector_weight=0.6

        **複雜度評估：**
        - SIMPLE: 單一概念，直接查詢
        - MODERATE: 2-3個概念，需要一定整合
        - COMPLEX: 多概念，需要深度推理

        **輸出要求：**
        - retrieval_strategy: 必須是上述四種策略之一
        - confidence: 0-1之間的數值，表示策略選擇的信心度
        - key_entities: 字符串列表，可以為空
        - query_complexity: 必須是 SIMPLE, MODERATE, COMPLEX 之一
        - bm25_weight: 0-1之間的數值，BM25 關鍵字搜尋的權重
        - vector_weight: 0-1之間的數值，向量語義搜尋的權重（兩權重和為1.0）
        - reasoning: 詳細說明為何選擇此策略的推理過程

        請仔細分析問題特徵，給出精確的策略建議和詳細的推理過程。
        """,
            ),
            ("user", "分析以下 RAG 查詢：{query}"),
        ]
    )

    return prompt | llm.with_structured_output(RAGQueryAnalyzer, method="function_calling")


# ----------------------------  模組層級常數  ----------------------------
MAP_CHUNK_SIZE = 8_000
MAP_CHUNK_OVERLAP = 400
TOKEN_MAX = 100_000  # ReduceDocumentsChain 內部 collapse 閾值
# -----------------------------------------------------------------------


# ----------------------------  模組層級常數  ----------------------------
MAP_CHUNK_SIZE = 8_000
MAP_CHUNK_OVERLAP = 400
TOKEN_MAX = 100_000  # ReduceDocumentsChain 內部 collapse 閾值
# -----------------------------------------------------------------------


def create_entire_retriever_tool(llm: BaseLanguageModel, vectorstore: VectorStore) -> StructuredTool:
    """
    建立「整份文件摘要」工具。
    支援兩種模式：
        1. 自訂格式 → refine chain
        2. 預設格式 → map-reduce chain (新 Runnable 寫法)
    """

    class EntireRetrieverToolSchema(BaseModel):
        """Input schema for the EntireRetriever tool."""

        doc_name: str = Field(
            ...,
            description="The full, exact name of the document to be summarized, e.g., 'document_name.pdf'.",
        )
        instructions: Optional[str] = Field(
            None,
            description="Optional. Specific user-provided instructions on how to format the summary.",  # 自訂摘要格式
        )

    # def _load_doc_by_title(title: str) -> list[Document]:
    #     """依 title 欄位精準撈取全文並切分"""
    #     exact_filter = {"title": title}
    #     resp = vectorstore.get(where=exact_filter, include=["documents"])
    #     if not resp or not resp.get("documents"):
    #         raise FileNotFoundError(f"找不到文件 '{title}'")

    #     full_text = "\n".join(resp["documents"])
    #     splitter = RecursiveCharacterTextSplitter(
    #         chunk_size=MAP_CHUNK_SIZE,
    #         chunk_overlap=MAP_CHUNK_OVERLAP,
    #     )
    #     return [Document(page_content=chk) for chk in splitter.split_text(full_text)]

    # def _build_refine_chain(instructions: str):
    #     """Refine 模式：自訂格式"""
    #     initial = ChatPromptTemplate.from_template(
    #         CUSTOM_SUMMARY_SYSTEM_PROMPT_TEMPLATE.format(instructions=instructions)
    #         + "\n\n<document_content>\n{text}\n</document_content>"
    #     )
    #     refine = ChatPromptTemplate.from_template(
    #         "Your job is to produce a final summary that adheres to the user's specified structure.\n"
    #         f"<user_instructions>\n{instructions}\n</user_instructions>\n"
    #         "You have an existing summary:\n<existing_summary>\n{existing_answer}\n</existing_summary>\n"
    #         "Given the new context below, refine the summary.\n<new_context>\n{text}\n</new_context>"
    #     )
    #     # load_summarize_chain 底層已改用 Runnable；直接呼叫即可
    #     return load_summarize_chain(
    #         llm,
    #         chain_type="refine",
    #         question_prompt=initial,
    #         refine_prompt=refine,
    #     )

    # def _build_map_reduce_chain():
    #     """Map-Reduce 模式：預設五大段落格式"""
    #     map_prompt = ChatPromptTemplate.from_template(
    #         DEFAULT_SUMMARY_SYSTEM_PROMPT
    #         + "\n\nSummarize this part of the document:\n<document_content>\n{text}\n</document_content>"
    #     )
    #     combine_prompt = ChatPromptTemplate.from_template(
    #         DEFAULT_SUMMARY_SYSTEM_PROMPT
    #         + "\n\nSynthesize these summaries into a single, final summary:\n<summaries_to_combine>\n{text}\n</summaries_to_combine>"
    #     )

    #     # Map chain
    #     map_chain = map_prompt | llm | StrOutputParser()

    #     # Reduce chain (Stuff + Collapse)
    #     combine_chain = combine_prompt | llm | StrOutputParser()
    #     combine_docs_chain = create_stuff_documents_chain(
    #         combine_chain,
    #         document_prompt=PromptTemplate.from_template("{page_content}"),
    #         document_variable_name="text",
    #     )
    #     reduce_chain = create_reduce_documents_chain(
    #         combine_docs_chain,
    #         collapse_chain=combine_docs_chain,
    #         token_max=TOKEN_MAX,
    #     )

    #     # 完整 Map-Reduce
    #     return (
    #         {
    #             "input_documents": lambda x: x["input_documents"],
    #             "map_steps": map_chain.map(),  # 對每個 chunk 先 map
    #         }
    #         | {
    #             "doc_summaries": itemgetter("map_steps"),
    #             "input_documents": itemgetter("input_documents"),
    #         }
    #         | reduce_chain
    #     )
    # def summary_func(**kwargs) -> str:
    #     try:
    #         data = EntireRetrieverToolSchema(**kwargs)
    #         title = os.path.splitext(data.doc_name.strip())[0]

    #         docs = _load_doc_by_title(title)
    #         chain = (
    #             _build_refine_chain(data.instructions)
    #             if data.instructions
    #             else _build_map_reduce_chain()
    #         )

    #         result = chain.invoke({"input_documents": docs})
    #         return result.get("output_text") or "摘要生成失敗。"

    #     except FileNotFoundError as e:
    #         return str(e)
    #     except Exception as e:
    #         import traceback
    #         traceback.print_exc()
    #         return f"摘要生成錯誤：{e}"
    # return StructuredTool(
    #     name="EntireRetriever",
    #     description="針對整份文件產生摘要",
    #     args_schema=EntireRetrieverToolSchema,
    #     func=summary_func,
    # )

    # def summary_func(doc_name: str, instructions: Optional[str] = None) -> str:
    def summary_func(**kwargs) -> str:
        data = EntireRetrieverToolSchema(**kwargs)
        doc_name = data.doc_name
        instructions = data.instructions
        try:
            # 1. 直接使用傳入的、已經被清理過的參數
            if not doc_name:
                return "錯誤：必須提供 'doc_name' 參數。"

            cleaned_doc_name = doc_name.strip()
            title_only, _ = os.path.splitext(cleaned_doc_name)

            # 2. 檢索文件的所有 chunks
            exact_filter = {"title": title_only}
            ret = vectorstore.get(where=exact_filter, include=["documents"])
            if not ret or not ret.get("documents"):
                return f"找不到文件 '{cleaned_doc_name}'，請確認文件名是否完全正確。"

            document_contents = [str(doc) for doc in ret["documents"] if doc is not None and str(doc).strip()]
            if not document_contents:
                return f"文件 '{cleaned_doc_name}' 內容為空或無效。"

            full_text = "\n".join(ret["documents"])

            text_splitter = RecursiveCharacterTextSplitter(chunk_size=8000, chunk_overlap=400)
            docs = [Document(page_content=chunk) for chunk in text_splitter.split_text(full_text)]
            if not docs:
                return f"文件 '{cleaned_doc_name}' 內容處理後為空，無法摘要。"

            chain = None
            if instructions:
                # --- Refine 策略 ---
                initial_prompt = ChatPromptTemplate.from_template(
                    CUSTOM_SUMMARY_SYSTEM_PROMPT_TEMPLATE.format(instructions=instructions)
                    + "\n\n<document_content>\n{text}\n</document_content>"
                )
                refine_prompt = ChatPromptTemplate.from_template(
                    f"Your job is to produce a final summary that adheres to the user's specified structure.\n<user_instructions>\n{instructions}\n</user_instructions>\nYou have an existing summary:\n<existing_summary>\n{{existing_answer}}\n</existing_summary>\nGiven the new context below, refine the summary.\n<new_context>\n{{text}}\n</new_context>"
                )
                chain = load_summarize_chain(
                    llm,
                    chain_type="refine",
                    question_prompt=initial_prompt,
                    refine_prompt=refine_prompt,
                )
            else:
                # --- Map-Reduce 策略 ---
                map_prompt = ChatPromptTemplate.from_template(
                    DEFAULT_SUMMARY_SYSTEM_PROMPT
                    + "\n\nSummarize this part of the document:\n<document_content>\n{text}\n</document_content>"
                )
                map_chain = LLMChain(llm=llm, prompt=map_prompt)

                combine_prompt = ChatPromptTemplate.from_template(
                    DEFAULT_SUMMARY_SYSTEM_PROMPT
                    + "\n\nSynthesize these summaries into a single, final summary:\n<summaries_to_combine>\n{text}\n</summaries_to_combine>"
                )
                combine_chain_core = LLMChain(llm=llm, prompt=combine_prompt)

                combine_documents_chain = StuffDocumentsChain(
                    llm_chain=combine_chain_core, document_variable_name="text"
                )
                reduce_documents_chain = ReduceDocumentsChain(
                    combine_documents_chain=combine_documents_chain,
                    collapse_documents_chain=combine_documents_chain,  # 用于处理单个摘要过长的情况
                    token_max=100000,
                )

                chain = MapReduceDocumentsChain(
                    llm_chain=map_chain,
                    reduce_documents_chain=reduce_documents_chain,
                    document_variable_name="text",
                )
                # chain = load_summarize_chain(
                #     llm,
                #     chain_type="map_reduce",
                #     map_prompt=map_prompt,
                #     combine_prompt=combine_prompt,
                # )

            summary_result = chain.invoke({"input_documents": docs})
            return summary_result.get("output_text", "摘要生成失敗。")

        except Exception as e:
            import traceback

            print("--- An exception occurred in summary_func ---")
            print(traceback.format_exc())
            print("---------------------------------------------")
            return f"在生成摘要過程中發生嚴重錯誤: {e}"

    # return Tool.from_function(
    #     func=summary_func,
    #     name=ENTIRE_RETRIEVER_NAME,
    #     description="Use this tool ONLY for summarizing an ENTIRE document based on its name. It can handle custom formatting instructions.",
    #     args_schema=EntireRetrieverToolSchema,
    # )
    return StructuredTool(
        name="EntireRetriever",
        description="針對整份文件產生摘要",
        args_schema=EntireRetrieverToolSchema,
        func=summary_func,
    )


def create_conscise_summary_reasoing_chain(llm):
    """創建一個鏈 (Chain)，用於根據 Agent 的完整思考過程生成一個簡潔的最終答案。"""
    system_prompt = """
You are an expert synthesizer. Your task is to generate a final, concise answer based on the user's question and the provided reasoning process from an AI agent.
<reasoning_process>
{intermediate_thoughts}
</reasoning_process>
<output_rules>
1.  Synthesize the information from the reasoning process to directly answer the original question.
2.  The final answer MUST be in Traditional Chinese.
3.  The final answer MUST be a single paragraph. Do not use bullet points or lists.
4.  Keep the answer concise and under 300 characters.
</output_rules>
"""
    prompt = ChatPromptTemplate.from_messages([("system", system_prompt), ("user", "Original Question: {input}")])
    return prompt | llm | StrOutputParser()


def detect_search_failure_signals(observation: str) -> bool:
    """
    檢測搜索失敗的信號
    """
    failure_keywords = [
        "找不到",
        "未找到",
        "沒有找到",
        "無法找到",
        "資料庫中找不到",
        "不存在",
        "沒有相關",
        "無相關",
        "查無",
        "搜索無結果",
    ]

    observation_lower = observation.lower()
    return any(keyword in observation_lower for keyword in failure_keywords)


def extract_key_terms(query: str) -> list[str]:
    """
    從查詢中提取關鍵詞，用於重試時簡化搜索
    """
    import re

    import jieba

    # 去除常見的停用詞
    stop_words = {"的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "這", "中", "要", "來"}

    # 使用結巴分詞
    words = list(jieba.cut(query))

    # 過濾停用詞和標點符號
    key_terms = []
    for word in words:
        if len(word) > 1 and word not in stop_words and not re.match(r"^[^\w]+$", word):
            key_terms.append(word)

    return key_terms[:3]  # 返回前3個關鍵詞


def create_chunk_retriever_tool(retriever, vectorstore, evidence_manager: EvidenceManager) -> Tool:
    """創建一個智慧型工具，能自動為不同類型的查詢選擇最佳檢索策略。"""

    def smart_retriever_invoke(tool_input: str | dict) -> str:
        try:
            # 解析輸入
            if isinstance(tool_input, str):
                parsed_input = _parse_tool_input(tool_input, default_key="query")
            elif isinstance(tool_input, dict):
                parsed_input = tool_input
            else:
                return f"錯誤：未知的工具輸入類型: {type(tool_input)}"

            query = parsed_input.get("query", "")
            filter_dict = parsed_input.get("filter")

            if not query:
                return "錯誤：缺少 'query' 參數。"

            # 執行檢索
            docs: list[Document] = retriever.invoke(input=query, filter=filter_dict)

            if not docs:
                return "資料庫中找不到與查詢相關的任何文件。"

            storage_confirmation = evidence_manager.add_chunks(docs)

            summary_feedback = (
                f"檢索成功，找到 {len(docs)} 個相關片段。"
                f" {storage_confirmation}"  # storage_confirmation 包含了新增了多少，總共有多少的信息
            )

            # # 在應用層進行後處理和精確驗證
            # normalized_query = "".join(query.split()).lower()
            # perfect_matches = []

            # for doc in docs:
            #     if not (hasattr(doc, "page_content") and hasattr(doc, "metadata")):
            #         continue

            #     normalized_content = "".join(doc.page_content.split()).lower()
            #     if normalized_query in normalized_content:
            #         snippet = f"在文件 [{doc.metadata.get('source', '未知來源')}] 中【精準定位】到以下内容：\n---\n{doc.page_content}\n---"
            #         perfect_matches.append(snippet)

            # if perfect_matches:
            #     return "【已找到精確匹配】\n" + "\n".join(perfect_matches)
            # else:
            #     most_relevant_doc = docs[0]
            #     source = most_relevant_doc.metadata.get("source", "未知來源")
            #     content = most_relevant_doc.page_content

            #     # 檢查內容相關性
            #     # if len(content.strip()) < 50:  # 內容太短可能不相關
            #     #     return f"在文件 [{source}] 中找到疑似相關內容，但信息較少。建議嘗試其他關鍵字搜索。"

            #     return (
            #         f"【未找到精確匹配】未能直接找到關鍵字 '{query}'，但根據語意分析，"
            #         f"在檔案 [{source}] 中找到以下【最相關】的內容：\n---\n{content}\n---"
            #     )

            summary_feedback = f"檢索到 {len(docs)} 個相關片段。{storage_confirmation}"

            return summary_feedback
        except Exception as e:
            return f"檢索過程發生錯誤: {str(e)}"

    return Tool(
        name=CHUNK_RETRIEVER_NAME,
        func=smart_retriever_invoke,
        args_schema=ChunkRetrieverSchema,
        description="""
        使用這個工具檢索文件中的特定內容片段。

        🎯 **輸入格式:**
        - 全域搜索: {'query': '搜索關鍵字'}
        - 限定文件: {'query': '搜索關鍵字', 'filter': {'source': '檔名.pdf'}}

        ⚡ **搜索建議:**
        - 使用具體、準確的關鍵字
        - 避免過於寬泛的搜索詞
        - 如果搜索失敗，嘗試簡化關鍵字

        🔍 **結果判斷:**
        - 找到精確匹配時會標註【精準定位】
        - 找到相關內容時會標註【最相關】
        - 找不到任何結果時會提示"找不到相關文件"
        """,
    )


def create_list_doc_names_tool(names: list[str]) -> Tool:
    """創建一個列出資料庫中所有文件名稱的工具。"""

    # 【修正】函式簽名必須能接收一個參數，即使未使用。
    def list_doc_names(query: str = "") -> str:
        if not names:
            return "資料庫中目前沒有文件。"
        doc_list = [f"- [{name}]" for name in names]
        return "資料庫包含的文件名稱如下：\n" + "\n".join(doc_list)

    return Tool(
        name=LIST_DOC_NAMES_NAME,
        func=list_doc_names,
        description="Use this tool when the user asks for a list of all available documents in the database.",
    )


def create_notebook_tool(notebook: InMemoryNotebook) -> Tool:
    """創建筆記本工具，用於記錄搜索歷史和規劃下一步"""

    # 使用類變量來保存筆記本狀態（在實際部署中可能需要使用持久化存儲）
    # notebook_storage = []

    # def notebook_invoke_wrapper(action: str, entry: Optional[dict] = None, task: Optional[str] = None) -> str:
    def notebook_invoke_wrapper(tool_input: dict) -> str:
        try:
            parsed_input = {}
            if isinstance(tool_input, str):
                # _parse_tool_input 能處理 JSON 字串和 key='value' 字串
                parsed_input = _parse_tool_input(tool_input, default_key="action")
            elif isinstance(tool_input, dict):
                parsed_input = tool_input
            else:
                return f"錯誤：接收到未知的工具輸入類型: {type(tool_input)}"

            action = parsed_input.get("action")
            task_data = parsed_input.get("task")

            if action == "add_task":
                if not task_data or not isinstance(task_data, str):
                    return "錯誤：'add_task' 操作必須提供一個 'task' 字串。"
                return notebook.add_task(task_data)
            elif action == "complete_task":
                if not task_data or not isinstance(task_data, str):
                    return "錯誤：'complete_task' 操作必須提供一個 'task' 字串。"
                return notebook.complete_task(task_data)
            elif action == "review_tasks":
                return notebook.review_tasks()
            # elif action == "add":
            #     entry_data = parsed_input.get("entry")
            #     if not entry_data or not isinstance(entry_data, dict):
            #         return "錯誤：'add' 操作必須提供一個有效的 'entry' 字典。"
            #     return notebook.add(entry_data)
            # elif action == "review":
            #     return notebook.review()
            else:
                return f"錯誤：未知的 action '{action}'。"

        except Exception as e:
            return f"筆記本工具在處理輸入時發生錯誤: {e}"

    return Tool(
        name="Notebook",
        func=notebook_invoke_wrapper,
        description="""一個具備筆記記錄和任務清單 (Checklist) 管理雙重功能的強大工具。

    **【核心功能】**
    - **任務管理 (Task Management)**: 用於規劃、追蹤和完成多步驟的解決方案。
    - **日誌記錄 (Log Recording)**: 用於記錄每次行動的發現、洞察和結果。

    **【可用操作 (`action`) 與輸入格式 (`Action Input`)】**

    **1. 添加任務到 Checklist:**
       - `action`: "add_task"
       - **範例**: `Notebook(action="add_task", task="在文件 A 中搜索『關鍵詞 X』")`

    **2. 將任務標記為完成:**
       - `action`: "complete_task"
       - **範例**: `Notebook(action="complete_task", task="在文件 A 中搜索『關鍵詞 X』")`

    **3. 審閱當前任務清單:**
       - `action`: "review_tasks"
       - **範例**: `Notebook(action="review_tasks")`
    """,
    )


def create_task_completer_tool() -> Tool:
    """
    創建一個特殊的工具，Agent 在完成所有證據蒐集任務後，必須呼叫此工具來結束 ReAct 迴圈。
    """

    def _complete(reasoning: str):
        return f"All tasks are complete. Final synthesis can now begin. Summary of findings: {reasoning}"

    return Tool(
        name="TaskCompleter",
        func=_complete,
        description="""CRITICAL: You MUST call this tool when you have finished all tasks from your notebook and believe you have gathered enough evidence. This signals the end of your search phase. The input should be a summary of your findings.""",
        args_schema=TaskCompleterInput,
    )


# 這是預留feedback的回應審核
# def create_final_synthesis_chain(llm):
#     """
#     創建一個鏈，它會接收【原始問題】、【初步答案】、【所有原始證據】和【建議關鍵字】，
#     進行最終的審查、強化和主題對焦，生成最終的權威報告。
#     """
#     system_prompt = """你是一位「頂級 AI 總編輯兼事實核查員」。
# 你的唯一任務：依據【所有原始證據】，對【原始問題】與【初步答案】進行「五階段審查強化」，輸出一份「完美、切題、完全可考證」的最終 Markdown 報告。

# **五階段審查優先順序（務必依序執行）**
# 1. **切題性審查（Relevance）**
#    - 確認【初步答案】是否「**全部**」回應【原始問題】的每一個面向。
#    - 若有遺漏 → 以【原始問題】為主軸補齊，並在報告開頭用「🎯 補充回應」區塊標示。

# 2. **事實核查（Factual Accuracy）**
#    - 逐句比對【初步答案】與【所有原始證據】。
#    - **任何找不到直接支援的句子 → 刪除或重寫**；**任何與證據衝突 → 立即修正**。
#    - 修正後請在該段落末加註「✅ 已核查」。

# 3. **關鍵字對焦（Keyword Focus）**
#    - 以【建議關鍵字】為「尋寶線索」，主動在【所有原始證據】中撈出相關段落。
#    - 若關鍵字概念未被充分涵蓋 → 擴寫並標註「🔑 關鍵字強化」。

# 4. **完整性補強（Completeness）**
#    - 檢查【所有原始證據】是否還有數據、範例、細節能讓答案更豐富 → 補充進去並標註「📈 完整性加值」。

# 5. **結構與流暢度（Structure & Flow）**
#    - 保留【初步答案】原有優點（總結、標題層次）。
#    - 重新組織段落，使邏輯遞進、閱讀順暢。
#    - **輸出唯一格式：Markdown**（含多層清單、表格、粗斜體等）。

# **硬性輸出規則（不可違反）**
# - 每句話都**必須**能在【所有原始證據】找到直接支援。
# - 最終報告要**直接且全面**回答【原始問題】。
# - 語言：**繁體中文**。
# - 格式：**Markdown**。
# - 若無建議關鍵字，請忽略「🔑 關鍵字強化」區塊。

# **模板變數（調用時替換）**

# - `{original_question}` → 【原始問題】
# - `{context}` → 【所有原始證據】
# - `{suggested_keywords}` → 【建議關鍵字】（可為空）
# - `{draft_answer}` → 【初步答案】

# ---
# # 最終核查報告

# ## 🎯 補充回應（若有）
# ...

# ## ✅ 已核查內容
# ...

# ## 🔑 關鍵字強化（若有）
# ...

# ## 📈 完整性加值（若有）
# ...

# ## 主體報告
# ...
# ---
# """
#     prompt = ChatPromptTemplate.from_messages(
#         [
#             ("system", system_prompt),
#             # 引入 Agent 的初步答案作為 user message
#             (
#                 "user",
#                 """
# 請根據以上規則，審查並強化以下這份【初步答案】，確保它能完美地回答【原始問題】，並充分利用【建議關鍵字】作為線索。

# ---
# 【原始問題】
# {original_question}
# ---
# 【建議關鍵字】
# {suggested_keywords}
# ---
# 【初步答案】
# {draft_answer}
# ---
# """,
#             ),
#         ]
#     )
#     return prompt | llm | StrOutputParser()

# 這是預留feedback的回應審核
# def create_final_synthesis_chain(llm):
#     """
#     創建一個鏈，它會接收【原始問題】、【初步答案】、【所有原始證據】和【建議關鍵字】，
#     進行最終的審查、強化和主題對焦，生成最終的權威報告。
#     """
#     system_prompt = """你是一位「頂級 AI 總編輯兼事實核查員」。
# 你的唯一任務：依據【所有原始證據】，對【原始問題】與【初步答案】進行「五階段審查強化」，輸出一份「完美、切題、完全可考證」的最終 Markdown 報告。

# **五階段審查優先順序（務必依序執行）**
# 1. **切題性審查（Relevance）**
#    - 確認【初步答案】是否「**全部**」回應【原始問題】的每一個面向。
#    - 若有遺漏 → 以【原始問題】為主軸補齊，並在報告開頭用「🎯 補充回應」區塊標示。

# 2. **事實核查（Factual Accuracy）**
#    - 逐句比對【初步答案】與【所有原始證據】。
#    - **任何找不到直接支援的句子 → 刪除或重寫**；**任何與證據衝突 → 立即修正**。
#    - 修正後請在該段落末加註「✅ 已核查」。

# 3. **關鍵字對焦（Keyword Focus）**
#    - 以【建議關鍵字】為「尋寶線索」，主動在【所有原始證據】中撈出相關段落。
#    - 若關鍵字概念未被充分涵蓋 → 擴寫並標註「🔑 關鍵字強化」。

# 4. **完整性補強（Completeness）**
#    - 檢查【所有原始證據】是否還有數據、範例、細節能讓答案更豐富 → 補充進去並標註「📈 完整性加值」。

# 5. **結構與流暢度（Structure & Flow）**
#    - 保留【初步答案】原有優點（總結、標題層次）。
#    - 重新組織段落，使邏輯遞進、閱讀順暢。
#    - **輸出唯一格式：Markdown**（含多層清單、表格、粗斜體等）。

# **硬性輸出規則（不可違反）**
# - 每句話都**必須**能在【所有原始證據】找到直接支援。
# - 最終報告要**直接且全面**回答【原始問題】。
# - 語言：**繁體中文**。
# - 格式：**Markdown**。
# - 若無建議關鍵字，請忽略「🔑 關鍵字強化」區塊。

# **模板變數（調用時替換）**

# - `{original_question}` → 【原始問題】
# - `{context}` → 【所有原始證據】
# - `{suggested_keywords}` → 【建議關鍵字】（可為空）
# - `{draft_answer}` → 【初步答案】

# ---
# # 最終核查報告

# ## 🎯 補充回應（若有）
# ...

# ## ✅ 已核查內容
# ...

# ## 🔑 關鍵字強化（若有）
# ...

# ## 📈 完整性加值（若有）
# ...

# ## 主體報告
# ...
# ---
# """
#     prompt = ChatPromptTemplate.from_messages(
#         [
#             ("system", system_prompt),
#             # 引入 Agent 的初步答案作為 user message
#             (
#                 "user",
#                 """
# 請根據以上規則，審查並強化以下這份【初步答案】，確保它能完美地回答【原始問題】，並充分利用【建議關鍵字】作為線索。

# ---
# 【原始問題】
# {original_question}
# ---
# 【建議關鍵字】
# {suggested_keywords}
# ---
# 【初步答案】
# {draft_answer}
# ---
# """,
#             ),
#         ]
#     )
#     return prompt | llm | StrOutputParser()


def create_final_synthesis_chain(llm):
    """
    創建一個鏈，它會接收【原始問題】、【初步答案】、【所有原始證據】和【建議關鍵字】，
    進行最終的審查、強化和主題對焦，生成最終的權威報告。
    """
    system_prompt = """<role>
你是親切且專業的 AI 報告編輯，專為「一般讀者」潤稿與補充。
</role>
<task>
根據「原始問題」「初步答案」「所有參考段落」，產出「易讀、完整」的最終報告。
</task>
<input>
原始問題：{original_question}
參考資料（已審核）：{all_evidence}
</input>
<instructions>
1. 先寫「3 行內」的結論摘要，讓使用者 5 秒看懂重點。
2. 刪除工程師口氣與多層括號。
3. 若證據有數字、年份、專有名詞，務必帶入並標示來源文件（用[^檔名]）。
4. 段落前用 ### 小標，層次不超過兩層；列表用 - 或 1. 2. 3.。
5. 全文 500–800 字，語言：繁體中文；格式：Markdown。
</instructions>

"""
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            # 引入 Agent 的初步答案作為 user message
            (
                "user",
                """
原始問題：
{original_question}

參考資料（已審核）：
{all_evidence}
""",
            ),
        ]
    )
    return prompt | llm | StrOutputParser()


def create_query_correction_chain(llm):
    """
    創建一個鏈，用於檢查使用者輸入是否符合最佳實踐（特別是檔案名稱格式），並提供修正建議。
    """
    correction_description = """你是一位友善的 AI 助理引導員。你的任務是檢查使用者的查詢格式，特別是關於檔案名稱的引用方式。

**唯一的「最佳實踐規則」：**
-   當使用者提到一個具體的檔案名稱時，該名稱**應該**被方括號 `[]` 包圍。

**你的工作流程如下：**
1.  **檢查查詢**: 閱讀使用者的原始查詢。
2.  **尋找潛在的檔案名稱**: 尋找看起來像檔案名稱的文本（例如，包含 `.pdf`, `.md`, `.txt` 等副檔名）。
3.  **判斷格式**: 檢查這個找到的檔案名稱是否已經被 `[]` 包圍。
4.  **決策並輸出**:
    -   **如果格式正確** (例如：`請摘要 [ex1.pdf]`)，或者查詢中**不包含**任何檔案名稱，則代表**不需要修正** (`is_correction_needed: False`)。
    -   **如果格式不正確** (例如：`請摘要 ex1.pdf`)，則代表**需要修正** (`is_correction_needed: True`)。此時，你必須：
        a. 生成一個 `corrected_query`，將檔案名稱用方括號 `[]` 包起來。
        b. 生成一個友善的 `correction_reason`，向使用者解釋這樣做的好處，並以問句結尾引導使用者確認。

**範例一 (需要修正):**
-   輸入: `請總結 report_v2.pdf 的內容`
-   輸出:
    -   `is_correction_needed`: True
    -   `corrected_query`: `請總結 [report_v2.pdf] 的內容`
    -   `correction_reason`: `為了更精確地識別您提到的檔案名稱，建議將其用方括號括起來會更好。您是指要執行這個指令嗎？`

**範例二 (格式正確):**
-   輸入: `根據 [110年度審核報告.md] 找出關於綠線捷運的內容`
-   輸出:
    -   `is_correction_needed`: False
    -   `corrected_query`: `根據 [110年度審核報告.md] 找出關於綠線捷運的內容`
    -   `correction_reason`: `查詢格式正確。`

**範例三 (無檔案名稱):**
-   輸入: `桃園的交通發展如何？`
-   輸出:
    -   `is_correction_needed`: False
    -   `corrected_query`: `桃園的交通發展如何？`
    -   `correction_reason`: `查詢格式正確。`
"""

    prompt = ChatPromptTemplate.from_messages(
        [("system", correction_description), ("user", "請分析並（在需要時）修正以下使用者查詢：\n\n```{input}```")]
    )

    # 確保使用結構化輸出
    return prompt | llm.with_structured_output(QueryCorrection, method="function_calling")
