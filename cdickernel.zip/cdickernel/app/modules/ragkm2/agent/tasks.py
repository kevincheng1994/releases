import os
import asyncio
from pathlib import Path
import logging
from uuid import UUID # Added UUID

# Keep original imports for DB operations
from app.shared.celery.app import celery_app
from app.modules.ragkm2.agent.repository import KnowledgeBaseRepository, KnowledgeFile # Added KnowledgeFile

# Imports from split_doc2.py and related files
from app.modules.ragkm2.agent.chunk_splitter import BaseChunkSplitter
from app.modules.ragkm2.agent.configs import retrieve_chunk_id_config as Configs
from app.modules.ragkm2.agent.configs.keys import azuer_document_intelligence_key


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@celery_app.task(bind=True)
def process_and_store_file(
    self,
    temp_file_path: str,
    account: str,
    knowledge_base_id: str,
    configname: str,
    split_type: str,
    chunk_size: int,
    knowledge_file_id: str,
):
    """
    Synchronous Celery task wrapper that runs the async processing logic,
    now with dynamic splitting and individual file tracking.
    """
    async def _async_main():
        kbrepo = KnowledgeBaseRepository()
        file_path = Path(temp_file_path)
        processing_status = "error" # Default status if something goes wrong

        try:
            logger.warning(
                f">>> CELERY TASK V5: Received request for file: {temp_file_path} "
                f"KB: {knowledge_base_id}, File ID: {knowledge_file_id} with splitting: "
                f"{configname}, {split_type}, {chunk_size}"
            )

            if not await asyncio.to_thread(file_path.exists):
                raise FileNotFoundError(f"Temporary file not found at {temp_file_path}")

            # --- 1. Create the splitter with metadata for tracking ---
            config_dict = getattr(Configs, configname)
            embeddings_kwargs = {
                "embedding_type": config_dict["embedding_type"],
                "key_dict": config_dict["key_dict"],
                "model_name": config_dict["model_name"],
            }
            
            # Construct metadata for LiteLLM usage tracking
            tracking_metadata = {
                "account": account,
                "operation": "file_upload_embedding"
            }

            splitter_specific_kwargs = {
                "chunk_size": chunk_size,
                "ocr_mode": "auto",  # Hardcoding for now as it\'s not exposed in the API
                "org_extension": ".none",
                "azure_endpoint": azuer_document_intelligence_key["azure"]["azure_endpoint"],
                "azure_key": azuer_document_intelligence_key["azure"]["azure_key"],
                "verbose": True, # Or False for less noise in logs
                "metadata": tracking_metadata # Pass metadata to splitter
            }

            splitter = await asyncio.to_thread(
                BaseChunkSplitter.create,
                splitter_type=split_type,
                embeddings_kwargs=embeddings_kwargs,
                **splitter_specific_kwargs
            )
            
            # --- 2. Split and embed document ---
            chunk_contents, embeddings, metadatas = await asyncio.to_thread(
                splitter.split_and_emb_from_filepath, temp_file_path
            )
            
            logger.info(f"Split file {file_path.name} into {len(chunk_contents)} chunks.")
            if not chunk_contents:
                logger.warning(f"File {file_path.name} produced no chunks.")
                processing_status = "completed_no_chunks" # Special status
                return {"status": processing_status, "message": f"File {file_path.name} produced no chunks."}

            # --- 3. Store in database ---
            knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)

            if not knowledge_base:
                # This should ideally not happen if KB is created in router, but good for robustness
                knowledge_base = await kbrepo.create_knowledge_base(account, account, description=f"KB for {knowledge_base_id}")
            
            # NO MORE kbrepo.clear_knowledge_base_chunks - we are adding incrementally
            # NO MORE kbrepo.update_knowledge_base_timestamp here - handled by file update

            # pgvector with asyncpg expects the vector to be a string, not a list.
            chunks_to_insert = [
                {
                    "knowledge_base_id": knowledge_base.id,
                    "knowledge_file_id": UUID(knowledge_file_id), # Include file ID
                    "content": chunk,
                    "embedding": str(emb)
                }
                for chunk, emb in zip(chunk_contents, embeddings)
            ]
            await kbrepo.insert_knowledge_base_chunks(chunks_to_insert)
            logger.info(f"Successfully stored {len(chunks_to_insert)} chunks for KB '{knowledge_base_id}' from file ID '{knowledge_file_id}'.")
            
            processing_status = "completed" # Mark as completed on success
            return {"status": processing_status, "message": f"File {file_path.name} processed and stored in KB '{knowledge_base_id}'."}

        except Exception as e:
            logger.error(f"Task failed for file path {temp_file_path} (File ID: {knowledge_file_id}): {e}", exc_info=True)
            processing_status = "error" # Explicitly set error status
            raise # Re-raise the exception to mark the Celery task as failed

        finally:
            # --- 4. Clean up ---
            # Update knowledge file status before temp file removal
            try:
                await kbrepo.update_knowledge_file_status(UUID(knowledge_file_id), processing_status)
                logger.info(f"Updated status for KnowledgeFile ID {knowledge_file_id} to '{processing_status}'.")
            except Exception as e:
                logger.error(f"Failed to update status for KnowledgeFile ID {knowledge_file_id}: {e}", exc_info=True)

            if await asyncio.to_thread(os.path.exists, temp_file_path):
                await asyncio.to_thread(os.remove, temp_file_path)
                logger.info(f"Removed temporary file: {temp_file_path}")

    try:
        # Run the async main function within the synchronous task
        return asyncio.run(_async_main())
    except Exception as e:
        logger.error(f"Task failed for file path {temp_file_path} (outer): {e}", exc_info=True)
        # Re-raise the exception to mark the Celery task as failed
        raise