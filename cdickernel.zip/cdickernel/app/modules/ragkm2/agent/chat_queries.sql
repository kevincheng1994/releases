-- app/modules/ragkm2/agent/chat_queries.sql
-- 對話 (conversation) 與訊息 (message) 相關的 SQL 查詢

------------------------- Conversation queries -------------------------

-- name: create-conversation<!
INSERT INTO chat.conversation (
    account,
    knowledge_base_id,
    conversation_id,
    title,
    modifytm,
    createtm
) VALUES (
    :account,
    :knowledge_base_id,
    :conversation_id,
    :title,
    NOW(),
    NOW()
) RETURNING
    id,
    account,
    knowledge_base_id,
    conversation_id,
    title,
    modifytm,
    createtm;

-- name: find-conversation-by-uuid^
SELECT
    id,
    account,
    knowledge_base_id,
    conversation_id,
    title,
    modifytm,
    createtm
FROM chat.conversation
WHERE conversation_id = :conversation_id;

-- name: list-conversations-by-account
SELECT
    id,
    account,
    knowledge_base_id,
    conversation_id,
    title,
    modifytm,
    createtm
FROM chat.conversation
WHERE account = :account
AND knowledge_base_id = :knowledge_base_id
ORDER BY modifytm DESC;

-- name: count-conversations-by-account$
SELECT
    COUNT(*)
FROM chat.conversation
WHERE account = :account;

-- name: update-conversation-modifytm!
UPDATE chat.conversation
SET modifytm = NOW()
WHERE conversation_id = :conversation_id;

-- name: update-conversation-title!
UPDATE chat.conversation
SET title = :title, modifytm = NOW()
WHERE conversation_id = :conversation_id;

-- name: delete-conversation-by-uuid!
DELETE FROM chat.conversation
WHERE conversation_id = :conversation_id;

------------------------- Message queries -------------------------

-- name: create-message<!
INSERT INTO chat.message (
    ask,
    conversation_id,
    reply_id,
    reply_msg,
    createtm
) VALUES (
    :ask,
    :conversation_id,
    :reply_id,
    :reply_msg,
    NOW()
) RETURNING
    id,
    ask,
    conversation_id,
    message_id,
    reply_id,
    reply_msg,
    category,
    token,
    createtm;

-- name: list-messages-by-conversation
SELECT
    id,
    ask,
    conversation_id,
    message_id,
    reply_id,
    reply_msg,
    category,
    token,
    createtm
FROM chat.message
WHERE conversation_id = :conversation_id
ORDER BY createtm ASC;

-- name: get-message-by-uuid^
SELECT
    id,
    ask,
    conversation_id,
    message_id,
    reply_id,
    reply_msg,
    category,
    token,
    createtm
FROM chat.message
WHERE message_id = :message_id;

-- name: delete-messages-by-conversation-id!
DELETE FROM chat.message
WHERE conversation_id = :conversation_id;

------------------------- Reference queries -------------------------

-- name: create-reference<!
INSERT INTO chat.reference (
    message_id,
    content,
    uploadname
) VALUES (
    :message_id,
    :content,
    :uploadname
) RETURNING
    id,
    message_id,
    content,
    uploadname;

-- name: list-references-by-message-id
SELECT
    id,
    message_id,
    content,
    uploadname
FROM chat.reference
WHERE message_id = :message_id
ORDER BY id ASC;

-- name: delete-references-by-message-id!
DELETE FROM chat.reference
WHERE message_id = :message_id;
