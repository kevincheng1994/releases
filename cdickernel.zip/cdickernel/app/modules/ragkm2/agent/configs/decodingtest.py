import os

from dotenv import load_dotenv


def get_key(key: str):
    return os.getenv(key)


load_dotenv()

aidvisor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")

bedrock_key = {
    "bedrock": {
        "aws_access_key_id": get_key("AWS_ACCESS_KEY_ID"),
        "aws_secret_access_key": get_key("AWS_SECRET_ACCESS_KEY"),
        "region_name": get_key("AWS_REGION_NAME"),
    }
}

vertexai_key = {
    "vertexai": {
        "type": "service_account",
        "project_id": get_key("GOOGLE_PROJECT_ID"),
        "private_key_id": get_key("GOOGLE_PRIVATE_KEY_ID"),
        "private_key": get_key("GOOGLE_PRIVATE_KEY"),
        "client_email": get_key("GOOGLE_CLIENT_EMAIL"),
        "client_id": get_key("GOOGLE_CLIENT_ID"),
        "auth_uri": get_key("GOOGLE_AUTH_URI"),
        "token_uri": get_key("GOOGLE_TOKEN_URI"),
        "auth_provider_x509_cert_url": get_key("GOOGLE_AUTH_PROVIDER_X509_CERT_URL"),
        "client_x509_cert_url": get_key("GOOGLE_CLIENT_X509_CERT_URL"),
        "universe_domain": get_key("GOOGLE_UNIVERSE_DOMAIN"),
        "location": get_key("GOOGLE_LOCATION"),
        "project": get_key("GOOGLE_PROJECT"),
    }
}

docname_to_metadata = {"2015.pdf.none.npy": {"title": "2015"}}

# agent_type = 'react_with_tool_calling'
agent_type = "react"
# agent_type = 'tool_calling'

# Bedrock
# ----------------------------------------------------------------
bedrock_embeddings = {"embedding_type": "bedrock", "key_dict": bedrock_key, "model_name": ""}

bedrock_llm = {"llm_type": "bedrock", "key_dict": bedrock_key, "model_name": ""}

bedrock_vectorstore = {
    "persist_dir": None,
    "chunk_dir": f"{aidvisor_dir}/storage/taipower",
    "docname_to_metadata": None,
    "available_docnames": None,
}

bedrock_configs = {
    "agent_type": agent_type,
    "llm": bedrock_llm,
    "embeddings": bedrock_embeddings,
    "vectorstore": bedrock_vectorstore,
    "verbose": True,
}
# ----------------------------------------------------------------

# VertexAi
# ----------------------------------------------------------------
vertexai_llm = {"llm_type": "vertexai", "key_dict": vertexai_key, "model_name": ""}

vertexai_embeddings = {"embedding_type": "vertexai", "key_dict": vertexai_key, "model_name": ""}

vertexai_vectorstore = {
    "persist_dir": None,
    "chunk_dir": f"{aidvisor_dir}/storage/decoding_reader2_chunk",
    "docname_to_metadata": lambda x: docname_to_metadata[x],
    "available_docnames": None,
}

vertexai_configs = {
    "agent_type": agent_type,
    "llm": vertexai_llm,
    "embeddings": vertexai_embeddings,
    "vectorstore": vertexai_vectorstore,
    "verbose": True,
}

# ----------------------------------------------------------------
configs = vertexai_configs
# configs = bedrock_configs
