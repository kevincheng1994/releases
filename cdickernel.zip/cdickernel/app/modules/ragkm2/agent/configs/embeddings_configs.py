from app.modules.ragkm2.agent.configs import keys

bedrock = {"embedding_type": "bedrock", "key_dict": keys.bedrock_key, "model_name": ""}
