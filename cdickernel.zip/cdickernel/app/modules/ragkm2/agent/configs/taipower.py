import os
import re
from typing import Optional

from dotenv import load_dotenv

# --- 1. 環境變數載入 ---


def get_key(key: str) -> Optional[str]:
    """從環境變數中安全地獲取一個鍵值。"""
    return os.getenv(key)


load_dotenv()

# --- 2. 基礎路徑與金鑰配置 ---

aidvisor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")

bedrock_key = {
    "bedrock": {
        "aws_access_key_id": get_key("AWS_ACCESS_KEY_ID"),
        "aws_secret_access_key": get_key("AWS_SECRET_ACCESS_KEY"),
        "region_name": get_key("AWS_REGION_NAME"),
    }
}

vertexai_key = {
    "vertexai": {
        "type": "service_account",
        "project_id": get_key("GOOGLE_PROJECT_ID"),
        "private_key_id": get_key("GOOGLE_PRIVATE_KEY_ID"),
        "private_key": get_key("GOOGLE_PRIVATE_KEY"),
        "client_email": get_key("GOOGLE_CLIENT_EMAIL"),
        "client_id": get_key("GOOGLE_CLIENT_ID"),
        "auth_uri": get_key("GOOGLE_AUTH_URI"),
        "token_uri": get_key("GOOGLE_TOKEN_URI"),
        "auth_provider_x509_cert_url": get_key("GOOGLE_AUTH_PROVIDER_X509_CERT_URL"),
        "client_x509_cert_url": get_key("GOOGLE_CLIENT_X509_CERT_URL"),
        "universe_domain": get_key("GOOGLE_UNIVERSE_DOMAIN"),
        "location": get_key("GOOGLE_LOCATION"),
        "project": get_key("GOOGLE_PROJECT"),
    }
}

azure_key = {
    "azure": {
        "api_key": get_key("AZURE_API_KEY"),
        # "api_base": get_key("AZURE_API_BASE"),
        # 'api_version': "2023-10-01-preview",
        "azure_endpoint": get_key("AZURE_API_BASE"),
        "api_version": "2025-04-01-preview",
        "deployment_name": "gpt-4o",
        "model_name": "gpt-4o",
        "validate_base_url": False,
    }
}

# --- 3. 元數據解析器 (策略模式實現) ---


def parse_project_id_format(docname: str) -> Optional[dict]:
    """
    解析策略一：處理 '原始檔名.專案ID' 格式。
    這是最優先的規則，用以處理帶有專案標識的檔名。
    """
    # 正則表達式：匹配以 .pdf, .docx, 或 .txt 結尾的檔名，後面跟著一個點和專案ID
    match = re.match(r"^(.+?\.(?:pdf|docx|txt|md))\.(.+)$", docname)
    if match:
        original_source = match.group(1)
        project_id = match.group(2)
        title = os.path.splitext(original_source)[0]
        return {"source": original_source, "title": title, "project_id": project_id}
    return None


def parse_year_prefix_format(docname: str) -> Optional[dict]:
    """解析策略二：處理 'YYYY-...' 或 'YYYYMMDD-...' 格式。"""
    match = re.match(r"^(\d{4,8})-.*", docname)
    if match:
        year_str = match.group(1)[:4]  # 只取前四位作為年份
        try:
            year = int(year_str)
            title = os.path.splitext(docname)[0]
            return {"source": docname, "title": title, "year": year}
        except ValueError:
            return None
    return None


# ???
def parse_mit_format(docname: str) -> Optional[dict]:
    """解析策略三：處理 MIT 報告的特殊格式。"""
    match = re.match(r"MIT-CEEPR-RC-(\d+)-\d+", docname)
    if match:
        try:
            year = int(match.group(1))
            title = os.path.splitext(docname)[0]
            return {"source": docname, "title": title, "year": year}
        except ValueError:
            return None
    return None


# 解析器鏈：按優先級順序定義所有要嘗試的解析策略。
METADATA_PARSERS = [
    parse_project_id_format,
    parse_year_prefix_format,
    parse_mit_format,
    # 未來若有新格式，只需在此處添加新的解析函式即可。
]


def docname_to_metadata(docname: str) -> dict:
    """
    從多種格式的檔名中解析元數據的主函式。
    它會按順序嘗試 METADATA_PARSERS 列表中的每個解析器，
    並返回第一個成功匹配的結果。
    """
    for parser in METADATA_PARSERS:
        metadata = parser(docname)
        if metadata is not None:
            return metadata

    # 如果所有解析器都失敗，提供一個健壯的回退機制，確保程式不會中斷。
    # print(f"警告：所有解析器都無法匹配檔名 '{docname}'。將使用預設元數據。")
    # source_filename = f"{docname}.pdf"
    source_filename = docname
    title = os.path.splitext(source_filename)[0]
    # 'source' 和 'title' 是最重要的基礎元數據。
    return {"source": source_filename, "title": title}


# --- 4. 各平台組態配置 ---

agent_type = "agent"
# agent_type = 'concise_agent'

# Bedrock
# ----------------------------------------------------------------
# 為常規、需要穩定性和低延遲的任務設定
bedrock_llm_fast = {
    "llm_type": "bedrock",
    "key_dict": bedrock_key,
    "model_name": "anthropic.claude-3-5-sonnet-20240620-v1:0",
    "temperature": 0.0,
    "max_output_tokens": 1024,
}

# 為需要長篇寫作、高質量輸出的 synthesis 階段設定
bedrock_llm_synthesis = {
    "llm_type": "bedrock",
    "key_dict": bedrock_key,
    "model_name": "anthropic.claude-3-5-sonnet-20240620-v1:0",  # Sonnet 很適合
    "temperature": 0.3,  # 稍微提高溫度，讓寫作更流暢
    "max_output_tokens": 64000,  # 設定為 Claude 4 Sonnet 的上限
}

# 新增一個專門用於長文本格式化的設定
bedrock_llm_long_format = {
    "llm_type": "bedrock",
    "key_dict": bedrock_key,
    "model_name": "anthropic.claude-3-5-sonnet-20240620-v1:0",
    "temperature": 0.0,
    "max_output_tokens": 64000,  # 與 synthesis 保持一致
}

# 為核心的 ReAct Agent 循環設定
bedrock_llm_react = {
    "llm_type": "bedrock",
    "key_dict": bedrock_key,
    "model_name": "anthropic.claude-3-5-sonnet-20240620-v1:0",  # Sonnet 或 Opus
    "temperature": 0.0,  # 嚴格的 0 溫，確保工具使用穩定
    "max_output_tokens": 4096,  # 為 Thought 和 Action Input 提供足夠空間
}

# ---舊config---
bedrock_llm = {"llm_type": "bedrock", "key_dict": bedrock_key, "model_name": ""}

bedrock_embeddings = {
    "embedding_type": "bedrock",
    "key_dict": bedrock_key,
    "model_name": "",  # 'amazon.titan-embed-text-v2:0'
}

bedrock_vectorstore = {
    "persist_dir": None,
    # 'chunk_dir': f'{aidvisor_dir}/storage/taipower',
    "chunk_dir": f"{aidvisor_dir}/storage/bedrock_1024_latest",
    "docname_to_metadata": docname_to_metadata,
    "available_docnames": None,
}

bedrock_configs = {
    "agent_type": agent_type,
    # "llm": bedrock_llm,
    "llm_configs": {
        "react": bedrock_llm_react,
        "synthesis": bedrock_llm_synthesis,
        "markdown": bedrock_llm_long_format,
        "q_classifier": bedrock_llm_fast,  # 分類器使用快速模型
        "rag_analyzer": bedrock_llm_fast,  # 分析器使用快速模型
        "default": bedrock_llm_fast,  # 為其他所有任務提供一個預設值
    },
    "embeddings": bedrock_embeddings,
    "vectorstore": bedrock_vectorstore,
    "is_bm25_ensemble": True,
    "is_rephrase": False,
    "verbose": True,
    "use_reranker": False,
}
# ----------------------------------------------------------------

# VertexAi
# ----------------------------------------------------------------
# 為常規、需要穩定性和低延遲的任務設定
vertexai_llm_fast = {
    "llm_type": "vertex_ai",
    "key_dict": vertexai_key,
    "model_name": "claude-sonnet-4@20250514",
    "temperature": 0.0,
    # "max_output_tokens": 64000,
}

# 為需要長篇寫作、高質量輸出的 synthesis 階段設定
vertexai_llm_synthesis = {
    "llm_type": "vertex_ai",
    "key_dict": vertexai_key,
    "model_name": "claude-sonnet-4@20250514",  # Sonnet 很適合
    "temperature": 0.3,  # 稍微提高溫度，讓寫作更流暢
    # "max_output_tokens": 64000,  # 設定為 Claude 4 Sonnet 的上限
}

# 新增一個專門用於長文本格式化的設定
vertexai_llm_long_format = {
    "llm_type": "vertex_ai",
    "key_dict": vertexai_key,
    "model_name": "claude-sonnet-4@20250514",
    "temperature": 0.0,
    # "max_output_tokens": 64000,  # 與 synthesis 保持一致
}

# 為核心的 ReAct Agent 循環設定
vertexai_llm_react = {
    "llm_type": "vertex_ai",
    "key_dict": vertexai_key,
    "model_name": "claude-sonnet-4@20250514",  # Sonnet 或 Opus
    "temperature": 0.0,  # 嚴格的 0 溫，確保工具使用穩定
    # "max_output_tokens": 4096,  # 為 Thought 和 Action Input 提供足夠空間
}

# ---舊config---
vertexai_llm = {
    "llm_type": "vertexai",
    "key_dict": vertexai_key,
    # 'model_name': 'gemini-2.0-flash'
    "model_name": "claude-sonnet-4@20250514",
    "temperature": 0.0,
    "max_output_tokens": 2048,
}

# ---

vertexai_embeddings = {
    "embedding_type": "vertexai",
    "key_dict": vertexai_key,
    "model_name": "",
}

vertexai_vectorstore = {
    "persist_dir": None,
    "chunk_dir": f"{aidvisor_dir}/storage/VertexAI",
    "docname_to_metadata": docname_to_metadata,
    "available_docnames": None,
}

vertexai_configs = {
    "agent_type": agent_type,
    # "llm": vertexai_llm,
    "llm_configs": {
        "react": vertexai_llm_react,
        "synthesis": vertexai_llm_synthesis,
        "markdown": vertexai_llm_long_format,
        "q_classifier": vertexai_llm_fast,  # 分類器使用快速模型
        "rag_analyzer": vertexai_llm_fast,  # 分析器使用快速模型
        "default": vertexai_llm_long_format,  # 為其他所有任務提供一個預設值
    },
    "embeddings": vertexai_embeddings,
    "vectorstore": vertexai_vectorstore,
    "is_bm25_ensemble": True,
    "is_rephrase": False,
    "verbose": True,
    "use_reranker": False,
}

# ----------------------------------------------------------------

# Azure
# ----------------------------------------------------------------
# 為常規、需要穩定性和低延遲的任務設定
azure_llm_fast = {
    "llm_type": "azure",
    "key_dict": azure_key,
    "model_name": "gpt-4o",
    "model_name": "gpt-4.1-mini",
    "temperature": 0.0,
    # "max_output_tokens": 1024,
}

# 為需要長篇寫作、高質量輸出的 synthesis 階段設定
azure_llm_synthesis = {
    "llm_type": "azure",
    "key_dict": azure_key,
    "model_name": "gpt-4o",  # Sonnet 很適合
    "model_name": "gpt-4.1-mini",
    "temperature": 0.3,  # 稍微提高溫度，讓寫作更流暢
    # "max_output_tokens": 64000,  # 設定為 Claude 4 Sonnet 的上限
}

# 新增一個專門用於長文本格式化的設定
azure_llm_long_format = {
    "llm_type": "azure",
    "key_dict": azure_key,
    "model_name": "gpt-4o",
    "model_name": "gpt-4.1-mini",
    "temperature": 0.0,
    # "max_output_tokens": 64000,  # 與 synthesis 保持一致
}

# 為核心的 ReAct Agent 循環設定
azure_llm_react = {
    "llm_type": "azure",
    "key_dict": azure_key,
    "model_name": "gpt-4o",  # Sonnet 或 Opus
    "model_name": "gpt-4.1-mini",
    "temperature": 0.0,  # 嚴格的 0 溫，確保工具使用穩定
    # "max_output_tokens": 4096,  # 為 Thought 和 Action Input 提供足夠空間
}

# ---舊config---
azure_llm = {"llm_type": "azure", "key_dict": azure_key, "model_name": "gpt-4o"}

azure_embeddings = {
    "embedding_type": "azure",
    "key_dict": azure_key,
    "model_name": "text-embedding-ada-002",  # <-- 請填寫您部署的 Azure Embedding 模型名稱
}

azure_vectorstore = {
    "persist_dir": None,
    # 建議為 Azure 建立一個專屬的 chunk 目錄
    "chunk_dir": f"{aidvisor_dir}/storage/Azure",
    "docname_to_metadata": docname_to_metadata,
    "available_docnames": None,
}

azure_configs = {
    "agent_type": agent_type,
    # "llm": azure_llm,
    "llm_configs": {
        "react": azure_llm_react,
        "synthesis": azure_llm_synthesis,
        "markdown": azure_llm_long_format,
        "q_classifier": azure_llm_fast,  # 分類器使用快速模型
        "rag_analyzer": azure_llm_fast,  # 分析器使用快速模型
        "default": azure_llm_fast,  # 為其他所有任務提供一個預設值
    },
    "embeddings": azure_embeddings,
    "vectorstore": azure_vectorstore,
    "is_bm25_ensemble": True,
    "is_rephrase": False,
    "verbose": True,
    "use_reranker": False,
    # 🆕 新增的調優參數
    # "max_steps": 12,              # 降低最大步數，減少無限循環風險
}

# ollama
# ----------------------------------------------------------------
ollama_llm = {"llm_type": "ollama", "key_dict": azure_key, "model_name": ""}

ollama_configs = {
    "agent_type": agent_type,
    "llm": ollama_llm,
    "embeddings": vertexai_embeddings,
    "vectorstore": vertexai_vectorstore,
    "is_bm25_ensemble": True,
    "is_rephrase": False,
    "verbose": True,
}

# configs = ollama_configs
# configs = vertexai_configs
# configs = bedrock_configs
configs = azure_configs


def get_configs_for_model(model_name: str) -> dict:
    """
    依據模型名稱判斷所屬平台，取得對應的 llm_configs，
    並套用到 default configs（保留原本的 embeddings / vectorstore）。

    判斷規則：
      - Bedrock : 含 "anthropic." 或 "amazon." 前綴
      - VertexAI: 含 "claude" 或 "gemini"（含 "@" 版本號的 VertexAI 格式）
      - Azure   : 其餘 (e.g. gpt-4o, gpt-4.1-mini, o1-*)
    """
    import copy

    if "anthropic." in model_name or "amazon." in model_name:
        llm_configs_template = bedrock_configs["llm_configs"]
    elif "claude" in model_name or "gemini" in model_name:
        llm_configs_template = vertexai_configs["llm_configs"]
    else:
        llm_configs_template = azure_configs["llm_configs"]

    # 以 default configs 為基底，只替換 llm_configs，
    # 保留 embeddings / vectorstore / 其他參數不變
    result = copy.deepcopy(configs)
    result["llm_configs"] = copy.deepcopy(llm_configs_template)
    for op_config in result["llm_configs"].values():
        op_config["model_name"] = model_name
    return result
