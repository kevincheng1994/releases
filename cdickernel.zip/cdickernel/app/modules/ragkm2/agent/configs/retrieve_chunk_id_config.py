import os

from . import keys

RETRIEVE_CHUNK_CONFIGS = [
    "retrieve_gt_bedrock_titanembedtext20",
    "retrieve_q_bedrock_titanembedtext20",
    "retrieve_q_vertexai_geckomultilingual001",
    "retrieve_q_azure_textembeddingada002",
]

SPLIT_DOC_CONFIGS = ["bedrock_titanembedtext20", "vertexai_geckomultilingual001", "azure_textembeddingada002"]

aidvisor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")

bedrock_titanembedtext20 = {
    "embedding_type": "bedrock",
    "key_dict": keys.bedrock_key,
    "model_name": "amazon.titan-embed-text-v2:0",
}

# bedrock_llm = {
#     'llm_type': 'bedrock',
#     'key_dict': keys.bedrock_key,
#     'model_name': ''
# }

vertexai_geckomultilingual001 = {
    "embedding_type": "vertex_ai",
    "key_dict": keys.vertexai_key,
    "model_name": "textembedding-gecko-multilingual@001",
}

azure_textembeddingada002 = {
    "embedding_type": "azure",
    "key_dict": keys.azure_key,
    "model_name": "text-embedding-ada-002",
}

bedrock_titanembedtext20_vectorstore = {
    "persist_dir": None,
    "chunk_dir": f"{aidvisor_dir}/storage/taipower_page_bedrock_titanembedtext20",
    "docname_to_metadata": None,
    "available_docnames": None,
    "embedding_type": "bedrock",
    "key_dict": keys.bedrock_key,
    "model_name": "amazon.titan-embed-text-v2:0",
    "add_index_metadata": True,
}

vertexai_geckomultilingual001_vectorstore = {
    "persist_dir": None,
    "chunk_dir": f"{aidvisor_dir}/storage/taipower_page_vertexai_geckomultilingual001",
    "docname_to_metadata": None,
    "available_docnames": None,
    "embedding_type": "vertex_ai",
    "key_dict": keys.vertexai_key,
    "model_name": "textembedding-gecko-multilingual@001",
    "add_index_metadata": True,
}

# openai_textembeddingada002_vectorstore = {
#     "persist_dir": None,
#     "chunk_dir": f"{aidvisor_dir}/storage/taipower_page_openai_textembeddingada002",
#     "docname_to_metadata": None,
#     "available_docnames": None,
#     "embedding_type": "vertexai",
#     "key_dict": keys.vertexai_key,
#     "model_name": "textembedding-gecko-multilingual@001",
#     "add_index_metadata": True,
# }

retrieve_gt_bedrock_titanembedtext20 = {"vectorstore": bedrock_titanembedtext20_vectorstore, "search_kwargs": {"k": 1}}

retrieve_q_bedrock_titanembedtext20 = {"vectorstore": bedrock_titanembedtext20_vectorstore, "search_kwargs": {"k": 5}}

retrieve_q_vertexai_geckomultilingual001 = {
    "vectorstore": vertexai_geckomultilingual001_vectorstore,
    "search_kwargs": {"k": 5},
}
