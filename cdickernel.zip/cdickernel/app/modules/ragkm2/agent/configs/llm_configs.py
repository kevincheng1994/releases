import os

from app.modules.ragkm2.agent.configs import keys

bedrock = {"llm_type": "bedrock", "key_dict": keys.bedrock_key, "model_name": ""}
