import os

from dotenv import load_dotenv
from langchain.chains.query_constructor.base import AttributeInfo


def get_key(key: str):
    return os.getenv(key)


load_dotenv()

aidvisor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")

bedrock_key = {
    "bedrock": {
        "aws_access_key_id": get_key("AWS_ACCESS_KEY_ID"),
        "aws_secret_access_key": get_key("AWS_SECRET_ACCESS_KEY"),
        "region_name": get_key("AWS_REGION_NAME"),
    }
}


def docname_to_metadata(docname: str):
    d2m = {
        "3002028847_Executive Summary_ Regional Hydrogen Pipeline Costs for US_REGEN Model.npy": {
            "title": "3002028847_Executive Summary_ Regional Hydrogen Pipeline Costs for US_REGEN Model.npy",
            "year": 2024,
            "month": 8,
        },
        "3002029695_Hydrogen to Infinity_ Developing a Hydrogen Gas Transmission Facility_ Joint Industry Partnership _ Phase 1.npy": {
            "title": "3002029695_Hydrogen to Infinity_ Developing a Hydrogen Gas Transmission Facility_ Joint Industry Partnership _ Phase 1.npy",
            "year": 2024,
            "month": 8,
        },
        "3002025159_Executive Summary_ Low_Carbon Fuel Pathways for the Primary Metals Industries.npy": {
            "title": "3002025159_Executive Summary_ Low_Carbon Fuel Pathways for the Primary Metals Industries.npy",
            "year": 2022,
            "month": 7,
        },
        "3002026035_Program on Technology Innovation_ Environmental Justice and Carbon Capture and Storage.npy": {
            "title": "3002026035_Program on Technology Innovation_ Environmental Justice and Carbon Capture and Storage.npy",
            "year": 2023,
            "month": 2,
        },
        "3002028907_Hydrogen Fuel Cell and Electrolyzer End_of_Life Management Review.npy": {
            "title": "3002028907_Hydrogen Fuel Cell and Electrolyzer End_of_Life Management Review.npy",
            "year": 2024,
            "month": 3,
        },
        "3002028176_Executive Summary_ Economic Cost_ Limitations_ Challenges and__Opportunities of Utilizing Existing Natural__Gas Compressor Systems for Transport of__Hydrogen and Hydrogen Blends.npy": {
            "title": "3002028176_Executive Summary_ Economic Cost_ Limitations_ Challenges and__Opportunities of Utilizing Existing Natural__Gas Compressor Systems for Transport of__Hydrogen and Hydrogen Blends.npy",
            "year": 2024,
            "month": 2,
        },
        "3002028027_Feasibility_Assessment_of_U_S__E_gas_Exports_to_Japan.npy": {
            "title": "3002028027_Feasibility_Assessment_of_U_S__E_gas_Exports_to_Japan.npy",
            "year": 2023,
            "month": 9,
        },
        "3002028977_U_S_ Low_Carbon Ammonia_ Costs and Resource Requirements.npy": {
            "title": "3002028977_U_S_ Low_Carbon Ammonia_ Costs and Resource Requirements.npy",
            "year": 2024,
            "month": 3,
        },
        "3002027977_NYPA and Southern Company_s Hydrogen_Natural Gas Blend Reduces CO2 Emissions.npy": {
            "title": "3002027977_NYPA and Southern Company_s Hydrogen_Natural Gas Blend Reduces CO2 Emissions.npy",
            "year": 2024,
            "month": 2,
        },
        "CCUS_Status_Final_2022.npy": {"title": "CCUS_Status_Final_2022.npy", "year": 2022, "month": 1},
        "3002028143_Decarbonization Strategies for Upstream Oil and Gas Operations with Advanced Nuclear Technologies.npy": {
            "title": "3002028143_Decarbonization Strategies for Upstream Oil and Gas Operations with Advanced Nuclear Technologies.npy",
            "year": 2023,
            "month": 11,
        },
    }
    return d2m[docname]


embeddings = {
    "persist_dir": f"{aidvisor_dir}/chroma/taipower_test",
    "docname_to_metadata": docname_to_metadata,
    "metadata_field_info": [
        AttributeInfo(
            name="year",
            description="The publication year of the section or the book",
            type="int",
        ),
        AttributeInfo(
            name="month",
            description="The publication month of the section or the book",
            type="int",
        ),
        AttributeInfo(
            name="title",
            description="The title of the book or section",
            type="string",
        ),
    ],
}

configs = {
    "chunk_dir": f"{aidvisor_dir}/storage/taipower_test",
    "service_platform": "bedrock",
    "key": bedrock_key,
    "embeddings": embeddings,
}
