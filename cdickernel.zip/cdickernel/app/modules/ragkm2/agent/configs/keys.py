import os

from dotenv import load_dotenv


def get_key(key: str):
    return os.getenv(key)


load_dotenv()

aidvisor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")

bedrock_key = {
    "bedrock": {
        "aws_access_key_id": get_key("AWS_ACCESS_KEY_ID"),
        "aws_secret_access_key": get_key("AWS_SECRET_ACCESS_KEY"),
        "region_name": get_key("AWS_REGION_NAME"),
    }
}


vertexai_key = {
    "vertexai": {
        "type": "service_account",
        "project_id": get_key("GOOGLE_PROJECT_ID"),
        "private_key_id": get_key("GOOGLE_PRIVATE_KEY_ID"),
        "private_key": get_key("GOOGLE_PRIVATE_KEY"),
        "client_email": get_key("GOOGLE_CLIENT_EMAIL"),
        "client_id": get_key("GOOGLE_CLIENT_ID"),
        "auth_uri": get_key("GOOGLE_AUTH_URI"),
        "token_uri": get_key("GOOGLE_TOKEN_URI"),
        "auth_provider_x509_cert_url": get_key("GOOGLE_AUTH_PROVIDER_X509_CERT_URL"),
        "client_x509_cert_url": get_key("GOOGLE_CLIENT_X509_CERT_URL"),
        "universe_domain": get_key("GOOGLE_UNIVERSE_DOMAIN"),
        "location": get_key("GOOGLE_LOCATION"),
        "project": get_key("GOOGLE_PROJECT"),
    }
}

azure_key = {
    "azure": {
        "api_key": get_key("AZURE_API_KEY"),
        # "api_base": get_key("AZURE_API_BASE"),
        # 'api_version': "2023-10-01-preview",
        "azure_endpoint": get_key("AZURE_API_BASE"),
        "api_version": "2025-04-01-preview",
        "deployment_name": "gpt-4o",
        "model_name": "gpt-4o",
        "validate_base_url": False,
    }
}

azuer_document_intelligence_key = {
    "azure": {
        "azure_endpoint": get_key("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"),
        "azure_key": get_key("AZURE_DOCUMENT_INTELLIGENCE_KEY"),
    }
}
