-- app/modules/ragkm2/agent/queries.sql

------------------------- Knowledge Base queries -------------------------

-- name: list-kbs-by-account
SELECT
    id,
    account,
    name,
    description,
    created_at,
    updated_at
FROM chat.knowledge_bases
WHERE account = :account
OR account = 'all';

-- name: find-knowledge-base-by-id^
SELECT
    id,
    account,
    name,
    description,
    created_at,
    updated_at
FROM chat.knowledge_bases
WHERE id = :knowledge_base_id;

-- name: find-knowledge-base-by-account-and-name^
SELECT
    id,
    account,
    name,
    description,
    created_at,
    updated_at
FROM chat.knowledge_bases
WHERE account = :account AND name = :name;

-- name: create-knowledge-base<!
INSERT INTO chat.knowledge_bases (
    account,
    name,
    description
)
VALUES (
    :account,
    :name,
    :description
)
RETURNING
    id,
    account,
    name,
    description,
    created_at,
    updated_at;

-- name: update-knowledge-base-timestamp!
UPDATE chat.knowledge_bases
SET updated_at = NOW()
WHERE id = :knowledge_base_id;

------------------------- Knowledge File queries -------------------------

-- name: create-knowledge-file<!
INSERT INTO chat.knowledge_files (
    knowledge_base_id,
    file_name,
    status
) VALUES (
    :knowledge_base_id,
    :file_name,
    :status
) RETURNING id, knowledge_base_id, file_name, status, created_at, updated_at;

-- name: get-knowledge-file-by-id^
SELECT id, knowledge_base_id, file_name, status, created_at, updated_at
FROM chat.knowledge_files
WHERE id = :file_id;

-- name: find-file-by-kb-id-and-name^
SELECT id, knowledge_base_id, file_name, status, created_at, updated_at
FROM chat.knowledge_files
WHERE knowledge_base_id = :knowledge_base_id AND file_name = :file_name;

-- name: list-files-by-kb-id
SELECT id, knowledge_base_id, file_name, status, created_at, updated_at
FROM chat.knowledge_files
WHERE knowledge_base_id = :knowledge_base_id
ORDER BY created_at DESC;

-- name: update-knowledge-file-status!
UPDATE chat.knowledge_files
SET status = :status, updated_at = NOW()
WHERE id = :file_id;

-- name: delete-knowledge-file-by-id!
DELETE FROM chat.knowledge_files
WHERE id = :file_id;

------------------------- Knowledge Chunk queries -------------------------

-- name: clear-chunks-by-kb-id!
DELETE FROM chat.knowledge_base_chunks
WHERE knowledge_base_id = :knowledge_base_id;

-- name: clear-chunks-by-file-id!
DELETE FROM chat.knowledge_base_chunks
WHERE knowledge_file_id = :file_id;

-- name: insert-knowledge-base-chunks*!

INSERT INTO chat.knowledge_base_chunks (

    knowledge_base_id,

    knowledge_file_id,

    content,

    embedding

) VALUES (

    :knowledge_base_id,

    :knowledge_file_id,

    :content,

    :embedding

);



-- name: get-chunks-by-kb-id

SELECT

    c.id,

    c.knowledge_base_id,

    c.knowledge_file_id,

    c.content,

    c.embedding,

    c.created_at,

    f.file_name as source,

    f.file_name as title

FROM chat.knowledge_base_chunks c

JOIN chat.knowledge_files f ON c.knowledge_file_id = f.id

WHERE c.knowledge_base_id = :knowledge_base_id;
