import aiosql
from typing import List, Optional
from uuid import UUID

from app.shared.database.tennat.connection_manager import TenantConnectionManager

from pydantic import BaseModel
from datetime import datetime

# --- Pydantic Models ---

class KnowledgeBase(BaseModel):
    id: UUID
    account: str
    name: str
    description: Optional[str]
    created_at: datetime
    updated_at: datetime

class KnowledgeFile(BaseModel):
    id: UUID
    knowledge_base_id: UUID
    file_name: str
    status: str # e.g., 'processing', 'completed', 'error'
    created_at: datetime
    updated_at: datetime

class KnowledgeBaseChunk(BaseModel):
    id: UUID
    knowledge_base_id: UUID
    knowledge_file_id: UUID # NEW FIELD
    content: str
    embedding: List[float] # pgvector will handle this list of floats
    created_at: datetime

# --- Repository ---

class KnowledgeBaseRepository:
    def __init__(self):
        self.tenant_conn_mgr = TenantConnectionManager()
        self.queries = aiosql.from_path(
            "app/modules/ragkm2/agent/queries.sql", "asyncpg"
        )

    # --- KnowledgeBase Management ---
    async def list_kbs_by_account(self, account: str) -> List[KnowledgeBase]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.list_kbs_by_account(connection, account=account)
            return [KnowledgeBase.model_validate(dict(record)) async for record in records]

    async def find_kb_by_id(
        self, knowledge_base_id: UUID
    ) -> Optional[KnowledgeBase]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.find_knowledge_base_by_id(
                connection, knowledge_base_id=knowledge_base_id
            )
            if record:
                return KnowledgeBase.model_validate(dict(record))
            return None

    async def find_kb_by_account_and_name(
        self, account: str, name: str
    ) -> Optional[KnowledgeBase]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.find_knowledge_base_by_account_and_name(
                connection, account=account, name=name
            )
            if record:
                return KnowledgeBase.model_validate(dict(record))
            return None

    async def create_knowledge_base(
        self, account: str, name: str, description: Optional[str] = None
    ) -> KnowledgeBase:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.create_knowledge_base(
                connection, account=account, name=name, description=description
            )
            return KnowledgeBase.model_validate(dict(record))
        
    async def update_knowledge_base_timestamp(
        self, knowledge_base_id: UUID
    ) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.update_knowledge_base_timestamp(
                connection, knowledge_base_id=knowledge_base_id
            )

    # --- KnowledgeFile Management ---
    async def create_knowledge_file(
        self, knowledge_base_id: UUID, file_name: str, status: str
    ) -> KnowledgeFile:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.create_knowledge_file(
                connection,
                knowledge_base_id=knowledge_base_id,
                file_name=file_name,
                status=status
            )
            return KnowledgeFile.model_validate(dict(record))

    async def get_knowledge_file_by_id(self, file_id: UUID) -> Optional[KnowledgeFile]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.get_knowledge_file_by_id(connection, file_id=file_id)
            if record:
                return KnowledgeFile.model_validate(dict(record))
            return None

    async def find_file_by_kb_id_and_name(
        self, knowledge_base_id: UUID, file_name: str
    ) -> Optional[KnowledgeFile]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.find_file_by_kb_id_and_name(
                connection, knowledge_base_id=knowledge_base_id, file_name=file_name
            )
            if record:
                return KnowledgeFile.model_validate(dict(record))
            return None
    
    async def list_files_by_kb_id(self, knowledge_base_id: UUID) -> List[KnowledgeFile]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.list_files_by_kb_id(connection, knowledge_base_id=knowledge_base_id)
            return [KnowledgeFile.model_validate(dict(record)) async for record in records]

    async def update_knowledge_file_status(
        self, file_id: UUID, status: str
    ) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.update_knowledge_file_status(
                connection, file_id=file_id, status=status
            )

    async def delete_knowledge_file_by_id(self, file_id: UUID) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            # Deleting the file record will cascade delete associated chunks
            await self.queries.delete_knowledge_file_by_id(connection, file_id=file_id)


    # --- KnowledgeBaseChunk Management ---

    async def clear_chunks_by_kb_id(
        self, knowledge_base_id: UUID
    ) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.clear_chunks_by_kb_id(
                connection, knowledge_base_id=knowledge_base_id
            )

    async def clear_chunks_by_file_id(
        self, file_id: UUID
    ) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.clear_chunks_by_file_id(
                connection, file_id=file_id
            )

    async def insert_knowledge_base_chunks(
        self, chunks_data: List[dict]
    ) -> None:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            # With the simplified query, aiosql handles the executemany operation
            # by iterating over the list of dicts.
            await self.queries.insert_knowledge_base_chunks(connection, chunks_data)

    async def get_chunks_by_kb_id(self, knowledge_base_id: UUID) -> List[dict]:
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.get_chunks_by_kb_id(
                connection, knowledge_base_id=knowledge_base_id
            )
            return [dict(record) async for record in records]
