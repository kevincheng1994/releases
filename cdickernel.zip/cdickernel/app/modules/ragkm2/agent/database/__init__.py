# class DB_Maker():
#     def __init__(self, key_dict: dict):
#         self.key_dict = key_dict

#     def read_from_chunk_dir(self, chunk_dir: str):
#         """Tree chunk_dir

#         chunk_dir/ ├── chunks/ ├── chunk1.npy
#                     │           ├── chunk2.npy
#                     │           └── ...
#                     └── metadata.py
#         """
