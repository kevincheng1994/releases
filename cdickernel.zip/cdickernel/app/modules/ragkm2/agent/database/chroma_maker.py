import os
import uuid
from typing import Callable, Optional

import numpy as np
from langchain_chroma import Chroma

from app.modules.ragkm2.agent.utils import utils


class ChromaMaker:
    def __init__(self):
        """
        初始化 ChromaMaker。
        嘗試使用 pysqlite3 替代內建的 sqlite3，以解決某些環境下的版本相容性問題。
        """
        import sys

        try:
            import pysqlite3  # noqa: F401

            sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
        except ImportError:
            # 如果沒有安裝 pysqlite3，則靜默跳過，使用系統預設。
            pass
        self._doc_names = []

    # def _read_config(self, filepath: str) -> dict:
    #     spec = importlib.util.spec_from_file_location('metadata', filepath)
    #     module = importlib.util.module_from_spec(spec)
    #     spec.loader.exec_module(module)
    #     embeddings_config = module.embeddings
    #     return embeddings_config

    def create_from_chunk_dir(
        self,
        embedding_type: str,
        key_dict: dict,
        model_name: str,
        chunk_dir: str,
        docname_to_metadata: Optional[Callable[[str], dict]],
        available_docnames: Optional[list[str]] = None,
        persist_dir: Optional[str] = None,
    ) -> (Chroma, list[str]):
        """
        從包含 chunks 和 embeddings 的目錄中創建一個 Chroma 向量資料庫。

        這個方法會遍歷 chunk_dir/chunks 目錄，讀取 .npy 檔案，
        並使用一個外部傳入的函式 `docname_to_metadata` 來生成元數據。

        Args:
            embedding_type: Embedding 模型的類型 (例如 'bedrock', 'azure')。
            key_dict: 包含 API 金鑰的字典。
            model_name: Embedding 模型的具體名稱。
            chunk_dir: 包含 'chunks' 和 'embs' 子目錄的根路徑。
            docname_to_metadata: 一個函式，接收不含副檔名的檔名，返回一個元數據字典。
            available_docnames: (可選) 一個檔名列表，只處理此列表中的檔案。
            persist_dir: (可選) 持久化儲存 ChromaDB 的路徑。

        Returns:
            一個元組，包含 Chroma 向量資料庫實例和處理過的所有文件基礎名稱列表。
        """
        """Tree chunk_dir.

        chunk_dir/ ├── chunks/ ├── chunk1.npy or chunk1.xxx.xxx.npy
                    |           ├── chunk2.npy or chunk2.xxx.xxx.npy
                    |           └── ...
                    |
                    └── embs/   ├── emb1.npy   or emb1.xxx.xxx.npy
                                ├── emb2.npy   or emb2.xxx.xxx.npy
                                └── ...
        """
        chunks_folder = os.path.join(chunk_dir, "chunks")
        embs_folder = os.path.join(chunk_dir, "embs")

        if not os.path.isdir(chunks_folder):
            raise FileNotFoundError(f"Chunks folder not found: {chunks_folder}")
        if not os.path.isdir(embs_folder):
            raise FileNotFoundError(f"Embeddings folder not found: {embs_folder}")

        query_embeddings = utils.create_embeddings(
            embedding_type=embedding_type, key_dict=key_dict, model_name=model_name
        )
        vectorstore = Chroma(
            collection_name=str(uuid.uuid4()),
            embedding_function=query_embeddings,
            persist_directory=persist_dir,
        )

        texts_batch, embs_batch, metadatas_batch, ids_batch = [], [], [], []

        # ChromaDB 的批次大小上限約為 41666，我們設定一個更小、更安全的值
        # 這是在所有文件中累加的 chunk 數量
        upsert_batch_size = 4000

        processed_files_count = 0
        skipped_files_count = 0
        total_chunks_added = 0

        # 使用 set 來自動處理重複的文件名
        processed_doc_names = set()

        # 排序以確保處理順序的一致性
        sorted_dir_list = sorted(os.listdir(chunks_folder))

        for npy_filename in sorted_dir_list:
            # 1. 嚴格的檔名檢查：只允許 .npy 檔案，確保數據源的乾淨
            if not npy_filename.endswith(".npy"):
                print(f"Warning: Non .npy file '{npy_filename}' found in chunks directory. Skipping.")
                skipped_files_count += 1
                continue

            if available_docnames and npy_filename not in available_docnames:
                print(f"[ChromaMaker] SKIPPED: '{npy_filename}' 不在提供的 available_docnames 列表中。")
                skipped_files_count += 1
                continue

            # 1. 去掉 .npy -> "report.pdf.none"
            filename_with_project_id = os.path.splitext(npy_filename)[0]

            # 2. 再次使用 splitext 去掉 .projectID (e.g., .none)
            #    os.path.splitext('report.pdf.none') -> ('report.pdf', '.none')
            original_full_filename, project_id_ext = os.path.splitext(filename_with_project_id)

            # 增加一個檢查，確保我們剝離的是 project ID，而不是檔名的一部分
            # (這個邏輯可以根據您的 project ID 格式進一步優化)
            if not (project_id_ext and project_id_ext.count(".") == 1):
                original_full_filename = filename_with_project_id

            print(f"\n[ChromaMaker] Processing file: {npy_filename} -> {original_full_filename}")

            textfilepath = os.path.join(chunks_folder, npy_filename)
            embfilepath = os.path.join(embs_folder, npy_filename)

            if not os.path.exists(embfilepath):
                print(f"Warning: Corresponding embedding file not found for {npy_filename}. Skipping.")
                skipped_files_count += 1
                continue

            text_chunks_raw = np.load(textfilepath, allow_pickle=True)
            emb_chunks_raw = np.load(embfilepath, allow_pickle=True)

            if len(emb_chunks_raw) != len(text_chunks_raw):
                print(f"Warning: Mismatch in chunk count for {npy_filename}. Skipping.")
                skipped_files_count += 1
                continue

            # 數據清洗：過濾掉 None 和空字串
            cleaned_texts = []
            valid_indices = []
            for i, chunk in enumerate(text_chunks_raw):
                if chunk is not None and str(chunk).strip():
                    cleaned_texts.append(str(chunk))
                    valid_indices.append(i)

            if not cleaned_texts:
                print(f"警告：在 {npy_filename} 中找不到有效的文本塊，已跳過。")
                skipped_files_count += 1
                continue

            # cleaned_embs = [emb_chunks_raw[i] for i in valid_indices]
            len_text = len(cleaned_texts)

            # 準備元數據
            chunk_metadata = {"source": original_full_filename, "title": os.path.splitext(original_full_filename)[0]}
            if docname_to_metadata:
                try:
                    extra_metadata = docname_to_metadata(filename_with_project_id)
                    print(f"[ChromaMaker] Metadata from func for '{filename_with_project_id}': {extra_metadata}")

                    if extra_metadata and isinstance(extra_metadata, dict):
                        chunk_metadata.update(extra_metadata)
                    else:
                        print(
                            f"Warning: docname_to_metadata returned an invalid value ({extra_metadata}) for '{filename_with_project_id}'. Using default metadata."
                        )

                except Exception as e:
                    print(
                        f"Warning: docname_to_metadata function failed for '{filename_with_project_id}': {e}. Using default metadata."
                    )

            # 標記此文件已開始處理
            file_processed_flag = False

            for i, chunk_text in enumerate(text_chunks_raw):
                # 數據清洗：在 chunk 層級進行
                if chunk_text is None or not str(chunk_text).strip():
                    continue

                # 將單個 chunk 加入到批次中
                texts_batch.append(str(chunk_text))
                embs_batch.append(emb_chunks_raw[i].tolist())
                metadatas_batch.append(chunk_metadata.copy())  # 每個 chunk 都獲得元數據
                ids_batch.append(str(uuid.uuid4()))

                # 標記此文件至少有一個有效 chunk 被處理
                if not file_processed_flag:
                    print(f"[ChromaMaker] SUCCESS: Adding {len_text} chunks from '{original_full_filename}'.")
                    processed_files_count += 1
                    processed_doc_names.add(original_full_filename)
                    file_processed_flag = True

                # 每加入一個 chunk，就檢查一次批次大小
                if len(texts_batch) >= upsert_batch_size:
                    try:
                        print(f"\n--- [ChromaMaker] 批次達到 {len(texts_batch)}，正在寫入資料庫... ---")
                        vectorstore._collection.upsert(
                            embeddings=embs_batch, documents=texts_batch, metadatas=metadatas_batch, ids=ids_batch
                        )
                        total_chunks_added += len(texts_batch)
                        print(f"   ✅ 批次寫入成功。累計已寫入 {total_chunks_added} chunks。")
                        # 清空批次列表以準備下一批
                        texts_batch, embs_batch, metadatas_batch, ids_batch = [], [], [], []
                    except Exception as e:
                        print(f"⚠️ [ChromaMaker] 寫入批次時發生嚴重錯誤: {e}。該批次數據可能已遺失。")
                        # 同樣清空批次，避免重複嘗試
                        texts_batch, embs_batch, metadatas_batch, ids_batch = [], [], [], []

            if not file_processed_flag:
                skipped_files_count += 1
                print(f"警告：在 {npy_filename} 中找不到有效的文本塊，已跳過。")

        # --- 4. 處理最後一批剩餘的數據 ---
        if texts_batch:
            try:
                print(f"\n--- [ChromaMaker] 正在寫入最後一批 {len(texts_batch)} 個 chunks... ---")
                vectorstore._collection.upsert(
                    embeddings=embs_batch, documents=texts_batch, metadatas=metadatas_batch, ids=ids_batch
                )
                total_chunks_added += len(texts_batch)
                print("   ✅ 最後一批寫入成功。")
            except Exception as e:
                print(f"⚠️ [ChromaMaker] 寫入最後一批時發生嚴重錯誤: {e}。")

        # --- 除错点 #5：打印最终总结 ---
        print("\n" + "=" * 50)
        print("ChromaMaker Processing Summary:")
        print(f"  - Total .npy files found: {len(sorted_dir_list)}")
        print(f"  - Files successfully processed: {processed_files_count}")
        print(f"  - Files skipped: {skipped_files_count}")
        print(f"  - Total chunks added to database: {total_chunks_added}")
        print("=" * 50 + "\n")
        # -------------------------------

        final_doc_names = sorted(list(processed_doc_names))

        # 檢查是否有任何 chunk 被成功加入
        if total_chunks_added == 0:
            print("警告：處理完成，但沒有任何 chunk 被成功加入到向量資料庫。")

        return vectorstore, final_doc_names

    def create_from_db(
        self,
        embedding_type: str,
        key_dict: dict,
        model_name: str,
        chunks_data: list[dict],
        persist_dir: Optional[str] = None,
    ) -> (Chroma, list[str]):
        """
        從資料庫獲取的 chunk 數據創建一個 Chroma 向量資料庫。
        """
        query_embeddings = utils.create_embeddings(
            embedding_type=embedding_type, key_dict=key_dict, model_name=model_name
        )
        vectorstore = Chroma(
            collection_name=str(uuid.uuid4()),
            embedding_function=query_embeddings,
            persist_directory=persist_dir,
        )

        if not chunks_data:
            print("Warning: No chunks data provided from the database.")
            return vectorstore, []

        import ast

        texts_batch = [chunk["content"] for chunk in chunks_data]
        embs_batch = []
        for chunk in chunks_data:
            embedding_data = chunk["embedding"]
            if isinstance(embedding_data, str):
                try:
                    # The string from the DB looks like a list representation
                    embs_batch.append(ast.literal_eval(embedding_data))
                except (ValueError, SyntaxError):
                    # Handle error or malformed string
                    raise TypeError(f"Could not parse embedding string: {embedding_data}")
            else:
                # Assume it's already a list of floats
                embs_batch.append(embedding_data)

        metadatas_batch = [
            {"source": chunk["source"], "title": chunk["title"]}
            for chunk in chunks_data
        ]
        ids_batch = [str(chunk["id"]) for chunk in chunks_data]

        vectorstore._collection.upsert(
            embeddings=embs_batch,
            documents=texts_batch,
            metadatas=metadatas_batch,
            ids=ids_batch,
        )

        processed_doc_names = set(m["source"] for m in metadatas_batch)
        final_doc_names = sorted(list(processed_doc_names))

        print("\n" + "=" * 50)
        print("ChromaMaker Processing Summary (from DB):")
        print(f"  - Total chunks added to database: {len(chunks_data)}")
        print(f"  - Total documents processed: {len(final_doc_names)}")
        print("=" * 50 + "\n")

        return vectorstore, final_doc_names

    # def create_from_persist_dir(
    #     self,
    #     persist_dir: str,
    #     service_platform: str
    # ) -> Chroma:

    #     embeddings = utils.create_embeddings(
    #         service_platform, self.key_dict
    #     )

    #     vectorstore = Chroma(
    #         persist_directory=persist_dir, embedding_function=embeddings
    #     )
    #     return vectorstore
