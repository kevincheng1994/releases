import os
from typing import Optional

import numpy as np
from langchain_community.vectorstores.faiss import FAISS

from app.modules.ragkm2.agent.utils import utils


class FaissMaker:
    def __init__(self, key_dict: dict):
        self.key_dict = key_dict

    def create_from_chunk_dir(
        self, chunk_dir: str, doc_to_metadata: dict, service_platform: str, persist_dir: Optional[str] = None
    ) -> FAISS:
        """Tree chunk_dir.

        chunk_dir/ ├── chunks/ ├── chunk1.npy
                                ├── chunk2.npy
                                └── ...
        """
        chunks_folder = os.path.join(chunk_dir, "chunks")
        embs_folder = os.path.join(chunk_dir, "embs")

        if not os.path.isdir(chunks_folder):
            raise FileNotFoundError(f"Folder not found: {chunks_folder}")
        if not os.path.isdir(embs_folder):
            raise FileNotFoundError(f"Folder not found: {embs_folder}")
        metadatas, texts, embs = [], [], []
        for textfile, embfile in zip(os.listdir(chunks_folder), os.listdir(embs_folder)):
            textfilepath = os.path.join(chunks_folder, textfile)
            embfilepath = os.path.join(embs_folder, embfile)
            text = np.load(textfilepath)
            for t in text:
                texts.append(str(t))
            emb = np.load(embfilepath)
            for e in emb:
                embs.append(e)
            len_text = len(text)
            metadata = doc_to_metadata[textfile]
            metadatas.extend([metadata] * (len_text))
        pairs = list(zip(texts, embs))
        embeddings = utils.create_embeddings(service_platform, self.key_dict)

        vectorstore = FAISS.from_embeddings(text_embeddings=pairs, metadatas=metadatas, embedding=embeddings)
        if persist_dir is not None:
            vectorstore.save_local(persist_dir)
        return vectorstore

    def create_from_persist_dir(self, persist_dir: str, service_platform: str) -> FAISS:
        embeddings = utils.create_embeddings(service_platform, self.key_dict)
        vectorstore = FAISS.load_local(persist_dir, embeddings, allow_dangerous_deserialization=True)
        return vectorstore
