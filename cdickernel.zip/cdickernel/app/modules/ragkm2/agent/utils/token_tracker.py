from typing import Any, Dict, List

from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult
from pydantic import BaseModel


class TokenModel(BaseModel):
    input_tokens: int
    output_tokens: int
    total_tokens: int

    def __add__(self, other: "TokenModel") -> "TokenModel":
        if not isinstance(other, TokenModel):
            return NotImplemented

        return TokenModel(
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
        )


class TokenModelHandler(BaseCallbackHandler):
    def __init__(self, operation: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.operation = operation
        self.token_ins = None

    def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], **kwargs: Any) -> Any:
        pass
        # print(self.operation)

    def on_llm_end(self, response: LLMResult, *args, **kwargs):
        for generations in response.generations:
            for g in generations:
                print("**************** Token Tracker ***************")
                print(self.operation)
                usage = g.to_json()["kwargs"]["message"]
                usage = usage.usage_metadata
                input_tokens = usage["input_tokens"]
                output_tokens = usage["output_tokens"]
                total_tokens = usage["total_tokens"]
                if not self.token_ins:
                    self.token_ins = TokenModel(input_tokens=0, output_tokens=0, total_tokens=0)
                ins = TokenModel(input_tokens=input_tokens, output_tokens=output_tokens, total_tokens=total_tokens)
                self.token_ins += ins
                print(self.token_ins)

                print("**********************************************")

    def on_agent_action(self, **kwargs):
        print("on agent")

    def get(self) -> TokenModel:
        if not self.token_ins:
            raise RuntimeError
        return self.token_ins


class TokenTracker:
    def __init__(self):
        self.usage: dict[str, int] = {}

    def tracker_usage(self, operation: str, token_usage: dict[str, int]) -> None:
        tokenobj = TokenModel(**token_usage)
        if operation not in self.usage:
            self.usage[operation] = None
        self.usage[operation] += tokenobj

    def get_total_usage(self) -> int:
        return sum(self.usage.values())

    def get_operation_usage(self, operation: str) -> TokenModel:
        return self.usage.get(operation, 0)

    def print_summary(self) -> None:
        print("\nToken Usage Summary:")
        print("-" * 40)
        for operation, tokens in self.usage.items():
            print(f"{operation}: {tokens:,}")
        print("-" * 40)
        total = self.get_total_usage()
        print(f"Total: {total:,}")
