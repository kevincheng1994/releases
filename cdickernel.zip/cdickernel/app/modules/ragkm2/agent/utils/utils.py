import enum
import importlib
import json
import os
import tempfile
from typing import Any, Dict

# from langchain_aws import BedrockEmbeddings
from langchain_core.embeddings import Embeddings
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings

from .token_tracker import TokenModelHandler

# from typing import List

# import numpy as np

# 將每個服務的建立邏輯封裝成獨立的函式


# def _create_bedrock_embeddings(model_name: str, key_dict: dict[str, str]) -> BedrockEmbeddings:
#     """Creates a BedrockEmbeddings instance."""
#     try:
#         import boto3
#     except ImportError:
#         raise ImportError("boto3 is not installed. Please install it with 'pip install boto3'")

#     client = boto3.client(
#         "bedrock-runtime",
#         aws_access_key_id=key_dict.get("aws_access_key_id"),
#         aws_secret_access_key=key_dict.get("aws_secret_access_key"),
#         region_name=key_dict.get("region_name"),
#     )
#     return BedrockEmbeddings(model_id=model_name, client=client)


def _create_vertexai_embeddings(model_name: str, key_dict: dict[str, str]) -> VertexAIEmbeddings:
    """Creates a VertexAIEmbeddings instance."""
    # 關於 `vertexai_helper.activate(key_dict)`:
    # 這似乎是您自訂的輔助函式。一個更標準的方式是設定環境變數
    # `GOOGLE_APPLICATION_CREDENTIALS` 指向您的 JSON 金鑰檔案。
    # 如果 LangChain 可以自動找到認證，就不需要這個 helper。
    # 這裡我們假設認證已透過環境變數或其他方式設定好。
    # 如果您仍需要它，可以在這裡呼叫 `vertexai_helper.activate(key_dict)`
    return VertexAIEmbeddings(model_name=model_name)


def _create_openai_embeddings(model_name: str, key_dict: dict[str, str]) -> AzureOpenAIEmbeddings:
    """Creates an AzureOpenAIEmbeddings instance."""
    # 對於 Azure，model_name 通常指的是 "deployment name"
    # 我們從 key_dict 中讀取 Azure 所需的特定參數

    # 為了方便，可以直接將 key_dict 中的 key 設置為環境變數
    os.environ["AZURE_OPENAI_API_KEY"] = key_dict.get("api_key")
    os.environ["AZURE_OPENAI_ENDPOINT"] = key_dict.get("azure_endpoint")

    return AzureOpenAIEmbeddings(
        azure_deployment=model_name,  # model_name 在 Azure 中對應 deployment name
        api_version=key_dict.get("api_version", "2"),  # 提供一個預設的 api_version
    )


# --- Configuration Dictionary ---
# 使用一個字典來管理所有支援的 embedding 類型

EMBEDDING_PROVIDERS = {
    # "bedrock": {
    #     "creator": _create_bedrock_embeddings,
    #     "supported_models": ["amazon.titan-embed-text-v2:0"],
    #     "default_model": "amazon.titan-embed-text-v2:0",
    # },
    "vertexai": {
        "creator": _create_vertexai_embeddings,
        "supported_models": ["textembedding-gecko-multilingual@001"],
        "default_model": "textembedding-gecko-multilingual@001",
    },
    "azure": {
        "creator": _create_openai_embeddings,
        # Azure 的模型是部署名稱，由用戶自訂，所以不在此處硬性限制
        # 如果您有固定的部署名稱，可以將它們加到列表中
        "supported_models": ["text-embedding-ada-002"],
        # Azure 沒有通用的預設模型，用戶必須指定自己的部署名稱
        # 此處留空，強制用戶傳入 model_name
        "default_model": "text-embedding-ada-002",
    },
}


class Extension(enum.Enum):
    ZIP = ".zip"
    TAR = ".tar"


def list_all_files(file_path) -> list:
    files = os.listdir(file_path)
    result = list()
    for f in files:
        fullpath = os.path.join(file_path, f)
        if os.path.isfile(fullpath):
            result.append(f)
    return result


def remove_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)


def load_module(filepath: str, module_name: str):
    """Reads file source and loads it as a module."""
    spec = importlib.util.spec_from_file_location(module_name, filepath)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return module


def load_json(filepath: str):
    with open(filepath) as f:
        return json.load(f)


def vertexai_json_to_env(key_dict):
    vertexai_json_template = (
        "type",
        "project_id",
        "private_key_id",
        "private_key",
        "client_email",
        "client_id",
        "auth_uri",
        "token_uri",
        "auth_provider_x509_cert_url",
        "client_x509_cert_url",
        "universe_domain",
    )
    config = {}
    for key in vertexai_json_template:
        if key not in key_dict:
            raise ValueError(f"missing key: {key} in key_dict")
        config[key] = key_dict
    file = tempfile.NamedTemporaryFile("w+")
    json.dump(config, file)
    file.flush()
    if "GOOGLE_APPLICATION_CREDENTIALS" in os.environ:
        print("GOOGLE_APPLICATION_CREDENTIALS is already in environment")
    else:
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = file.name
    return file


class VertexaiHelper:
    def __init__(self):
        """
        Initializes a VertexaiHelper instance to manage Vertex AI credentials:
        """
        self._once = False
        self._file = None
        self.vertexai_json_template = (
            "type",
            "project_id",
            "private_key_id",
            "private_key",
            "client_email",
            "client_id",
            "auth_uri",
            "token_uri",
            "auth_provider_x509_cert_url",
            "client_x509_cert_url",
            "universe_domain",
        )

    def activate(self, vertexai_config_dict: dict):
        if self._once:
            print("")
            return
        self._once = True
        config = {}
        for key in self.vertexai_json_template:
            if key not in vertexai_config_dict:
                raise ValueError(f"missing key: {key} in key_dict")
            config[key] = vertexai_config_dict[key]
        file = tempfile.NamedTemporaryFile("w+")
        json.dump(config, file)
        file.flush()
        self._file = file
        if "GOOGLE_APPLICATION_CREDENTIALS" in os.environ:
            print("GOOGLE_APPLICATION_CREDENTIALS is already in environment")
        else:
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = file.name


# Instantiate VertexaiHelper and hold its reference `self._file = file` to prevent garbage collection
vertexai_helper = VertexaiHelper()


def create_llm(
    llm_type: str,
    key_dict: dict,
    model_name: str = "",
    temperature: float = 0,
    token_operation: str = "",
    metadata: dict = None,
    **model_kwargs,
):
    """Creates a Large Language Model (LLM) instance, optionally routed through LiteLLM Proxy.

    Args:
        llm_type (str): The type of LLM to create. Can be one of 'azure', 'vertexai', or 'bedrock'.
        key_dict (dict): A dictionary containing the necessary keys for the chosen LLM type.
        model_name (str, optional): The name of the model to use. Defaults to an empty string.
        temperature (float, optional): The temperature value for the LLM. Defaults to 0.
        token_operation (str, optional): The name of the TokenModelHandler.
        **model_kwargs: Additional keyword arguments to pass to the model constructor,
                        e.g., max_output_tokens.

    Supported Models:
        Azure:
            - gpt-4-turbo
        Bedrock:
            - anthropic.claude-3-5-sonnet-20240620-v1:0
            - anthropic.claude-3-sonnet-20240229-v1:0
        VertexAI:
            - claude-3-5-sonnet@20240620
            - claude-3-7-sonnet@20250219
            - claude-sonnet-4@20250514

    Returns:
        An instance of the chosen LLM type.

    Raises:
        NotImplementedError: If the chosen LLM type is not supported.
        ValueError: If the provided model name is not supported by the chosen LLM type.
    """

    llm_type = llm_type.lower()
    proxy_url = os.getenv("LITELLM_API_BASE_PROXY")
    proxy_key = os.getenv("LITELLM_API_KEY")

    final_model_kwargs = {"temperature": temperature, **model_kwargs}
    
    # --- Option 1: Route through LiteLLM Proxy (Recommended for Tracking) ---
    if proxy_url and proxy_key:
        if model_name == "":
            raise ValueError("model_name is required when using LiteLLM Proxy to ensure proper routing and tracking.")

        from langchain_openai import ChatOpenAI

        # Combine provider and model for LiteLLM routing (e.g., azure/gpt-4o)
        litellm_model = f"{llm_type}/{model_name}"
        
        extra_body = {"drop_params": True}
        if metadata:
            extra_body["tags"] = [f"{k}:{v}" for k, v in metadata.items()]

        print(f"Routing LLM through LiteLLM Proxy: {litellm_model}")

        return ChatOpenAI(
            model=model_name,
            openai_api_key=proxy_key,
            openai_api_base=proxy_url,
            extra_body=extra_body,
            **final_model_kwargs
        )

    # --- Option 2: Direct Connection (Fallback) ---
    if llm_type not in ["azure", "vertexai", "bedrock", "ollama"]:
        raise NotImplementedError(f"{llm_type} is not supported")

    final_model_kwargs = {"temperature": temperature, **model_kwargs}

    supported_azure_models = ["gpt-4o"]
    # vertexai_supported_models = []
    supported_bedrock_models = [
        "anthropic.claude-3-5-sonnet-20240620-v1:0",
        "anthropic.claude-3-sonnet-20240229-v1:0",
    ]
    supporter_vertexai_models = ["claude-3-5-sonnet@20240620", "claude-3-7-sonnet@20250219", "claude-sonnet-4@20250514"]

    # supported_bedrock_models = {
    #     "claude 3.5 sonnet": "anthropic.claude-3-5-sonnet-20240620-v1:0",
    #     "claude 3 sonnet": "anthropic.claude-3-sonnet-20240229-v1:0",
    # }

    # supporter_vertexai_models = {
    #     "claude 3.5 sonnet": "claude-3-7-sonnet@20250219",
    #     # 'claude 3.5 sonnet': 'claude-3-5-sonnet@20240620',
    #     "gemini-2.0-flash": "gemini-2.5-pro",
    # }

    model_name = model_name.lower()
    if llm_type == "azure":
        if model_name == "":
            model_name = supported_azure_models[0]
        if model_name not in supported_azure_models:
            raise ValueError(f"{model_name} is not supported by Azure")

        from langchain_openai import AzureChatOpenAI

        # https://stackoverflow.com/questions/79039544/openai-api-error-invalid-parameter-response-format-of-type-json-schema-is
        # structured outputs and json mode is different
        key_dict = key_dict["azure"]
        llm = AzureChatOpenAI(
            openai_api_key=key_dict.get("api_key"),
            azure_endpoint=key_dict.get("azure_endpoint"),
            openai_api_version=key_dict.get("api_version"),
            deployment_name=key_dict.get("deployment_name"),
            model_name=key_dict.get("model_name"),
            # temperature=temperature,
            max_retries=2,  # 2 -> retry only once
            **final_model_kwargs,
        )
    elif llm_type == "bedrock":
        if model_name == "":
            model_name = "anthropic.claude-3-5-sonnet-20240620-v1:0"
        if model_name not in supported_bedrock_models:
            raise ValueError(f"{model_name} is not supported by Azure")

        model_name = supported_bedrock_models[model_name]

        import boto3
        from langchain_aws import ChatBedrock

        key_dict = key_dict["bedrock"]
        client = boto3.client(
            "bedrock-runtime",
            aws_access_key_id=key_dict.get("aws_access_key_id"),
            aws_secret_access_key=key_dict.get("aws_secret_access_key"),
            region_name=key_dict.get("region_name"),
        )
        if "max_output_tokens" in final_model_kwargs:
            final_model_kwargs["max_tokens"] = final_model_kwargs.pop("max_output_tokens")

        llm = ChatBedrock(
            model_id=model_name,
            client=client,
            model_kwargs=final_model_kwargs,  # model_kwargs={"temperature": temperature, "max_tokens": 10000}
        )
    elif llm_type == "vertexai":
        if model_name == "":
            model_name = "claude-3-5-sonnet@20240620"
        if model_name not in supporter_vertexai_models:
            raise ValueError(f"{model_name} is not supported by VertexAi")

        # model_name = supporter_vertexai_models[model_name]
        if "claude" in model_name.lower():
            from langchain_google_vertexai.model_garden import ChatAnthropicVertex

            key_dict = key_dict["vertexai"]
            vertexai_helper.activate(key_dict)
            vertexai_api_templage = ("location", "project_id")
            for key in vertexai_api_templage:
                if key not in key_dict:
                    raise ValueError(f"missing key: {key} in key_dict")

            callbacks = []
            # if token_operation != "":
            #     callbacks.append(TokenModelHandler(token_operation))
            llm = ChatAnthropicVertex(
                # model_name=model_name,
                model_name=model_name,
                location=key_dict["location"],
                project=key_dict["project_id"],
                callbacks=callbacks,
                # temperature=temperature,
                **final_model_kwargs,
            )

            print(f"{token_operation}: use vertexai claude {model_name}")
        elif "gemini" in model_name.lower():
            from langchain_google_vertexai import ChatVertexAI

            key_dict = key_dict["vertexai"]
            vertexai_helper.activate(key_dict)
            llm = ChatVertexAI(
                model=model_name,
                # temperature=temperature,
                **final_model_kwargs,
            )
    elif llm_type == "ollama":
        if model_name == "":
            raise RuntimeError("no model name in ollama")
        from langchain_ollama.llms import OllamaLLM

        llm = OllamaLLM(model=model_name)

        # llm = OllamaLLM(model=model_name, max_tokens=512)
        # llm = OllamaLLM(model=model_name, base_url='localhost:11196')

    return llm


def create_embeddings(
    embedding_type: str, 
    key_dict: dict[str, Any], 
    model_name: str = "", 
    metadata: dict = None
) -> Embeddings:
    """
    Creates an embedding client from a specified provider, optionally via LiteLLM Proxy.

    Args:
        embedding_type: The type of embedding provider (e.g., "bedrock", "vertexai", "azureopenai").
        key_dict: A dictionary containing API keys and other necessary credentials.
                  The structure should be:
                  {
                      "bedrock": {"aws_access_key_id": "...", ...},
                      "vertexai": {"project": "...", ...},
                      "azureopenai": {"api_key": "...", "azure_endpoint": "...", ...}
                  }
        model_name: The specific model or deployment name to use. If empty, a default is used.

    Returns:
        An instance of a LangChain embedding class.

    Raises:
        NotImplementedError: If the embedding_type is not supported.
        ValueError: If a required model_name is not provided or is not supported.
    """
    embedding_type = embedding_type.lower()
    proxy_url = os.getenv("LITELLM_API_BASE_PROXY")
    proxy_key = os.getenv("LITELLM_API_KEY")

    # --- Option 1: Route through LiteLLM Proxy (Recommended for Tracking) ---
    if proxy_url and proxy_key:
        if model_name == "":
            raise ValueError("model_name is required when using LiteLLM Proxy to ensure proper routing and tracking.")

        from langchain_openai import OpenAIEmbeddings
        
        litellm_model = f"{embedding_type}/{model_name}"
        
        print(f"Routing Embeddings through LiteLLM Proxy: {litellm_model}") 
        
        extra_body = {}
        if metadata:
            extra_body["tags"] = [f"{k}:{v}" for k, v in metadata.items()]

        return OpenAIEmbeddings(
            model=litellm_model,
            openai_api_key=proxy_key,
            openai_api_base=proxy_url,
            model_kwargs={"extra_body": extra_body} if extra_body else {}
        )

    # --- Option 2: Direct Connection (Fallback) ---
    if embedding_type not in EMBEDDING_PROVIDERS:
        raise NotImplementedError(
            f"Embedding type '{embedding_type}' is not supported. "
            f"Supported types are: {list(EMBEDDING_PROVIDERS.keys())}"
        )

    config = EMBEDDING_PROVIDERS[embedding_type]

    # 1. 決定 model_name
    if not model_name:
        model_name = config["default_model"]
        if not model_name:
            raise ValueError(f"model_name is required for embedding_type '{embedding_type}'")

    # 2. 驗證 model_name (如果需要)
    supported_models = config["supported_models"]
    if supported_models and model_name not in supported_models:
        raise ValueError(
            f"Model '{model_name}' is not in the supported list for {embedding_type}. "
            f"Supported models: {supported_models}"
        )

    # 3. 取得對應的 key，並呼叫建立函式
    provider_keys = key_dict.get(embedding_type)
    if not provider_keys:
        raise ValueError(f"Key dictionary for '{embedding_type}' not found in key_dict.")

    creator_func = config["creator"]
    embeddings = creator_func(model_name, provider_keys)

    return embeddings
