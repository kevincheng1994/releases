class ErrorCode:
    REQUESTLIMIT = 400
    FORMAT = 401
    NOKNOWLEDGEBASE = 402  # knowledge base is empty
    ELSEERROR = 403
    HARMFULINPUT = 404
    HARMFULRESPONSE = 405
    REPEAT = 406
    INVALIDFORMAT = 407
    ABNORMALRESPONSE = 408

    @staticmethod
    def is_error_status(input):
        if (
            input == ErrorCode.REQUESTLIMIT
            or input == ErrorCode.FORMAT
            or input == ErrorCode.ELSEERROR
            or input == ErrorCode.NOKNOWLEDGEBASE
            or input == ErrorCode.HARMFULINPUT
            or input == ErrorCode.HARMFULRESPONSE
        ):
            return True
        return False


class ReturnProcess:
    COMPLETION = 200
    AGENT = 201
    BEAST_ANSWER = 202
    REPHRASE = 203
    SUMMARY = 204
    MARKDOWN = 205
