from collections import defaultdict
from typing import Optional
from langchain_community.retrievers import BM25Retriever
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

try:
    from sentence_transformers import CrossEncoder

    _SENTENCE_TRANSFORMERS_INSTALLED = True
except ImportError:
    _SENTENCE_TRANSFORMERS_INSTALLED = False
    CrossEncoder = None


class BM25SimilarityEnsembleRetriever:
    """
    一個混合式檢索器，結合了 BM25 關鍵字搜索和 ChromaDB 向量相似度搜索。
    可選地，它還能使用一個 Cross-Encoder 模型（Reranker）對初步結果進行精確重排。
    """

    def __init__(
        self,
        db: Chroma,
        k: int,
        final_k: int,
        weights: list = None,
        c: float = 60,
        reranker_model_name: Optional[str] = "BAAI/bge-reranker-base",  # 預設使用 BGE Reranker
    ):
        # def __init__(self, db: Chroma, k: int, weights: list = None, c: float = 60):
        """
        初始化檢索器。

        Args:
            db (Chroma): ChromaDB 實例。
            k (int): 最終要返回的文件數量。
            weights (list, optional): BM25 和向量搜索的權重。預設為 [0.5, 0.5]。
            c (float, optional): RRF 平滑因子。預設為 60。
            reranker_model_name (Optional[str]): 要使用的 Hugging Face Cross-Encoder 模型名稱。
                                                 設為 None 則禁用 Reranker。
        """
        if weights is not None and len(weights) != 2:
            raise ValueError("Number of weights must be equal to 2.")

        self.db = db
        self.k = k  # 這是初始召回的 k
        self.final_k = final_k  # 這是最終要返回的 k
        self.weights = weights if weights else [0.5, 0.5]
        self.c = c
        self.reranker = None

        if reranker_model_name:
            if not _SENTENCE_TRANSFORMERS_INSTALLED:
                print("⚠️ 警告：sentence-transformers 未安装，Reranker被禁用")
            else:
                try:
                    print(f"正在初始化 Reranker 模型: '{reranker_model_name}'...")
                    # CrossEncoder 會自動處理模型下載和快取
                    self.reranker = CrossEncoder(reranker_model_name)
                    print("✅ Reranker 初始化成功。")
                except Exception as e:
                    print(f"⚠️ Reranker 初始化失敗: {e}。將禁用 Reranker 功能。")
                    self.reranker = None

    def invoke(self, input: str, filter: Optional[dict] = None) -> list[Document]:
        """
        主調用接口，執行「召回 + 重排」流程。
        """
        try:
            # from itertools import count
            from pathlib import Path

            # 你要輸出的目錄（可改成 "." 表示目前目錄）
            output_dir = Path("fused_outputs")
            output_dir.mkdir(parents=True, exist_ok=True)

            fused_documents = self.rank_fusion(input, self.k, filter)

            if not fused_documents:
                return []

            # 找到下一個可用的序號並建立檔案
            # for i in count(0):
            #     out_path = output_dir / f"fused_documents_{i}.txt"
            #     try:
            #         with open(out_path, "x", encoding="utf-8") as f:  # "x"：檔案存在就丟 FileExistsError
            #             for idx, doc in enumerate(fused_documents, start=1):
            #                 f.write(f"{idx}. {doc}\n")
            #         print(f"Saved: {out_path}")
            #         break
            #     except FileExistsError:
            #         continue

            # 2. 如果 Reranker 已啟用，則執行重排
            if self.reranker:
                print(f"✅ Reranker 已啟用，正在對 {len(fused_documents)} 個召回文件進行重排...")

                # 準備 Reranker 需要的輸入格式：[(query, doc_content), ...]
                sentence_pairs = [(input, doc.page_content) for doc in fused_documents]

                # 執行 Reranker 評分
                scores = self.reranker.predict(sentence_pairs)

                # 將分數與文件配對，並按分數降序排序
                doc_score_pairs = list(zip(fused_documents, scores))
                doc_score_pairs.sort(key=lambda x: x[1], reverse=True)

                # 提取排序後的文件，並只返回前 k 個
                reranked_docs = [doc for doc, score in doc_score_pairs]
                return reranked_docs[: self.final_k]

            # 3. 如果 Reranker 未啟用，則返回 RRF 融合後的結果
            else:
                return fused_documents[: self.k]

            # result = self.rank_fusion(input, self.k, filter)
            # return result
        except Exception as e:
            # 不要再向上拋出異常，而是返回一個描述性的字串
            # 這是讓 Agent 能夠進行「第二次思考」的關鍵
            print(f"⚠️ 檢索器在執行時發生錯誤: {e}。")
            # 返回一個空的 Document 列表，或者一個包含錯誤信息的 Document
            # 這裡我們返回一個空的列表，讓 Agent 知道「什麼都沒找到」
            return []

    def rank_fusion(self, query: str, k: int, filter: Optional[dict] = None) -> list[Document]:
        """
        執行檢索和 RRF 排名融合
        """
        """Retrieve the results of the retrievers and use rank_fusion_func to
        get the final result.

        Args:
            query: The query to search for.

        Returns:
            A list of reranked documents.
        """

        retriever_docs = []  # Get the results of all retrievers

        # 1. 根據 filter 獲取候選文件
        # .get() 在找不到時會返回空的列表，不會拋出錯誤
        filtered_docs_data = self.db.get(where=filter) if filter else self.db.get()

        if not filtered_docs_data or not filtered_docs_data.get("documents"):
            print("⚠️ 根據過濾條件未找到任何文件。")
            # 如果初步過濾就找不到任何文件，直接返回空列表
            # Agent 會觀察到這個空的結果，並進行下一步思考
            return []

        filtered_docs = [
            Document(page_content=doc, metadata=meta)
            for doc, meta in zip(filtered_docs_data["documents"], filtered_docs_data["metadatas"])
        ]

        # 2. 建立 BM25 檢索器
        try:
            bm25_retriever = BM25Retriever.from_documents(filtered_docs)
            print("✅ BM25Retriever 成功建立。")
            bm25_retriever.k = k
            # bm25_docs = bm25_retriever.get_relevant_documents(query)
            bm25_docs = bm25_retriever.invoke(query)
            retriever_docs.append(bm25_docs)
        except ValueError as e:
            print(f"⚠️ 無法建立 BM25Retriever：{e}")
            retriever_docs.append([])

        # 3. 執行向量搜尋
        # 注意：Chroma 的 as_retriever 可能不直接接受 dict filter，
        # 但其底層的 query 方法接受。這裡假設 invoke 能正確處理。
        # 如果這裡也出錯，invoke 外層的 try-except 會捕捉到。
        retriever = self.db.as_retriever(search_kwargs={"k": k, "filter": filter})
        similarity_docs = retriever.invoke(query)  # 這裡的 filter 參數名可能需要確認
        retriever_docs.append(similarity_docs)

        # # Enforce that retrieved docs are Documents for each list in retriever_docs
        # for i in range(len(retriever_docs)):
        #     retriever_docs[i] = [
        #         Document(page_content=cast(str, doc)) if isinstance(doc, str) else doc for doc in retriever_docs[i]
        #     ]

        # apply rank fusion
        fused_documents = self.weighted_reciprocal_rank(retriever_docs)
        return fused_documents

    def weighted_reciprocal_rank(self, doc_lists: list) -> list:
        """
        執行加權倒數排名融合
        """
        if len(doc_lists) != len(self.weights):
            raise ValueError("Number of rank lists must be equal to the number of weights.")

        rrf_score: dict[str, float] = defaultdict(float)
        doc_metadata_map: dict[str, dict] = {}

        for doc_list, weight in zip(doc_lists, self.weights):
            for rank, doc in enumerate(doc_list, start=1):
                content = doc.page_content
                rrf_score[doc.page_content] += weight / (rank + self.c)
                if content not in doc_metadata_map:
                    doc_metadata_map[content] = doc.metadata

        # Docs are deduplicated by their contents then sorted by their scores
        # all_docs = chain.from_iterable(doc_lists)
        # unique_docs = {doc.page_content: doc for doc in all_docs}
        # sorted_docs = sorted(unique_docs.values(), key=lambda doc: rrf_score[doc.page_content], reverse=True)
        sorted_contents = sorted(rrf_score.keys(), key=lambda x: rrf_score[x], reverse=True)

        sorted_docs = [
            Document(page_content=content, metadata=doc_metadata_map[content]) for content in sorted_contents
        ]
        return sorted_docs
