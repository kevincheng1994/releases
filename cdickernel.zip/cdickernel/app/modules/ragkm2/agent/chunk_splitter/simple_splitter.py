import os
import re
from typing import Any, Dict, List, Tuple

import tiktoken
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import Docx2txtLoader, PyPDFLoader

from .base_splitter import BaseChunkSplitter


class SimpleChunkSplitter(BaseChunkSplitter):

    def __init__(self, chunk_size: int, ocr_mode: str = "auto", metadata: dict = None, **kwargs):
        """Initialize the SimpleChunkSplitter.

        Args:
            chunk_size (int): The maximum number of tokens or characters per chunk.
            ocr_mode (str): OCR mode, one of:
                - 'always': Always use OCR to extract text (even if text is already extractable).
                - 'never': Never use OCR; if parsing fails, skip or return empty.
                - 'auto': Automatically decide whether to use OCR based on document content.
            **kwargs: Additional keyword arguments passed to the BaseChunkSplitter.

        Raises:
            ValueError: If the ocr_mode is not one of the supported options.
        """
        if ocr_mode not in {"always", "never", "auto"}:
            raise ValueError(f"Invalid ocr_mode: '{ocr_mode}'. Must be one of 'always', 'never', or 'auto'.")
        self.chunk_size = chunk_size
        self.ocr_mode = ocr_mode
        super().__init__(metadata=metadata, **kwargs)

    def _read_doc(self, filepath: str) -> str:
        """Read the content of a document file.

        Args:
            filepath (str): The path to the document file.

        Returns:
            str: The text content of the document.

        Raises:
            FileNotFoundError: If the file does not exist.
            NotImplementedError: If the file format is not supported.
        """

        ocr_mode = self.ocr_mode
        if not os.path.isfile(filepath):
            # raise FileNotFoundError(filepath)
            # 改為打印警告並返回空字串，避免中斷整個流程
            if self.verbose:
                print(f"Warning: File not found at {filepath}, skipping.")
            return ""

        text = ""
        filename = os.path.basename(filepath)

        if ".pdf" in filename and "Zone.Identifier" not in filename:
            use_ocr = ocr_mode == "always" or (ocr_mode == "auto" and self._is_pdf_need_ocr(filepath))
            if self.verbose:
                print(f"OCR mode for {filename}: '{ocr_mode}', Using OCR: {use_ocr}")

            if use_ocr:
                text = self._azure_analyze_document(filepath)
                if self.verbose:
                    print(f"Extracted via Azure OCR: {text[:100]}...")

            else:
                try:
                    loader = PyPDFLoader(filepath)
                    documents = loader.load()
                    text = "".join([doc.page_content for doc in documents])
                    if self.verbose:
                        print(f"Extracted via PyPDFLoader: {text[:100]}...")
                except Exception as e:
                    if self.verbose:
                        print(f"PyPDFLoader failed: {e}. Falling back to OCR if applicable.")

                    if ocr_mode != "never":  # auto or always mode
                        text = self._azure_analyze_document(filepath)
                        if self.verbose:
                            print(f"Extracted via Azure OCR on fallback: {text[:100]}...")

        elif ".docx" in filename:
            loader = Docx2txtLoader(filepath)
            documents = loader.load()
            text = "".join([doc.page_content for doc in documents])
        elif ".txt" in filename or ".md" in filename:
            try:
                with open(filepath, encoding="utf-8") as f:
                    text = f.read()
            except Exception as e:
                if self.verbose:
                    print(f"Error reading text file {filename}: {e}")
                text = ""  # 失敗時返回空字串
        else:
            # raise NotImplementedError(f'only support pdf and docx, {filename}')
            if self.verbose:
                print(f"Unsupported file type for {filename}, skipping.")

        if text:
            # 移除 HTML 註解，例如 <!-- PageNumber="戊-52" -->
            text = re.sub(r"<!--.*?-->", "", text, flags=re.DOTALL)
            # 移除其他可能的 HTML 標籤
            text = re.sub(r"<[^>]+>", "", text)
            # 將多個連續的換行符和空白符合併為兩個換行符，以保持段落間距
            text = re.sub(r"(\n\s*){2,}", "\n\n", text).strip()

        return text

    # 'cl100k_base' 是更新、更常用的模型編碼
    def _count_tokens(self, text: str, encoding_name: str = "cl100k_base"):
        try:
            encoding = tiktoken.get_encoding(encoding_name)
        except ValueError:
            encoding = tiktoken.get_encoding("gpt2")  # 保留 gpt2 作為備援
        return len(encoding.encode(text))

    def _split_and_emb_text(
        self, text: str, filepath: str
    ) -> tuple[list[str], list[list[float]], list[dict[str, Any]]]:
        text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
            chunk_size=self.chunk_size,
            chunk_overlap=int(self.chunk_size * 0.5),  # 設置50%的重疊，有助於上下文連貫
        )
        all_chunks_raw = text_splitter.split_text(text)
        if not all_chunks_raw:
            return [], [], []

        # 過濾掉無效或僅包含元數據標籤的 chunk
        all_chunks = []
        for chunk in all_chunks_raw:
            stripped_chunk = chunk.strip()
            # 確保 chunk 不是空的，並且不只是以 HTML 註解開頭和結尾
            if stripped_chunk and not (stripped_chunk.startswith("<!--") and stripped_chunk.endswith("-->")):
                all_chunks.append(chunk)

        if not all_chunks:
            if self.verbose:
                print(f"Warning: After filtering, no valid chunks were found in '{os.path.basename(filepath)}'.")
            return [], [], []

        # VertexAI限制20000
        # 我們設定一個略低的安全邊際，例如 19000
        API_TOKEN_LIMIT = 19000
        # Vertex AI 還有一個單次請求的文件數量上限，通常是 250
        API_DOCS_LIMIT = 250

        all_embs = []
        current_batch_chunks = []
        current_batch_tokens = 0

        if self.verbose:
            print(f"總共有 {len(all_chunks)} 個 chunks，將進行動態批次化 Embedding...")

        for chunk in all_chunks:
            # 計算當前 chunk 的 token 數
            chunk_token_count = self._count_tokens(chunk)

            # 檢查加入這個 chunk 後，是否會超過 Token 上限或文件數量上限
            if (
                current_batch_tokens + chunk_token_count > API_TOKEN_LIMIT
                or len(current_batch_chunks) >= API_DOCS_LIMIT
            ):

                # 如果會超過，就先處理目前的這一批
                if self.verbose:
                    print(f"處理批次：包含 {len(current_batch_chunks)} 個 chunks，總計 {current_batch_tokens} tokens。")
                batch_embs = self.emb_model.embed_documents(current_batch_chunks)
                all_embs.extend(batch_embs)

                # 重置批次，並將當前的 chunk 作為新批次的第一個元素
                current_batch_chunks = [chunk]
                current_batch_tokens = chunk_token_count
            else:
                # 如果不會超過，就把這個 chunk 加入目前的批次
                current_batch_chunks.append(chunk)
                current_batch_tokens += chunk_token_count

        # 處理最後一批剩餘的 chunks
        if current_batch_chunks:
            if self.verbose:
                print(f"處理最後一批：包含 {len(current_batch_chunks)} 個 chunks，總計 {current_batch_tokens} tokens。")
            batch_embs = self.emb_model.embed_documents(current_batch_chunks)
            all_embs.extend(batch_embs)

            # (可選) 在處理大量文件時加入短暫的延遲，避免觸發 API 的速率限制 (rate limit)
            # import time
            # time.sleep(0.5)

        if self.verbose:
            print("所有批次的 Embedding 都已完成。")

        # 這個摘要將作為路由檢索的依據。我們只取文件的前 4000 個字元來生成，以平衡效率和代表性。
        # 注意：這裡的實現是一個簡化的概念，未來可以引入 LLM 來生成更高品質的摘要。
        summary_preview = text[:4000].strip()
        document_summary = f"這份文件 '{os.path.basename(filepath)}' 的開頭內容摘要為：{summary_preview}"

        metadatas = []
        filename = os.path.basename(filepath)
        title, _ = os.path.splitext(filename)  # 在這裡就處理好 title

        # generic_id 暫時沒用到
        for i, chunk_content in enumerate(all_chunks):
            generic_ids = re.findall(r"\b([A-Z]+(?:-[A-Za-z0-9]+)+)\b", chunk_content)

            metadata = {
                "source": filename,  # 完整檔名
                "title": title,  # 不含副檔名的標題
                "chunk_id": f"{title}_{i}",
                "document_summary": document_summary,
            }

            if generic_ids:
                metadata["generic_ids"] = generic_ids

            metadatas.append(metadata)

        return all_chunks, all_embs, metadatas

    def split_and_emb_from_filepath(self, filepath: str) -> tuple[list[str], list[list[float]], list[dict]]:
        text = self._read_doc(filepath)
        # 如果 _read_doc 返回空，應提前終止，避免不必要的計算
        if not text or not text.strip():
            return [], [], []

        return self._split_and_emb_text(text, filepath)
