from .base_splitter import BaseChunkSplitter
from .page_splitter import PageChunkSplitter
from .simple_splitter import SimpleChunkSplitter

__all__ = ["BaseChunkSplitter", "SimpleChunkSplitter", "PageChunkSplitter"]


SUPPORTED_TYPES = ["simple", "page"]
