import argparse
import os
from datetime import datetime
from pathlib import Path

from modules.ragkm2.agent import chunk_splitter
from modules.ragkm2.agent.chunk_splitter import BaseChunkSplitter
from modules.ragkm2.agent.configs import retrieve_chunk_id_config as Configs
from modules.ragkm2.agent.configs.keys import azuer_document_intelligence_key


def main(args):
    config_dict = getattr(Configs, args.configname)
    embeddings_kwargs = {
        "embedding_type": config_dict["embedding_type"],
        "key_dict": config_dict["key_dict"],
        "model_name": config_dict["model_name"],
    }

    splitter_specific_kwargs = {
        "chunk_size": args.chunk_size,
        "ocr_mode": args.ocr_mode,
        "org_extension": ".none",  # server端會帶入project ID
        "azure_endpoint": azuer_document_intelligence_key["azure"]["azure_endpoint"],
        "azure_key": azuer_document_intelligence_key["azure"]["azure_key"],
        "verbose": True,
    }

    splitter = BaseChunkSplitter.create(
        splitter_type=args.split_type, embeddings_kwargs=embeddings_kwargs, **splitter_specific_kwargs
    )

    # savepath 現在是我們期望的、最終的、乾淨的符號連結路徑
    # 例如: "storage/azure"
    final_symlink_path = Path(args.savepath)

    # 我們從這個路徑推斷出基礎名稱和父目錄
    base_storage_dir_name = final_symlink_path.name  # 結果: "azure"
    storage_parent_dir = final_symlink_path.parent  # 結果: "storage"

    # 3. 創建帶有時間戳的、實際儲存資料的新目錄
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # 新的真實目錄名稱會是 "azure_2025..."
    actual_storage_dir = storage_parent_dir / f"{base_storage_dir_name}_{timestamp}"
    print(f"新知識庫將被創建於: {actual_storage_dir}")

    os.makedirs(actual_storage_dir, exist_ok=True)

    # 4. 呼叫 split_folder，目標仍然是新的時間戳目錄
    splitter.split_folder(src_folder=args.src, target_folder=str(actual_storage_dir))

    # 5. 原子化地更新符號連結 (現在更新的是 final_symlink_path)
    print(f"處理完成。現在更新 '{final_symlink_path}' 指向新目錄...")

    # 檢查目標路徑是否已經存在（無論是檔案、目錄還是符號連結）
    if os.path.lexists(final_symlink_path):
        print(f"正在移除舊的 '{final_symlink_path}'...")
        # 如果它是一個符號連結，os.remove 可以安全地刪除它
        # 如果它是一個真實的目錄（例如第一次運行後留下的），我們需要用 rmtree
        # 為了安全和簡單，我們假設它主要是符號連結
        os.remove(final_symlink_path)

    # 創建一個新的符號連結，從 `storage/azure` 指向 `azure_2025...`
    # os.symlink 的第一個參數是「目標」，第二個是「連結名稱」
    os.symlink(actual_storage_dir.name, final_symlink_path)
    print(f"✅ 符號連結更新成功！應用程式現在可以透過 '{final_symlink_path}' 使用最新的知識庫。")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("src", help="file to split")
    # p.add_argument(
    #     '-p', '--platform', choices=['bedrock', 'azure', 'vertexai'],
    #     default='bedrock'
    # )
    p.add_argument("-s", "--savepath", type=str, required=True)
    # p.add_argument(
    #     '--configfile', type=str,
    #     default=f'{AIDVISOR_DIR}/aidvisor_langchain/configs/embeddings_configs.py'
    # )
    p.add_argument("--configname", type=str, choices=Configs.SPLIT_DOC_CONFIGS)
    p.add_argument("-c", "--chunk_size", type=int, default=512)
    p.add_argument(
        "--split_type", type=str, choices=chunk_splitter.SUPPORTED_TYPES, required=True, help="要使用的分塊器類型"
    )
    p.add_argument(
        "--ocr_mode",
        type=str,
        choices=["never", "auto", "always"],
        default="auto",
        help='OCR mode: "never" to disable OCR, "always" to always use OCR, "auto" to decide based on file content.',
    )
    args = p.parse_args()

    main(args)
