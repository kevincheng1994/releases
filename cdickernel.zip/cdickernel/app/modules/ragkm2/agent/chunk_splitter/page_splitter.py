import os

from langchain_community.document_loaders import PyMuPDFLoader

from .base_splitter import BaseChunkSplitter


class PageChunkSplitter(BaseChunkSplitter):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _read_doc(self, filepath: str) -> list[str]:
        if not os.path.isfile(filepath):
            raise FileNotFoundError(filepath)

        if ".pdf" in os.path.basename(filepath):
            loader = PyMuPDFLoader(filepath)
            documents = loader.load()
            texts = [doc.page_content for doc in documents]
        else:
            raise NotImplementedError(f"only support pdf, {filepath}")
        return texts

    def split_and_emb_from_filepath(self, filepath: str) -> (list[str], list[str]):
        chunks = self._read_doc(filepath)
        embs = self.emb_model.embed_documents(chunks)
        return chunks, embs
