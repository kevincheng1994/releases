import os
from abc import ABC, abstractmethod
from typing import List

import fitz
import numpy as np
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import DocumentContentFormat
from azure.core.credentials import AzureKeyCredential

from ..utils import utils

SUPPORTED_TYPES = ["simple", "page"]


class BaseChunkSplitter(ABC):
    def __init__(
        self,
        embeddings_kwargs: dict,
        org_extension: str,
        azure_endpoint: str = None,
        azure_key: str = None,
        verbose: bool = True,
        metadata: dict = None,
        **kwargs,
    ):
        self.metadata = metadata or {}
        self.emb_model = utils.create_embeddings(
            **embeddings_kwargs, 
            metadata=self.metadata
        )
        self.org_extension = org_extension

        self.verbose = verbose

        self._azure_dic = None
        if azure_endpoint and azure_key:
            self._azure_dic = DocumentIntelligenceClient(
                endpoint=azure_endpoint, credential=AzureKeyCredential(azure_key)
            )

    def _is_pdf_need_ocr(
        self,
        pdf_filename: str,
        text_len_threshold: int = 100,
        text_threshold: float = 0.5,
    ):
        """Check if the PDF file needs OCR."""
        doc = fitz.open(pdf_filename)
        text_pages = 0
        total_pages = len(doc)

        for page in doc:
            text = page.get_text().strip()
            if len(text) > text_len_threshold:
                text_pages += 1

        text_ratio = text_pages / total_pages

        print(f"Text pages: {text_pages}/{total_pages} ({text_ratio:.2%})")

        return text_ratio < text_threshold

    def _azure_analyze_document(self, filename: str):
        if not self._azure_dic:
            raise RuntimeError("azure DocumentIntelligenceClient is not initialized")

        with open(filename, "rb") as f:
            poller = self._azure_dic.begin_analyze_document(
                "prebuilt-layout",
                f,
                output_content_format=DocumentContentFormat.MARKDOWN,
            )
        result = poller.result()
        return result.content

    @abstractmethod
    def split_and_emb_from_filepath(self, text: str) -> (list[str], list[str]):
        """
        Read file, split it, create embeddings, and generate metadatas.

        Returns:
            A tuple containing:
            - texts (List[str]): A list of text chunks.
            - embeddings (List[List[float]]): A list of embeddings for each chunk.
            - metadatas (List[Dict[str, Any]]): A list of metadata dictionaries for each chunk.
        """

    def split_folder(self, src_folder: str, target_folder: str):
        os.makedirs(os.path.join(target_folder, "chunks"), exist_ok=True)
        os.makedirs(os.path.join(target_folder, "embs"), exist_ok=True)
        os.makedirs(os.path.join(target_folder, "metadatas"), exist_ok=True)

        for filename in os.listdir(src_folder):
            if self.verbose:
                print(f"Processing {filename}")

            full_filepath = os.path.join(src_folder, filename)

            texts, embs, metadatas = self.split_and_emb_from_filepath(full_filepath)

            # 如果文件處理後沒有產生任何 chunk，則跳過，避免儲存空檔案
            if not texts:
                if self.verbose:
                    print(f"Skipping {filename} as it produced no chunks.")
                continue

            # 定義保存路徑
            base_name = os.path.basename(filename)
            texts_path = os.path.join(target_folder, "chunks", f"{base_name}{self.org_extension}.npy")
            embs_path = os.path.join(target_folder, "embs", f"{base_name}{self.org_extension}.npy")
            metadatas_path = os.path.join(target_folder, "metadatas", f"{base_name}{self.org_extension}.npy")

            np.save(texts_path, np.array(texts, dtype=object))
            np.save(embs_path, np.array(embs, dtype=object))
            np.save(metadatas_path, np.array(metadatas, dtype=object))

    @classmethod
    def create(cls, splitter_type: str, *args, **kwargs):
        stype = splitter_type.lower()
        scls = None
        if stype == "simple":
            from .simple_splitter import SimpleChunkSplitter as scls
        elif stype == "page":
            from .page_splitter import PageChunkSplitter as scls
        if scls is None:
            raise NotImplementedError
        return scls(*args, **kwargs)
