from typing import List, Tuple
from uuid import UUID

from app.modules.ragkm2.agent.agent.taipower.taipower_agent import TaipowerAgent
from app.modules.ragkm2.agent.status_code import ReturnProcess
from app.modules.ragkm2.agent.utils import utils
from app.modules.ragkm2.agent.repository import KnowledgeBaseRepository


class RAGKM2Service:
    _agent_cache = {}

    def __init__(self):
        config_path = "app/modules/ragkm2/agent/configs"
        self.configs = utils.load_module(f"{config_path}/taipower.py", "configs")
        self.repository = KnowledgeBaseRepository()

    async def _get_agent(self, knowledge_bases_id: str, model_name: str | None = None) -> TaipowerAgent:
        # cache_key = f"{account}:{kb_name}"
        # if cache_key in self._agent_cache:
        #     return self._agent_cache[cache_key]

        if model_name:
            configs = self.configs.get_configs_for_model(model_name)
        else:
            configs = self.configs.configs

        agent = await TaipowerAgent.create_from_config(configs, knowledge_bases_id)
        # self._agent_cache[cache_key] = agent
        return agent

    async def query(
        self,
        knowledge_bases_id: str,
        question: str,
        chat_history: list = [],
    ) -> str:
        """
        單次查詢（不回傳參考資料），供向下相容的 /query 端點使用。
        """
        answer, _ = await self.query_with_references(
            knowledge_bases_id=knowledge_bases_id,
            question=question,
            chat_history=chat_history,
        )
        return answer

    async def query_with_references(
        self,
        knowledge_bases_id: str,
        question: str,
        chat_history: list = [],
    ) -> Tuple[str, List[Tuple[str, str]]]:
        """
        查詢並同時回傳參考資料。

        Returns:
            Tuple[str, List[Tuple[str, str]]]:
                - 第一個元素：模型的最終回答文字
                - 第二個元素：參考資料列表，每個元素為 (content, uploadname)
        """
        agent = await self._get_agent(knowledge_bases_id)

        q = {
            "input": question,
            "chat_history": chat_history,
        }

        final_answer = ""
        references_raw = {}

        for stream_part in agent.stream(q):
            if stream_part[0] == ReturnProcess.COMPLETION:
                final_answer = stream_part[1]
                references_raw = stream_part[2] if len(stream_part) > 2 else {}

        print("\n--- 最終答案 ---\n")
        print(final_answer)
        print("\n------------------\n")

        # 將 references_raw 轉換為 (content, uploadname) 的 list
        # references_raw 結構：{ tool_name: [[content, source, metadata], ...] }
        reference_pairs: List[Tuple[str, str]] = []
        for _tool_name, pairs in references_raw.items():
            for pair in pairs:
                if not isinstance(pair, (list, tuple)) or len(pair) < 2:
                    continue
                content = pair[0] if pair[0] else ""
                uploadname = pair[1] if pair[1] else None
                if content:
                    reference_pairs.append((content, uploadname))

        return final_answer, reference_pairs
