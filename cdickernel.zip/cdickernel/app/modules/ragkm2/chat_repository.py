"""
chat_repository.py

負責 chat.conversation、chat.message、chat.reference 三張資料表的存取操作。
使用 aiosql 搭配 asyncpg 進行非同步 SQL 查詢。

資料表欄位（最新版本）：
  chat.conversation : id, account, knowledge_base_id, project_id, conversation_id, title, modifytm, createtm
  chat.message      : id, ask, conversation_id(UUID), message_id, reply_id, reply_msg, category, token, createtm
  chat.reference    : id, message_id(UUID), content, uploadname
"""

import uuid
import aiosql
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel
from datetime import datetime

from app.shared.database.tennat.connection_manager import TenantConnectionManager


# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------

class Conversation(BaseModel):
    id: int
    account: str
    knowledge_base_id: UUID
    conversation_id: UUID
    title: str
    modifytm: datetime
    createtm: datetime


class Message(BaseModel):
    id: int
    ask: str
    conversation_id: UUID        # 直接使用 conversation UUID 關聯（非整數 FK）
    message_id: Optional[UUID] = None
    reply_id: Optional[UUID] = None     # 上一輪訊息的 message_id；第一輪為 None
    reply_msg: Optional[str] = None
    category: Optional[str] = None
    token: Optional[int] = None
    createtm: datetime


class Reference(BaseModel):
    id: int
    message_id: UUID             # 直接使用 message UUID 關聯（非整數 FK）
    content: str
    uploadname: Optional[str]


# ---------------------------------------------------------------------------
# Repository
# ---------------------------------------------------------------------------

class ChatRepository:
    """
    封裝對 chat schema 三張核心資料表的所有資料庫操作：
      - chat.conversation  (對話串)
      - chat.message       (單一問答紀錄)
      - chat.reference     (回答所使用的參考片段)
    """

    def __init__(self):
        self.tenant_conn_mgr = TenantConnectionManager()
        self.queries = aiosql.from_path(
            "app/modules/ragkm2/agent/chat_queries.sql", "asyncpg"
        )

    # -----------------------------------------------------------------------
    # Conversation
    # -----------------------------------------------------------------------

    async def create_conversation(
        self,
        account: str,
        knowledge_base_id: UUID,
        conversation_id: Optional[UUID] = None,
    ) -> Conversation:
        """
        建立一筆新的對話紀錄。
        若未傳入 conversation_id 則自動產生一個 UUID。
        """
        if conversation_id is None:
            conversation_id = uuid.uuid4()

        count = await self.count_conversations(account)
        new_title = f"新對話 {count + 1}"

        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.create_conversation(
                connection,
                account=account,
                knowledge_base_id=knowledge_base_id,
                conversation_id=conversation_id,
                title=new_title,
            )
            return Conversation.model_validate(dict(record))

    async def find_conversation_by_uuid(
        self, conversation_id: UUID
    ) -> Optional[Conversation]:
        """以 conversation_id (UUID) 查詢單一對話。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.find_conversation_by_uuid(
                connection, conversation_id=conversation_id
            )
            if record:
                return Conversation.model_validate(dict(record))
            return None

    async def list_conversations(
        self, account: str, knowledge_base_id: UUID
    ) -> List[Conversation]:
        """列出某帳號在特定知識庫中的所有對話（依修改時間倒序）。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.list_conversations_by_account(
                connection,
                account=account,
                knowledge_base_id=knowledge_base_id,
            )
            return [Conversation.model_validate(dict(r)) async for r in records]

    async def count_conversations(self, account: str) -> int:
        """計算某帳號的對話數量。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            return await self.queries.count_conversations_by_account(
                connection,
                account=account,
            )

    async def update_conversation_modifytm(self, conversation_id: UUID) -> None:
        """更新對話的修改時間（每次新增訊息後呼叫）。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.update_conversation_modifytm(
                connection, conversation_id=conversation_id
            )

    async def update_conversation_title(self, conversation_id: UUID, title: str) -> None:
        """更新對話標題。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.update_conversation_title(
                connection, conversation_id=conversation_id, title=title
            )

    async def delete_conversation(self, conversation_id: UUID) -> None:
        """刪除指定對話。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.delete_conversation_by_uuid(
                connection, conversation_id=conversation_id
            )

    # -----------------------------------------------------------------------
    # Message
    # -----------------------------------------------------------------------

    async def create_message(
        self,
        ask: str,
        conversation_id: UUID,       # 直接傳 conversation UUID
        reply_id: UUID,
        reply_msg: str
    ) -> Message:
        """
        新增一筆問答訊息到指定對話。
        - ask            : 使用者提問
        - conversation_id: chat.conversation.conversation_id (UUID)
        - reply_msg      : 模型的回答
        """
        message_id = uuid.uuid4()
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.create_message(
                connection,
                ask=ask,
                conversation_id=conversation_id,
                message_id=message_id,
                reply_id=reply_id,
                reply_msg=reply_msg,
            )
            return Message.model_validate(dict(record))

    async def list_messages(self, conversation_id: UUID) -> List[Message]:
        """取得某對話的所有訊息（依建立時間升序，即對話順序）。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.list_messages_by_conversation(
                connection, conversation_id=conversation_id
            )
            return [Message.model_validate(dict(r)) async for r in records]

    async def get_message_by_uuid(self, message_id: UUID) -> Optional[Message]:
        """以 message_id (UUID) 查詢單一訊息。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.get_message_by_uuid(
                connection, message_id=message_id
            )
            if record:
                return Message.model_validate(dict(record))
            return None

    async def delete_messages_by_conversation_id(self, conversation_id: UUID) -> None:
        """刪除某對話下的所有訊息。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.delete_messages_by_conversation_id(
                connection, conversation_id=conversation_id
            )

    # -----------------------------------------------------------------------
    # Reference
    # -----------------------------------------------------------------------

    async def create_reference(
        self,
        message_id: UUID,            # 直接傳 message UUID
        content: str,
        uploadname: Optional[str] = None,
    ) -> Reference:
        """為某訊息新增一筆參考資料片段。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            record = await self.queries.create_reference(
                connection,
                message_id=message_id,
                content=content,
                uploadname=uploadname,
            )
            return Reference.model_validate(dict(record))

    async def list_references(self, message_id: UUID) -> List[Reference]:
        """取得某訊息的所有參考資料。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            records = self.queries.list_references_by_message_id(
                connection, message_id=message_id
            )
            return [Reference.model_validate(dict(r)) async for r in records]

    async def delete_references_by_message_id(self, message_id: UUID) -> None:
        """刪除某訊息的所有參考資料。"""
        db = await self.tenant_conn_mgr.get_central_connection()
        async with db.pool.acquire() as connection:
            await self.queries.delete_references_by_message_id(
                connection, message_id=message_id
            )

    # -----------------------------------------------------------------------
    # 輔助方法：建立 LangChain 相容的 chat_history
    # -----------------------------------------------------------------------

    async def build_chat_history(self, conversation_id: UUID) -> List[str]:
        """
        從資料庫讀取對話歷史，回傳符合 LangChain HumanMessage / AIMessage
        交替格式的字串列表：
          ["使用者問題1", "AI回答1", "使用者問題2", "AI回答2", ...]

        這個格式與 service.py 中傳入 agent 的 chat_history 參數相容。
        新對話時 list 為空（[]）。
        """
        messages = await self.list_messages(conversation_id)
        history: List[str] = []
        for msg in messages:
            history.append(msg.ask)
            if msg.reply_msg:
                history.append(msg.reply_msg)
        return history
