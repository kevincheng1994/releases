from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID
from datetime import datetime


# ---------------------------------------------------------------------------
# Query (現有，向下相容)
# ---------------------------------------------------------------------------

class QueryRequest(BaseModel):
    question: str = "申請國內交換學生要準備哪些文件？"
    chat_history: List[str] = []


class QueryResponse(BaseModel):
    answer: str


# ---------------------------------------------------------------------------
# Conversation (對話串)
# ---------------------------------------------------------------------------

class ConversationResponse(BaseModel):
    id: int
    account: str
    knowledge_base_id: UUID
    conversation_id: UUID
    title: str
    modifytm: datetime
    createtm: datetime


class UpdateConversationTitleRequest(BaseModel):
    conversation_id: UUID = Field(..., description="對話 ID")
    title: str = Field(..., description="新的對話標題")


# ---------------------------------------------------------------------------
# Chat (多輪對話查詢)
# ---------------------------------------------------------------------------

class ChatRequest(BaseModel):
    ask: str = Field(..., description="使用者提問")
    conversation_id: Optional[UUID] = Field(
        default=None,
        description="對話 ID（UUID）。若為空則自動建立新對話",
    )


class ReferenceItem(BaseModel):
    content: str
    uploadname: Optional[str] = None


class MessageResponse(BaseModel):
    id: int
    message_id: UUID
    ask: str
    reply_msg: Optional[str]
    reply_id: Optional[UUID]
    category: Optional[str]
    token: Optional[int]
    createtm: datetime
    references: List[ReferenceItem] = []


class ChatResponse(BaseModel):
    conversation_id: UUID
    is_new_conversation: bool = Field(description="是否為本次請求自動建立的新對話")
    message: MessageResponse


# ---------------------------------------------------------------------------
# 對話歷史
# ---------------------------------------------------------------------------

class ConversationHistoryResponse(BaseModel):
    conversation: ConversationResponse
    messages: List[MessageResponse]
