import asyncio
import os
import shutil
import tempfile
import threading
import traceback
import uuid
from pathlib import Path
from typing import Annotated, List, AsyncGenerator, Generator, Callable
from enum import Enum
from uuid import UUID
from fastapi import APIRouter, File, UploadFile, HTTPException, Form, Query, WebSocket, WebSocketDisconnect
from app.modules.ragkm2.agent.status_code import ReturnProcess
from app.modules.ragkm2.agent.tasks import process_and_store_file
from app.modules.ragkm2.agent.repository import KnowledgeBaseRepository, KnowledgeFile, KnowledgeBase
from app.modules.ragkm2.service import RAGKM2Service
from app.modules.ragkm2.chat_repository import ChatRepository
from app.modules.ragkm2.schemas import (
    QueryRequest,
    QueryResponse,
    ConversationResponse,
    UpdateConversationTitleRequest,
    ChatRequest,
    ChatResponse,
    MessageResponse,
    ReferenceItem,
    ConversationHistoryResponse,
)

# --- Enums for validation ---
class ConfigName(str, Enum):
    vertexai = "vertexai_geckomultilingual001"
    bedrock = "bedrock_titanembedtext20"
    azure = "azure_textembeddingada002"

class SplitType(str, Enum):
    simple = "simple"
    page = "page"

# --- FastAPI Router ---
router = APIRouter(prefix="/ragkm2", tags=["RAG Knowledge Management V2"])

# =============================================================================
# 知識庫管理 API
# =============================================================================

@router.post("/knowledge-bases/upload")
async def upload_knowledge_base_files(
    knowledge_base_id: Annotated[UUID, Form(description="Knowledge base ID.")],
    configname: Annotated[ConfigName, Form(description="Configuration name for embedding models.")] = ConfigName.azure,
    split_type: Annotated[SplitType, Form(description="The type of document splitter to use.")] = SplitType.simple,
    chunk_size: Annotated[int, Form(description="The size of chunks for splitting documents.")] = 512,
    files: List[UploadFile] = File(..., description="Files to upload for the knowledge base"),
):
    """
    Uploads multiple files to be processed and stored as a knowledge base, with dynamic splitting options.
    Each file will be processed in a separate background task.
    """
    if not knowledge_base_id:
        raise HTTPException(status_code=400, detail="Knowledge base ID cannot be empty.")

    kbrepo = KnowledgeBaseRepository()
    
    # 1. Find or create the knowledge base
    knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)
    if not knowledge_base:
        raise HTTPException(status_code=404, detail=f"Knowledge base '{knowledge_base_id}' not found.")

    results = []

    for file in files:
        temp_file_path = None
        try:
            # Check if a file with the same name already exists in this knowledge base
            existing_file = await kbrepo.find_file_by_kb_id_and_name(knowledge_base.id, file.filename)
            if existing_file:
                await kbrepo.clear_chunks_by_file_id(existing_file.id)
                knowledge_file_to_process = existing_file
                await kbrepo.update_knowledge_file_status(existing_file.id, "processing")
            else:
                knowledge_file_to_process = await kbrepo.create_knowledge_file(
                    knowledge_base_id=knowledge_base.id,
                    file_name=file.filename,
                    status="processing"
                )

            # Ensure the temporary file has the correct extension for processing
            suffix = Path(file.filename).suffix if file.filename else ""
            
            # Create a temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
                shutil.copyfileobj(file.file, temp_file)
                temp_file_path = temp_file.name

            # 3. Trigger the Celery background task for each file
            task_info = process_and_store_file.delay(
                temp_file_path,
                knowledge_base.account,
                str(knowledge_base.id),      # 確保傳 str 給 Celery JSON serializer
                configname.value,
                split_type.value,
                chunk_size,
                str(knowledge_file_to_process.id)
            )

            results.append({
                "file_name": file.filename,
                "knowledge_file_id": knowledge_file_to_process.id,
                "task_id": task_info.id,
                "status": "processing_started"
            })
        except Exception as e:
            # Clean up temp file if something went wrong before task dispatch for this specific file
            if temp_file_path and os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            results.append({
                "file_name": file.filename,
                "status": "failed_to_start_processing",
                "detail": str(e)
            })
            # It's better to continue processing other files even if one fails to start

    if not results:
        raise HTTPException(status_code=500, detail="No files could be processed.")

    return {
        "message": f"Processing initiated for {len(files)} file(s) for knowledge base '{knowledge_base.name}'.",
        "knowledge_base_name": knowledge_base.name,
        "account": knowledge_base.account,
        "split_options": {
            "configname": configname.value,
            "split_type": split_type.value,
            "chunk_size": chunk_size
        },
        "files_info": results
    }

@router.get("/knowledge-bases/list", response_model=List[KnowledgeBase])
async def list_knowledge_bases(
    account: Annotated[str, Query(description="Account.")],
):
    """
    列出指定帳號的所有知識庫。
    """
    kbrepo = KnowledgeBaseRepository()
    knowledge_bases = await kbrepo.list_kbs_by_account(account)
    return knowledge_bases

@router.get("/knowledge-bases/files", response_model=List[KnowledgeFile])
async def list_knowledge_base_files(
    knowledge_base_id: Annotated[UUID, Query(description="Knowledge base ID.")],
):
    """
    Lists all files associated with a specific knowledge base.
    """
    kbrepo = KnowledgeBaseRepository()
    knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)
    if not knowledge_base:
        raise HTTPException(status_code=404, detail=f"Knowledge base '{knowledge_base_id}' not found.")
    
    files = await kbrepo.list_files_by_kb_id(knowledge_base.id)
    return files

@router.delete("/knowledge-bases/files/delete")
async def delete_knowledge_base_file(
    knowledge_base_id: Annotated[UUID, Query(description="Knowledge base ID.")],
    file_id: Annotated[UUID, Query(description="File ID.")],
):
    """
    Deletes a specific file and its associated chunks from a knowledge base.
    """
    kbrepo = KnowledgeBaseRepository()
    
    # 1. Verify knowledge base exists and file belongs to it
    knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)
    if not knowledge_base:
        raise HTTPException(status_code=404, detail=f"Knowledge base '{knowledge_base_id}' not found.")

    knowledge_file = await kbrepo.get_knowledge_file_by_id(file_id)
    if not knowledge_file or knowledge_file.knowledge_base_id != knowledge_base.id:
        raise HTTPException(status_code=404, detail=f"File with ID '{file_id}' not found in knowledge base '{knowledge_base_id}'.")

    # 2. Delete the file record (which will cascade delete chunks due to ON DELETE CASCADE)
    await kbrepo.delete_knowledge_file_by_id(file_id)

    return {"message": f"File '{knowledge_file.file_name}' (ID: {file_id}) and its associated chunks deleted successfully from knowledge base '{knowledge_base_id}'."}

@router.post("/knowledge-bases/query", response_model=QueryResponse)
async def query_knowledge_base(
    account: Annotated[str, Query(description="Account.")],
    knowledge_bases_id: Annotated[UUID, Query(description="Knowledge base ID.")],
    request: QueryRequest
):
    """
    對指定知識庫進行單次無狀態查詢（不記錄對話歷史）。
    若需要多輪對話與歷史記錄，請使用 POST /knowledge-bases/{knowledge_base_id}/chat。
    """
    try:
        kbrepo = KnowledgeBaseRepository()
        knowledge_base = await kbrepo.find_kb_by_id(knowledge_bases_id)
        if not knowledge_base:
            raise HTTPException(status_code=404, detail=f"Knowledge base '{knowledge_bases_id}' not found.")
        if knowledge_base.account != account:
            raise HTTPException(status_code=403, detail=f"Account '{account}' does not have access to knowledge base '{knowledge_bases_id}'.")
        
        service = RAGKM2Service()
        answer = await service.query(
            knowledge_bases_id=knowledge_bases_id,
            question=request.question,
            chat_history=request.chat_history
        )
        return QueryResponse(answer=answer)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Conversation 管理 API
# =============================================================================

@router.get(
    "/conversations/list/{account}",
    response_model=List[ConversationResponse],
    summary="列出使用者的對話清單",
)
async def list_conversations(
    account: str
):
    """
    列出此帳號的所有歷史對話（依最後修改時間倒序）。 
    """
    chat_repo = ChatRepository()
    conversations = await chat_repo.list_conversations(
        account=account,
    )
    return conversations


@router.put(
    "/conversations/edit",
    summary="修改對話標題",
)
async def update_conversation_title(
    request: UpdateConversationTitleRequest,
):
    """
    修改指定對話的標題。
    """
    chat_repo = ChatRepository()
    conversation = await chat_repo.find_conversation_by_uuid(request.conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail=f"Conversation '{request.conversation_id}' not found.")

    await chat_repo.update_conversation_title(conversation_id=request.conversation_id, title=request.title)

    return {"message": f"Conversation title updated successfully."}


@router.get(
    "/conversations/{conversation_id}/history",
    response_model=ConversationHistoryResponse,
    summary="取得對話的完整歷史訊息",
)
async def get_conversation_history(
    conversation_id: UUID,
    account: Annotated[str, Query(description="Account.")],
):
    """
    取得某對話的所有訊息（含每則訊息的參考資料），用於前端顯示歷史記錄。
    """
    chat_repo = ChatRepository()
    conversation = await chat_repo.find_conversation_by_uuid(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail=f"Conversation '{conversation_id}' not found.")

    # 驗證知識庫存取權限
    kbrepo = KnowledgeBaseRepository()
    knowledge_base = await kbrepo.find_kb_by_id(conversation.knowledge_base_id)
    if not knowledge_base or knowledge_base.account != account:
        raise HTTPException(status_code=403, detail=f"Account '{account}' does not have access to this conversation.")

    messages = await chat_repo.list_messages(conversation_id=conversation.conversation_id)

    message_responses: List[MessageResponse] = []
    for msg in messages:
        refs = await chat_repo.list_references(message_id=msg.message_id)
        ref_items = [ReferenceItem(content=r.content, uploadname=r.uploadname) for r in refs]
        message_responses.append(
            MessageResponse(
                id=msg.id,
                message_id=msg.message_id,
                ask=msg.ask,
                reply_msg=msg.reply_msg,
                reply_id=msg.reply_id,
                category=msg.category,
                token=msg.token,
                createtm=msg.createtm,
                references=ref_items,
            )
        )

    return ConversationHistoryResponse(
        conversation=conversation.model_dump(),
        messages=message_responses,
    )

@router.delete(
    "/conversations/{conversation_id}",
    summary="刪除對話及其所有訊息",
)
async def delete_conversation(
    conversation_id: UUID
):
    """
    刪除指定的對話紀錄，並清除所有關聯的訊息與參考資料。
    """
    chat_repo = ChatRepository()
    conversation = await chat_repo.find_conversation_by_uuid(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail=f"Conversation '{conversation_id}' not found.")

    await chat_repo.delete_conversation(conversation_id=conversation_id)

    return {"message": f"Conversation '{conversation_id}' deleted successfully."}


# =============================================================================
# 多輪對話查詢 API（支援新對話 / 繼續舊對話）
# =============================================================================

@router.post(
    "/knowledge-bases/{knowledge_base_id}/chat",
    response_model=ChatResponse,
    summary="多輪對話查詢（自動記錄問答，支援新對話與繼續對話）",
)
async def chat(
    knowledge_base_id: UUID,
    account: Annotated[str, Query(description="Account.")],
    request: ChatRequest,
):
    """
    在指定知識庫中進行 RAG 查詢，自動記錄問答並支援多輪對話。

    - 若 `request.conversation_id` **為空**：自動建立新對話，回傳的 `is_new_conversation=True`
    - 若 `request.conversation_id` **有值**：繼續既有對話，從 DB 讀取歷史作為 `chat_history`

    流程：
    1. 驗證知識庫存取權限
    2. 若無 conversation_id → 建立新對話；否則查詢既有對話
    3. 從資料庫讀取歷史訊息，組成 chat_history 傳入 Agent
    4. 呼叫 RAGKM2Service.query_with_references() 取得回答與參考資料
    5. 將本次問答存入 chat.message
    6. 若有參考資料則存入 chat.reference
    7. 更新對話的修改時間
    8. 回傳完整的問答結果（含 conversation_id 讓前端後續使用）
    """
    # 1. 驗證知識庫存取權限
    kbrepo = KnowledgeBaseRepository()
    knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)
    if not knowledge_base:
        raise HTTPException(status_code=404, detail=f"Knowledge base '{knowledge_base_id}' not found.")
    if knowledge_base.account != account:
        raise HTTPException(status_code=403, detail=f"Account '{account}' does not have access to knowledge base '{knowledge_base_id}'.")

    chat_repo = ChatRepository()
    is_new_conversation = False

    # 2a. 沒有傳 conversation_id → 自動建立新對話
    if request.conversation_id is None:
        conversation = await chat_repo.create_conversation(
            account=account,
            knowledge_base_id=knowledge_base_id,
        )
        is_new_conversation = True

    # 2b. 有傳 conversation_id → 查找既有對話
    else:
        conversation = await chat_repo.find_conversation_by_uuid(request.conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=404,
                detail=f"Conversation '{request.conversation_id}' not found."
            )
        # 確保此對話屬於正確的知識庫
        if conversation.knowledge_base_id != knowledge_base_id:
            raise HTTPException(
                status_code=400,
                detail=f"Conversation '{request.conversation_id}' does not belong to knowledge base '{knowledge_base_id}'."
            )

    # 3. 從資料庫讀取歷史訊息，建構 chat_history（Human/AI 交替格式）
    #    新對話此時 list 會是空的，所以 chat_history = []
    chat_history = await chat_repo.build_chat_history(conversation_id=conversation.conversation_id)

    # 4. 取得上一輪訊息的 message_id（作為 reply_id 儲存，建立訊息鏈）
    existing_messages = await chat_repo.list_messages(conversation_id=conversation.conversation_id)

    # 5. 呼叫 RAG Service 取得回答及參考資料
    try:
        service = RAGKM2Service()
        answer, references = await service.query_with_references(
            knowledge_bases_id=conversation.knowledge_base_id,
            question=request.ask,
            chat_history=chat_history,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # 6. 將本次問答儲存到 chat.message
    new_message = await chat_repo.create_message(
        ask=request.ask,
        conversation_id=conversation.conversation_id,
        reply_msg=answer
    )

    # 7. 儲存參考資料到 chat.reference（以 message_id UUID 關聯）
    ref_items: List[ReferenceItem] = []
    for ref_content, ref_uploadname in references:
        await chat_repo.create_reference(
            message_id=new_message.message_id,
            content=ref_content,
            uploadname=ref_uploadname,
        )
        ref_items.append(ReferenceItem(content=ref_content, uploadname=ref_uploadname))

    # 8. 更新對話修改時間
    await chat_repo.update_conversation_modifytm(conversation_id=conversation.conversation_id)

    return ChatResponse(
        conversation_id=conversation.conversation_id,
        is_new_conversation=is_new_conversation,
        message=MessageResponse(
            id=new_message.id,
            message_id=new_message.message_id,
            ask=new_message.ask,
            reply_msg=new_message.reply_msg,
            reply_id=new_message.reply_id,
            category=new_message.category,
            token=new_message.token,
            createtm=new_message.createtm,
            references=ref_items,
        ),
    )


# =============================================================================
# WebSocket 流式查詢 API
# =============================================================================

_TOOL_DISPLAY_MAP = {
    "ChunkRetriever": "正在搜尋相關文件...",
    "EntireRetriever": "正在閱讀文件內容...",
    "ListDocNames": "正在列出知識庫文件...",
    "Notebook": "正在整理任務清單...",
    "TaskCompleter": "正在確認任務完成...",
}

def _simplify_agent_log(msg: str) -> str:
    """將 agent 傳來的訊息轉換為前端友善文字。
    - 若 msg 是工具名稱 (ReAct yield action.tool)，映射為中文說明。
    - 若 msg 已是友善文字 (pre-analysis yield)，直接回傳。
    - 若 msg 是 LangChain 內部錯誤名稱 (如 _Exception)，回傳 None 以略過。
    """
    print(f"_simplify_agent_log: {msg}")
    if msg in _TOOL_DISPLAY_MAP:
        return _TOOL_DISPLAY_MAP[msg]
    if msg.startswith("_"):
        return None
    return msg


@router.websocket("/knowledge-bases/{knowledge_base_id}/chat-ws")
async def chat_ws(
    websocket: WebSocket,
    knowledge_base_id: UUID,
    account: str = Query(..., description="Account."),
):
    """
    提供 WebSocket 串流的多輪查詢
    接收: {"ask": "我的問題", "conversation_id": "對話ID"}
    發送串流:
      {"status": "AGENT", "content": "Thought: ..."}
      {"status": "COMPLETION", "content": "Final Text", "references": [...]}
    """
    await websocket.accept()
    kbrepo = KnowledgeBaseRepository()
    knowledge_base = await kbrepo.find_kb_by_id(knowledge_base_id)
    if not knowledge_base:
        await websocket.send_json({"status": "error", "content": f"Knowledge base '{knowledge_base_id}' not found."})
        await websocket.close()
        return

    if knowledge_base.account != account and knowledge_base.account != "all":
        await websocket.send_json({"status": "error", "content": "Forbidden."})
        await websocket.close()
        return

    service = RAGKM2Service()
    chat_repo = ChatRepository()

    try:
        data = await websocket.receive_json()
        input_text = data.get('ask', '')
        conversation_id_str = data.get('conversation_id', None)
        model_name = data.get('model', None)

        is_new_conversation = False

        # 1. 解析對話 ID
        if conversation_id_str is None or conversation_id_str == "":
            conversation = await chat_repo.create_conversation(
                account=account,
                knowledge_base_id=knowledge_base_id,
            )
            conversation_id_str = str(conversation.conversation_id)
            is_new_conversation = True
        else:
            conversation_id_obj = UUID(conversation_id_str)
            conversation = await chat_repo.find_conversation_by_uuid(conversation_id_obj)
            if not conversation:
                await websocket.send_json({"status": "error", "content": f"Conversation '{conversation_id_str}' not found."})
                await websocket.close()
                return

        # 2. 回傳對話編號資訊
        await websocket.send_json({
            "status": "CONVERSATION_INFO",
            "conversation_id": str(conversation.conversation_id),
            "is_new_conversation": is_new_conversation
        })

        # 3. 取得歷史記錄
        chat_history = await chat_repo.build_chat_history(conversation_id=conversation.conversation_id)

        # 4. 取得上一筆訊息對話作關聯串聯 (目前 reply_id 被註解所以可能暫時用不到但還是抓出來)
        existing_messages = await chat_repo.list_messages(conversation_id=conversation.conversation_id)

        reply_id = uuid.uuid4()

        await websocket.send_json({
            "Action": "LOADING",
            "ConversationID": conversation_id_str,
            "MessageID": "",
            "Ask": input_text,
            "Reply": {
                "ReplyID": str(reply_id),
                "ReplyMsg": "正在載入知識庫...",
                "Category": "Legal"
            },
            "Reference": [],
            "Token": 0
        })

        agent = await service._get_agent(str(knowledge_base_id), model_name=model_name)

        q = {
            'input': input_text,
            'chat_history': chat_history
        }

        async def keepalive():
            """定時送 PING 給前端，避免 WebSocket 閒置超時斷線。"""
            while True:
                await asyncio.sleep(20)
                try:
                    await websocket.send_json({"Action": "PING"})
                except Exception:
                    break

        keepalive_task = asyncio.create_task(keepalive())
        try:
            async for stream_part in await stream_agent_response(agent, q):
                status = stream_part[0]

                if status == ReturnProcess.COMPLETION:
                    final_answer = stream_part[1]
                    references_raw = stream_part[2] if len(stream_part) > 2 else {}

                    # 轉換 reference 格式，去重並依來源分組
                    seen_contents = set()
                    # source -> list of passage dicts
                    source_passages: dict = {}
                    for _tool_name, pairs in references_raw.items():
                        for pair in pairs:
                            if not isinstance(pair, (list, tuple)) or len(pair) < 2:
                                continue
                            content = pair[0] if pair[0] else ""
                            uploadname = pair[1] if pair[1] else "未知來源"
                            if not content or content in seen_contents:
                                continue
                            seen_contents.add(content)
                            if uploadname not in source_passages:
                                source_passages[uploadname] = []
                            source_passages[uploadname].append(content)

                    # 展平為前端列表，每筆含 uploadname、content、passage_index
                    ref_items = []
                    for uploadname, passages in source_passages.items():
                        for idx, content in enumerate(passages, start=1):
                            ref_items.append({
                                "uploadname": uploadname,
                                "content": content,
                                "passage_index": idx,
                            })

                    # 儲存對話到資料庫
                    new_message = await chat_repo.create_message(
                        ask=input_text,
                        conversation_id=conversation.conversation_id,
                        reply_id=reply_id,
                        reply_msg=final_answer
                    )

                    for ref in ref_items:
                        await chat_repo.create_reference(
                            message_id=new_message.message_id,
                            content=ref['content'],
                            uploadname=ref['uploadname'],
                        )

                    # 更新對話時間
                    await chat_repo.update_conversation_modifytm(conversation_id=conversation.conversation_id)

                    await websocket.send_json({
                        "Action": "STOP",
                        "ConversationID": conversation_id_str,
                        "MessageID": str(new_message.message_id),
                        "Ask": input_text,
                        "Reply": {
                            "ReplyID": str(reply_id),
                            "ReplyMsg": stream_part[1],
                            "Category": "Legal"
                        },
                        "Reference": ref_items,
                    })
                elif status == ReturnProcess.AGENT:
                    display_msg = _simplify_agent_log(stream_part[1])
                    if display_msg is None:
                        continue
                    await websocket.send_json({
                        "Action": "LOADING",
                        "ConversationID": conversation_id_str,
                        "MessageID": "",
                        "Ask": input_text,
                        "Reply": {
                            "ReplyID": str(reply_id),
                            "ReplyMsg": display_msg,
                            "Category": "Legal"
                        },
                        "Reference": [],
                        "Token": 0
                    })
        finally:
            keepalive_task.cancel()
            try:
                await keepalive_task
            except asyncio.CancelledError:
                pass

    except WebSocketDisconnect:
        pass  # 客戶端斷線
    except asyncio.CancelledError:
        try:
            await websocket.send_json({"status": "cancelled", "content": "Server cancelled stream"})
        except RuntimeError:
            pass
    except asyncio.TimeoutError:
        try:
            await websocket.send_json({"status": "error", "content": "Stream timeout", "references": []})
        except RuntimeError:
            pass
    except Exception as e:
        print(f"[chat_ws] unhandled exception: {traceback.format_exc()}")
        try:
            await websocket.send_json({"status": "error", "content": str(e), "references": []})
        except RuntimeError:
            pass
    finally:
        try:
            if websocket.client_state != 3: # WebSocketState.DISCONNECTED
                await websocket.close()
        except Exception:
            pass


async def stream_agent_response(agent, question):
    def sync_gen():
        yield from agent.stream(question)

    return sync_to_async_gen_with_control(sync_gen, timeout=300.0)


def sync_to_async_gen_with_control(
    sync_gen_func: Callable[[], Generator],
    *,
    timeout: float = 60.0
) -> AsyncGenerator:
    """轉換同步生成器為非同步生成器，防止阻塞 event loop"""
    async def wrapper():
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue()
        stop_event = threading.Event()

        def run_and_enqueue():
            try:
                for item in sync_gen_func():
                    if stop_event.is_set():
                        break
                    loop.call_soon_threadsafe(queue.put_nowait, item)
            except Exception as e:
                loop.call_soon_threadsafe(queue.put_nowait, e)
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        thread = threading.Thread(target=run_and_enqueue, daemon=True)
        thread.start()

        try:
            while True:
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=timeout)
                except asyncio.TimeoutError:
                    raise

                if isinstance(item, Exception):
                    raise item

                if item is None:
                    break

                yield item
        except asyncio.CancelledError:
            stop_event.set()
            raise
        finally:
            stop_event.set()
            if thread.is_alive():
                thread.join(timeout=1.0)

    return wrapper()