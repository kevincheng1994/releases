import os
from celery import Celery

# This is the shared Celery application instance.
# Other modules can import this to register their tasks.
celery_app = Celery(
    'main_celery_app',
    broker=os.getenv('CELERY_BROKER_URL'),
    backend=os.getenv('CELERY_RESULT_BACKEND'),
    # List all modules that contain tasks here so Celery can discover them.
    include=['app.modules.ragkm2.agent.tasks']
)

celery_app.conf.update(
    task_serializer='json',
    result_serializer='json',
    accept_content=['json'],
    timezone='Asia/Taipei',
    enable_utc=True,
    worker_hijack_root_logger=False
)
