import asyncio
from .postgres_provider import PostgresTenantProvider

class TenantConnectionManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TenantConnectionManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self.postgres_providers = {}
        self._initialized = True

    async def _get_provider_for_current_loop(self) -> PostgresTenantProvider:
        loop = asyncio.get_running_loop()
        if loop not in self.postgres_providers:
            self.postgres_providers[loop] = PostgresTenantProvider()
            await self.postgres_providers[loop].initialize()
        return self.postgres_providers[loop]

    async def initialize(self):
        # This method is now implicitly called by _get_provider_for_current_loop
        # but we can keep it for explicit initialization if needed.
        provider = await self._get_provider_for_current_loop()
        await provider.initialize()

    async def check_connection(self):
        provider = await self._get_provider_for_current_loop()
        await provider.check_connection()

    async def get_central_connection(self, db_type: str = "postgres"):
        if db_type == "postgres":
            provider = await self._get_provider_for_current_loop()
            return await provider.get_central_db()
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

    async def get_connection(self, account: str, db_type: str = "postgres"):
        if db_type == "postgres":
            provider = await self._get_provider_for_current_loop()
            return await provider.get_database(account=account)
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

    async def close_all(self):
        for provider in self.postgres_providers.values():
            await provider.close_all()

# Create a single, globally accessible instance.
tenant_conn_mgr = TenantConnectionManager()