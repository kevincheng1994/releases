from app.shared.database.postgres.database import Postgres
from app.config.config import config

class PostgresTenantProvider:
    def __init__(self):
        self.central_db_config = config["database"]["postgres"]
        self.central_db = None
        self.cache = {}

    async def initialize(self):
        await self.get_central_db()

    async def get_central_db(self):
        if not self.central_db:
            self.central_db = Postgres(
                host=self.central_db_config.host,
                port=self.central_db_config.port,
                dbname=self.central_db_config.dbname,
                user=self.central_db_config.user,
                password=self.central_db_config.password,
            )
            await self.central_db.init_connection()
        return self.central_db

    async def get_database(self, account: str) -> Postgres:
        if account in self.cache:
            return self.cache[account]

        central_db = await self.get_central_db()
        query = "SELECT * FROM company.dbinfo WHERE account = $1"
        async with central_db.pool.acquire() as conn:
            result = await conn.fetchrow(query, account)

        if not result:
            raise ValueError(f"No Postgres config found for account: {account}")

        db = Postgres(
            host=result["dbip"],
            port=5432,
            dbname=result["dbname"],
            user=result["dbuserid"],
            password=result["dbpassword"],
        )
        await db.init_connection()
        self.cache[account] = db
        return db
    
    async def check_connection(self):
        central_db = await self.get_central_db()
        async with central_db.pool.acquire() as conn:
            await conn.execute("SELECT 1")

    async def close_all(self):
        if self.central_db:
            await self.central_db.close()
        for db in self.cache.values():
            await db.close()
