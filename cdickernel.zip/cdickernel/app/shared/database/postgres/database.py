import asyncpg

__all__ = ("Postgres",)

class Postgres:

    def __init__(
        self,
        host: str,
        user: str,
        password: str,
        dbname: str,
        autocommit: bool = True,
        port: int = 5432,
        pool_minsize=1,
        pool_maxsize=10,
        timeout=30.0,
    ):
        self._host = host
        self._user = user
        self._password = password
        self._dbname = dbname
        self._autocommit = autocommit
        self._port = port
        self._pool_minsize = pool_minsize
        self._pool_maxsize = pool_maxsize
        self._timeout = timeout
        self.pool = None

    async def connect(self):
        self.pool = await asyncpg.create_pool(
            host=self._host,
            port=self._port,
            user=self._user,
            password=self._password,
            database=self._dbname,
            min_size=self._pool_minsize,
            max_size=self._pool_maxsize,
            timeout=self._timeout,
        )

    async def check_connection(self):
        async with self.pool.acquire() as conn:
            await conn.execute("SELECT 1")

    async def init_connection(self):
        try:
            await self.connect()
            await self.check_connection()
        except Exception:
            raise

    async def close(self):
        if self.pool:
            await self.pool.close()
            self.pool = None