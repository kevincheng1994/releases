import logging
import sys
from datetime import datetime
import pytz

class TZFormatter(logging.Formatter):
    def __init__(self, fmt=None, datefmt=None, tz=None):
        super().__init__(fmt, datefmt)
        self.tz = tz or pytz.UTC

    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created, self.tz)
        if datefmt:
            return dt.strftime(datefmt)
        return dt.isoformat()

def setup_logger(name: str = "app", level: int = logging.INFO):
    logger = logging.getLogger(name)

    if not logger.hasHandlers():
        logger.setLevel(level)

        formatter = TZFormatter(
            fmt="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S %Z%z",
            tz=pytz.timezone("Asia/Taipei")
        )

        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # 防止 Celery logger 傳播給 root logger（會印第二次）
    logger.propagate = False

    return logger