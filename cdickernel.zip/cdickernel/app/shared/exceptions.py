from typing import ParamSpec, Type
from fastapi import status, FastAPI
from fastapi.responses import ORJSONResponse

P = ParamSpec("P")

class DomainException(Exception):

    TYPE = "internal_server_error"
    MESSAGE = "Internal Server Error"

    def __init__(self, message: str | None = None, **kwargs: P.kwargs):
        self._message = message
        self._kwargs = kwargs
        super().__init__(message)

    @property
    def message(self) -> str:
        return self._message or self.MESSAGE.format(**self._kwargs)

    def __str__(self) -> str:
        return self.message

class InvalidValueError(DomainException):
    TYPE = "invalid_field_value"
    MESSAGE = "Invalid value {field_value} for field {field_name}"

class CompanyNotFound(DomainException):
    TYPE = "company_not_found"
    MESSAGE = "Company {id} not found"

class MakrdownNotFound(DomainException):
    TYPE = "markdown_not_found"
    MESSAGE = "Markdown {id} not found"

class Forbidden(DomainException):
    TYPE = "forbidden"
    MESSAGE = "You don't have permission to access this resource"


DomainExceptionType = Type[DomainException]

EXCEPTION_STATUS_MAPPING: dict[DomainExceptionType, int] = {
    InvalidValueError: status.HTTP_400_BAD_REQUEST,
    Forbidden: status.HTTP_403_FORBIDDEN,
}

def setup_exception_handler(app: FastAPI) -> None:
    @app.exception_handler(DomainException)
    def domain_exception_handler(_, exc: DomainException) -> ORJSONResponse:
        return ORJSONResponse(
            content={
                "error": exc.message,
                "type": exc.TYPE
            },
            status_code=EXCEPTION_STATUS_MAPPING.get(type(exc), status.HTTP_500_INTERNAL_SERVER_ERROR)
        )

    @app.exception_handler(Exception)
    def exception_handler(_, exc: Exception) -> ORJSONResponse:
        return ORJSONResponse(
            content={
                "error": str(exc),
                "type": "internal_server_error",
            },
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
