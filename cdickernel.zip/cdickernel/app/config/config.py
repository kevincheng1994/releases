import glob
from dynaconf import Dynaconf, settings
from pathlib import Path
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings

__all__ = ("config", "Settings",)

ROOT_DIR = Path(__file__).parent

def read_files(file_path: str) -> list:
    return glob.glob(file_path, root_dir=ROOT_DIR)

confs = read_files("default/*.yml")

config = Dynaconf(
    settings_files=confs,
    core_loaders=["YAML"],
    load_dotenv=True,
    root_path=ROOT_DIR,
)

class Settings(BaseSettings):
    EMBEDDING_PROVIDER_TYPE: str = Field("vertexai", env="EMBEDDING_PROVIDER_TYPE") # New: e.g., 'vertexai', 'openai'
    EMBEDDING_MODEL_NAME: str = Field("textembedding-gecko-multilingual@001", env="EMBEDDING_MODEL_NAME")
    VERTEXAI_CREDENTIALS_PATH: str | None = Field(None, env="VERTEXAI_CREDENTIALS_PATH") # Path to service account JSON
    OPENAI_API_KEY: SecretStr | None = Field(None, env="OPENAI_API_KEY") # Keep for other uses if needed

    RAG_CHUNK_SIZE: int = Field(512, env="RAG_CHUNK_SIZE")
    RAG_CHUNK_OVERLAP: int = Field(200, env="RAG_CHUNK_OVERLAP")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = 'ignore' # Ignore extra environment variables


settings = Settings()