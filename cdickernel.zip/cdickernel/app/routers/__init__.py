from app.modules.heartbeat.router import router as heartbeat_router
from app.modules.ragkm2.router import router as ragkm2_router

__all__ = (
    "heartbeat_router",
    "ragkm2_router",
)

routers = (
    heartbeat_router,
    ragkm2_router,
)