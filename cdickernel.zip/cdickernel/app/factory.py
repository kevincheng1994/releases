from contextlib import asynccontextmanager
from typing import AsyncGenerator
from fastapi import FastAPI
from app.config.config import config
from app.shared.exceptions import setup_exception_handler
from app.routers import routers
from app.shared.database.tennat.connection_manager import tenant_conn_mgr

__all__ = ("create_app", )

def create_app() -> FastAPI:

    @asynccontextmanager
    async def lifespan(application: FastAPI) -> AsyncGenerator:
        print("App starting up.")
        await tenant_conn_mgr.initialize()
        print("Tenant Connection Manager initialized.")
        yield
        print("App shut down.")

    app: FastAPI = FastAPI(
        title=config.app.title,
        description=config.app.description,
        version=config.app.version,
        lifespan=lifespan,
    )

    # ✅ 加上動態 CORS 處理
    @app.middleware("http")
    async def custom_cors_middleware(request, call_next):
        origin = request.headers.get("origin")

        # 只允許 *.antnex.com.tw
        allow_cors = origin and (
            origin.endswith(".antnex.com.tw")
            or origin.startswith("http://127.0.0.1")
            or origin.startswith("http://localhost")
        )

        # 處理預檢請求（OPTIONS）
        if request.method == "OPTIONS" and allow_cors:
            from starlette.responses import Response

            response = Response(status_code=204)
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS,DELETE,PUT"
            response.headers["Access-Control-Allow-Headers"] = "Authorization,Content-Type,X-Requested-With"
            return response

        # 處理一般請求
        response = await call_next(request)

        if allow_cors:
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS,DELETE,PUT"
            response.headers["Access-Control-Allow-Headers"] = "Authorization,Content-Type,X-Requested-With"

        return response

    for router in routers:
        app.include_router(router)

    setup_exception_handler(app)

    return app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.factory:create_app",
        host="0.0.0.0",
        port=8000,
        access_log=False,
        reload=config.app.debug,
        reload_dirs=["app"],
        factory=True
    )
