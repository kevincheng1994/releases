// resources/voice-processor.js

class VoiceProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.targetSampleRate = 16000;
    this.bufferSize = 2048; // 固定的輸出緩衝區大小 (512 * 4)
    
    this.inputSampleRate = 48000; // 預設值，會被配置覆蓋
    this.downsampleRatio = 3;     // 預設比例

    // 內部緩衝區，用於累積從 process() 收到的數據
    // 大小設置得足夠大，以防止溢出
    this.internalBuffer = new Float32Array(this.inputSampleRate); // 暫存最多 1 秒的音訊
    this.bufferIndex = 0;

    this.port.onmessage = (event) => {
      if (event.data.sampleRate) {
        this.inputSampleRate = event.data.sampleRate;
        this.downsampleRatio = this.inputSampleRate / this.targetSampleRate;
        console.log(`🎛️ VoiceProcessor: Configured. Input SR: ${this.inputSampleRate}, Target SR: ${this.targetSampleRate}, Ratio: ${this.downsampleRatio}`);
      }
    };
  }

  process(inputs) {
    const inputChannel = inputs[0] ? inputs[0][0] : undefined;

    if (!inputChannel) {
      return true;
    }

    // 將新數據塞入內部緩衝區
    this.internalBuffer.set(inputChannel, this.bufferIndex);
    this.bufferIndex += inputChannel.length;

    // 計算需要多少輸入樣本才能產生一個完整的輸出塊
    const requiredInputSamples = Math.floor(this.bufferSize * this.downsampleRatio);

    // 當緩衝區中的數據足夠時，處理並發送
    if (this.bufferIndex >= requiredInputSamples) {
      // 1. 從內部緩衝區中提取所需數量的樣本
      const samplesToProcess = this.internalBuffer.subarray(0, requiredInputSamples);

      // 2. 降採樣並轉換為 Int16
      const outputBuffer = new Int16Array(this.bufferSize);
      for (let i = 0; i < this.bufferSize; i++) {
        const inputIndex = Math.floor(i * this.downsampleRatio);
        outputBuffer[i] = Math.max(-1, Math.min(1, samplesToProcess[inputIndex])) * 32767;
      }

      // 3. 發送數據塊
      this.port.postMessage(outputBuffer, [outputBuffer.buffer]);

      // 4. 將剩餘的數據移到緩衝區開頭，為下一次收集做準備
      const remainingSamples = this.internalBuffer.subarray(requiredInputSamples, this.bufferIndex);
      this.internalBuffer.fill(0); // 清空緩衝區
      this.internalBuffer.set(remainingSamples); // 將剩餘部分放回
      this.bufferIndex = remainingSamples.length;
    }

    return true; // 保持處理器活躍
  }
}

registerProcessor('voice-processor', VoiceProcessor);